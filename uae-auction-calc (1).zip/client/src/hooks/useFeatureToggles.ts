/**
 * useFeatureToggles — fetches site settings (feature toggles) from the database.
 * Admin can toggle these on/off from Site Settings → Feature Toggles.
 * Client pages use this hook to conditionally show/hide features.
 */
import { trpc } from "@/lib/trpc";

const TOGGLE_KEYS = [
  "shipping_quotes_enabled",
  "insurance_quotes_enabled",
  "parts_quotes_enabled",
] as const;

export type ToggleKey = (typeof TOGGLE_KEYS)[number];

export function useFeatureToggles() {
  const { data, isLoading } = trpc.siteConfig.getSettings.useQuery(
    { keys: [...TOGGLE_KEYS] },
    {
      staleTime: 60_000, // cache for 1 minute
      refetchOnWindowFocus: false,
    }
  );

  const isEnabled = (key: ToggleKey): boolean => {
    if (!data) return false; // default to disabled while loading
    return data[key] === "true";
  };

  return {
    isLoading,
    isEnabled,
    shippingQuotesEnabled: isEnabled("shipping_quotes_enabled"),
    insuranceQuotesEnabled: isEnabled("insurance_quotes_enabled"),
    partsQuotesEnabled: isEnabled("parts_quotes_enabled"),
  };
}
