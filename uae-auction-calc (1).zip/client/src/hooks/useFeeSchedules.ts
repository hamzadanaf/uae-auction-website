/**
 * useFeeSchedules — fetches fee schedule data from the database (admin Fee Guide Editor).
 * Falls back to hardcoded data from auctionData.ts if no database entries exist.
 */
import { trpc } from "@/lib/trpc";
import {
  COPART_BUYER_FEES,
  COPART_VIRTUAL_FEES,
  COPART_GATE_FEE,
  COPART_ENV_FEE,
  COPART_TITLE_FEE,
  UAE_CUSTOMS_RATE,
  UAE_VAT_RATE,
  USD_TO_AED,
  EMIRATES_REGISTRATION,
  formatUSD,
  formatAED,
} from "@/lib/auctionData";

interface FeeEntry {
  id: number;
  category: string;
  feeKey: string;
  label: string | null;
  value: string;
  sortOrder: number;
  isActive: number;
}

function parseFeeValue(entry: FeeEntry) {
  try {
    return JSON.parse(entry.value);
  } catch {
    return {};
  }
}

export function useFeeSchedules() {
  const { data: allFees, isLoading } = trpc.siteConfig.getFeeSchedules.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });

  const getByCategory = (category: string): FeeEntry[] => {
    if (!allFees) return [];
    return allFees
      .filter((f: FeeEntry) => f.category === category && f.isActive === 1)
      .sort((a: FeeEntry, b: FeeEntry) => a.sortOrder - b.sortOrder);
  };

  // ── Buyer Fees (Copart/IAAI) ──
  const dbBuyerFees = getByCategory("copart_buyer_fee");
  const buyerFees = dbBuyerFees.length > 0
    ? dbBuyerFees.map((f) => {
        const val = parseFeeValue(f);
        return {
          min: val.min ?? 0,
          max: val.max ?? Infinity,
          fee: val.fee ?? null,
          percent: val.percent ?? null,
          label: f.label,
        };
      })
    : COPART_BUYER_FEES;

  // ── Virtual Bid Fees ──
  const dbVirtualFees = getByCategory("copart_virtual_fee");
  const virtualFees = dbVirtualFees.length > 0
    ? dbVirtualFees.map((f) => {
        const val = parseFeeValue(f);
        return {
          min: val.min ?? 0,
          max: val.max ?? Infinity,
          fee: val.fee ?? 0,
          label: f.label,
        };
      })
    : COPART_VIRTUAL_FEES;

  // ── Fixed Fees ──
  const dbFixedFees = getByCategory("fixed_fee");
  const fixedFees = dbFixedFees.length > 0
    ? {
        gateFee: Number(dbFixedFees.find((f) => f.feeKey === "gate_fee")?.value ? parseFeeValue(dbFixedFees.find((f) => f.feeKey === "gate_fee")!).value : COPART_GATE_FEE),
        envFee: Number(dbFixedFees.find((f) => f.feeKey === "env_fee")?.value ? parseFeeValue(dbFixedFees.find((f) => f.feeKey === "env_fee")!).value : COPART_ENV_FEE),
        titleFee: Number(dbFixedFees.find((f) => f.feeKey === "title_fee")?.value ? parseFeeValue(dbFixedFees.find((f) => f.feeKey === "title_fee")!).value : COPART_TITLE_FEE),
        allEntries: dbFixedFees.map((f) => ({
          key: f.feeKey,
          label: f.label || f.feeKey,
          value: parseFeeValue(f).value ?? 0,
        })),
      }
    : {
        gateFee: COPART_GATE_FEE,
        envFee: COPART_ENV_FEE,
        titleFee: COPART_TITLE_FEE,
        allEntries: [
          { key: "gate_fee", label: "Gate Fee", value: COPART_GATE_FEE },
          { key: "env_fee", label: "Environmental Fee", value: COPART_ENV_FEE },
          { key: "title_fee", label: "Title Fee", value: COPART_TITLE_FEE },
        ],
      };

  // ── Import Tax Rates ──
  const dbImportTax = getByCategory("import_tax");
  const importTax = dbImportTax.length > 0
    ? {
        customsRate: Number(dbImportTax.find((f) => f.feeKey === "customs_duty")?.value ? parseFeeValue(dbImportTax.find((f) => f.feeKey === "customs_duty")!).rate : UAE_CUSTOMS_RATE),
        vatRate: Number(dbImportTax.find((f) => f.feeKey === "vat")?.value ? parseFeeValue(dbImportTax.find((f) => f.feeKey === "vat")!).rate : UAE_VAT_RATE),
        exchangeRate: Number(dbImportTax.find((f) => f.feeKey === "exchange_rate")?.value ? parseFeeValue(dbImportTax.find((f) => f.feeKey === "exchange_rate")!).rate : USD_TO_AED),
        allEntries: dbImportTax.map((f) => ({
          key: f.feeKey,
          label: f.label || f.feeKey,
          rate: parseFeeValue(f).rate ?? 0,
        })),
      }
    : {
        customsRate: UAE_CUSTOMS_RATE,
        vatRate: UAE_VAT_RATE,
        exchangeRate: USD_TO_AED,
        allEntries: [
          { key: "customs_duty", label: "Customs Duty", rate: UAE_CUSTOMS_RATE },
          { key: "vat", label: "VAT", rate: UAE_VAT_RATE },
          { key: "exchange_rate", label: "USD/AED Exchange Rate", rate: USD_TO_AED },
        ],
      };

  // ── Emirate Registration Fees ──
  const dbEmirateReg = getByCategory("emirate_registration");
  const emirateRegistration = dbEmirateReg.length > 0
    ? dbEmirateReg.map((f) => {
        const val = parseFeeValue(f);
        return {
          id: f.feeKey,
          name: f.label || f.feeKey,
          registrationFee: val.registrationFee ?? 0,
          inspectionFee: val.inspectionFee ?? 0,
          plateFee: val.plateFee ?? 0,
          otherFees: val.otherFees ?? 0,
          total: val.total ?? 0,
          notes: val.notes ?? "",
        };
      })
    : EMIRATES_REGISTRATION;

  // ── Shipping Methods ──
  const dbShipping = getByCategory("shipping_method");
  const shippingMethods = dbShipping.length > 0
    ? dbShipping.map((f) => {
        const val = parseFeeValue(f);
        return {
          key: f.feeKey,
          label: f.label || f.feeKey,
          costMin: val.costMin ?? 0,
          costMax: val.costMax ?? 0,
          transit: val.transit ?? "",
          notes: val.notes ?? "",
        };
      })
    : [
        { key: "roro", label: "RoRo (Roll-on/Roll-off)", costMin: 800, costMax: 1500, transit: "4-6 weeks", notes: "Cheapest option. Car must be driveable." },
        { key: "container_shared", label: "Container (Shared)", costMin: 1200, costMax: 2000, transit: "4-8 weeks", notes: "Shared container with other vehicles." },
        { key: "container_exclusive", label: "Container (Exclusive)", costMin: 2000, costMax: 3500, transit: "4-8 weeks", notes: "Your car only. Best for luxury/high-value." },
        { key: "air_freight", label: "Air Freight", costMin: 5000, costMax: 10000, transit: "3-5 days", notes: "Fastest. Rarely used for standard imports." },
      ];

  return {
    isLoading,
    buyerFees,
    virtualFees,
    fixedFees,
    importTax,
    emirateRegistration,
    shippingMethods,
    hasDbData: !!allFees && allFees.length > 0,
  };
}
