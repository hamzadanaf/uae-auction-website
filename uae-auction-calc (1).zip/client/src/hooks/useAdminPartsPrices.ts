/**
 * Hook to fetch admin-editable spare parts prices from the database.
 * Falls back to the hardcoded SPARE_PARTS array if no admin data is available.
 * Admin prices override hardcoded prices by matching on partId.
 */
import { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { SPARE_PARTS, type SparePart } from "@/lib/auctionData";

export function useAdminPartsPrices() {
  const { data: adminPrices, isLoading } = trpc.siteConfig.getPartsPrices.useQuery(undefined, {
    staleTime: 5 * 60_000, // Cache for 5 minutes
    retry: 1,
  });

  const parts: SparePart[] = useMemo(() => {
    if (!adminPrices || adminPrices.length === 0) {
      // No admin overrides — use hardcoded defaults
      return SPARE_PARTS;
    }

    // Build a map of admin prices by partId
    const adminMap = new Map<string, { priceAED: number; partName: string; category: string; isActive: number }>();
    for (const ap of adminPrices) {
      adminMap.set(ap.partId, {
        priceAED: ap.priceAED,
        partName: ap.partName,
        category: ap.category,
        isActive: ap.isActive,
      });
    }

    // Merge: admin overrides hardcoded, filter out inactive
    const merged: SparePart[] = [];

    for (const part of SPARE_PARTS) {
      const adminOverride = adminMap.get(part.id);
      if (adminOverride) {
        // Skip inactive parts
        if (adminOverride.isActive === 0) continue;
        merged.push({
          id: part.id,
          category: adminOverride.category || part.category,
          name: adminOverride.partName || part.name,
          priceAED: adminOverride.priceAED,
        });
        adminMap.delete(part.id); // Remove from map so we can add new ones later
      } else {
        merged.push(part);
      }
    }

    // Add any new parts that exist in admin DB but not in hardcoded array
    adminMap.forEach((ap, partId) => {
      if (ap.isActive === 0) return;
      merged.push({
        id: partId,
        category: ap.category,
        name: ap.partName,
        priceAED: ap.priceAED,
      });
    });

    return merged;
  }, [adminPrices]);

  return { parts, isLoading };
}
