import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import AuthGuard from "./components/AuthGuard";
import AdminGuard from "./components/AdminGuard";
import ClientLayout from "./components/ClientLayout";
import PublicHome from "./pages/PublicHome";
import Calculator from "./pages/Calculator";
import FeeGuide from "./pages/FeeGuide";
import ClientLogin from "./pages/ClientLogin";
import DealQueue from "./pages/DealQueue";
import FAQ from "./pages/FAQ";
import HowItWorks from "./pages/HowItWorks";
import Pricing from "./pages/Pricing";
import AdminDashboard from "./pages/AdminDashboard";
import Services from "./pages/Services";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCancel from "./pages/PaymentCancel";
import VehicleModels from "./pages/VehicleModels";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={PublicHome} />
      <Route path="/login" component={ClientLogin} />
      <Route path="/faq" component={FAQ} />
      <Route path="/how-it-works" component={HowItWorks} />
      <Route path="/pricing" component={Pricing} />

      {/* Protected client routes — require client session, wrapped in sidebar layout */}
      <Route path="/calculator">
        <AuthGuard>
          <ClientLayout><Calculator /></ClientLayout>
        </AuthGuard>
      </Route>
      <Route path="/fee-guide">
        <AuthGuard>
          <ClientLayout><FeeGuide /></ClientLayout>
        </AuthGuard>
      </Route>
      <Route path="/deal-queue">
        <AuthGuard>
          <ClientLayout><DealQueue /></ClientLayout>
        </AuthGuard>
      </Route>
      <Route path="/services">
        <AuthGuard>
          <ClientLayout><Services /></ClientLayout>
        </AuthGuard>
      </Route>
      <Route path="/vehicle-models">
        <AuthGuard>
          <ClientLayout><VehicleModels /></ClientLayout>
        </AuthGuard>
      </Route>

      {/* Payment routes — also wrapped in sidebar layout */}
      <Route path="/payment/success">
        <ClientLayout><PaymentSuccess /></ClientLayout>
      </Route>
      <Route path="/payment/cancel">
        <ClientLayout><PaymentCancel /></ClientLayout>
      </Route>

      {/* Admin-only route — requires Manus OAuth admin, keeps its own sidebar */}
      <Route path="/admin">
        <AdminGuard><AdminDashboard /></AdminGuard>
      </Route>

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <ThemeProvider defaultTheme="dark">
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}

export default App;
