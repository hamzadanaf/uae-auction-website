/*
 * Gulf Luxe Design — Navbar
 * Deep navy base, emerald accent, frosted glass effect
 * With language (AR/EN) and theme (dark/light) toggles
 * Auth-aware: shows client name + logout for authenticated users
 * Clicking on the client name opens an account details popover with change password
 */
import { Link, useLocation } from "wouter";
import { Calculator, BookOpen, Menu, X, BarChart3, Sun, Moon, Globe, Settings, LogOut, User, Phone, Lock, Check, Loader2, Eye, EyeOff, Building2, Car } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface ClientSession {
  id: number;
  username: string;
  displayName: string | null;
  email: string | null;
  phoneNumber?: string | null;
  role: string;
  createdAt?: string | null;
}

function getClientSession(): ClientSession | null {
  try {
    const raw = localStorage.getItem("clientSession");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export default function Navbar() {
  const [location, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { lang, setLang, t, isRTL } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user: authUser, logout: authLogout, isAuthenticated } = useAuth();
  const [session, setSession] = useState<ClientSession | null>(null);

  useEffect(() => {
    setSession(getClientSession());
  }, []);

  // Determine role: check server auth first, then localStorage fallback
  const displayUser = authUser || session;
  const isAdmin = displayUser?.role === "admin";
  const isLoggedIn = isAuthenticated || !!session;

  // Client nav items (only for authenticated non-admin users)
  const clientItems = [
    { href: "/calculator", label: t("nav.calculator"), icon: Calculator },
    { href: "/fee-guide", label: t("nav.feeGuide"), icon: BookOpen },
    { href: "/deal-queue", label: t("nav.dealQueue"), icon: BarChart3 },
    { href: "/services", label: "Services", icon: Building2 },
    { href: "/vehicle-models", label: "Models", icon: Car },
  ];

  // Admin sees only admin dashboard link
  const adminItems = [
    { href: "/admin", label: "Admin Panel", icon: Settings },
  ];

  // Public visitors see no nav items (they use the public home page navbar)
  const navItems = isAdmin ? adminItems : isLoggedIn ? clientItems : [];

  const handleLogout = async () => {
    // Clear localStorage
    localStorage.removeItem("clientSession");
    setSession(null);
    // Call server-side logout to clear cookies
    try {
      await authLogout();
    } catch {
      // Ignore errors
    }
    navigate("/login");
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50">
      <div className="glass-card border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <Link href={isLoggedIn ? (isAdmin ? "/admin" : "/calculator") : "/"} className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center group-hover:bg-primary/25 transition-colors">
              <Calculator className="w-5 h-5 text-primary" />
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-bold text-lg leading-tight tracking-tight text-foreground">
                {t("nav.brand")} <span className="text-gradient">{t("nav.brandAccent")}</span>
              </span>
              <span className="text-[10px] text-muted-foreground leading-none tracking-widest uppercase">
                {t("nav.subtitle")}
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? "bg-primary/15 text-primary border border-primary/20"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              );
            })}

            {/* Divider */}
            <div className="w-px h-6 bg-border/50 mx-1" />

            {/* Language Toggle */}
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all duration-200"
              title={lang === "en" ? "التبديل إلى العربية" : "Switch to English"}
            >
              <Globe className="w-4 h-4" />
              <span className="text-xs font-semibold">{lang === "en" ? "AR" : "EN"}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all duration-200"
              title={theme === "dark" ? t("settings.light") : t("settings.dark")}
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Auth Section */}
            {isLoggedIn ? (
              <>
                <div className="w-px h-6 bg-border/50 mx-1" />
                {/* Clickable name → Account Details Popover */}
                <AccountPopover
                  displayUser={displayUser}
                  session={session}
                />
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-all duration-200"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-200"
              >
                Login
              </Link>
            )}
          </div>

          {/* Mobile: toggles + menu button */}
          <div className="md:hidden flex items-center gap-1">
            {/* Language Toggle Mobile */}
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
            >
              <Globe className="w-5 h-5" />
            </button>

            {/* Theme Toggle Mobile */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Menu Button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="md:hidden glass-card border-b border-border/50"
          >
            <div className="container py-3 flex flex-col gap-1">
              {navItems.map((item) => {
                const isActive = location === item.href;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                      isActive
                        ? "bg-primary/15 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                );
              })}

              {/* Mobile Auth Section */}
              {isLoggedIn ? (
                <>
                  <div className="h-px bg-border/50 my-2" />
                  {/* Account details popover for mobile */}
                  <AccountPopover
                    displayUser={displayUser}
                    session={session}
                    isMobile
                  />
                  <button
                    onClick={() => { handleLogout(); setMobileOpen(false); }}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <div className="h-px bg-border/50 my-2" />
                  <Link
                    href="/login"
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium bg-primary/10 text-primary"
                  >
                    <User className="w-4 h-4" />
                    Login
                  </Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

/**
 * Account Details Popover — opens when user clicks their name in the navbar.
 * Shows account info (name, phone, username) and a change password form.
 */
function AccountPopover({
  displayUser,
  session,
  isMobile,
}: {
  displayUser: any;
  session: ClientSession | null;
  isMobile?: boolean;
}) {
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [pwSuccess, setPwSuccess] = useState(false);

  // Fetch full account details from server
  const { data: accountDetails } = trpc.accounts.getMyAccount.useQuery(undefined, {
    enabled: !!session, // only fetch for client sessions (not Manus OAuth admin)
  });

  const changePasswordMutation = trpc.accounts.changePassword.useMutation({
    onSuccess: () => {
      setPwSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      toast.success("Password changed successfully");
      setTimeout(() => {
        setShowChangePassword(false);
        setPwSuccess(false);
      }, 1500);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to change password");
    },
  });

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      toast.error("Please fill in both fields");
      return;
    }
    if (newPassword.length < 6) {
      toast.error("New password must be at least 6 characters");
      return;
    }
    changePasswordMutation.mutate({ currentPassword, newPassword });
  };

  const displayName = displayUser?.displayName || displayUser?.name || displayUser?.username || "User";
  const firstLetter = displayName.charAt(0).toUpperCase();
  const details = accountDetails || session;
  const phoneNumber = details?.phoneNumber;
  const username = details?.username || session?.username;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          className={`flex items-center gap-2 rounded-lg transition-all duration-200 cursor-pointer hover:bg-secondary/50 ${
            isMobile ? "px-4 py-2 w-full" : "px-3 py-1.5 bg-secondary/30"
          }`}
        >
          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <span className="text-xs font-bold text-primary">{firstLetter}</span>
          </div>
          <span className={`text-xs font-medium text-foreground ${isMobile ? "" : "max-w-[100px]"} truncate`}>
            {displayName}
          </span>
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 bg-card border-border/50 shadow-2xl shadow-black/30"
        align={isMobile ? "start" : "end"}
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-border/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-lg font-bold text-primary">{firstLetter}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{displayName}</p>
              <p className="text-xs text-muted-foreground truncate">{username}</p>
            </div>
          </div>
        </div>

        {/* Account Details */}
        <div className="px-5 py-4 space-y-3">
          {phoneNumber && (
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Phone</p>
                <p className="text-sm text-foreground" dir="ltr">{phoneNumber}</p>
              </div>
            </div>
          )}
          {details?.email && (
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Email</p>
                <p className="text-sm text-foreground">{details.email}</p>
              </div>
            </div>
          )}
          {details?.createdAt && (
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Member Since</p>
                <p className="text-sm text-foreground">
                  {new Date(details.createdAt).toLocaleDateString("en-AE", {
                    month: "long",
                    year: "numeric",
                  })}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Change Password Section — only for client sessions, not Manus OAuth admin */}
        {session && (
          <div className="border-t border-border/30 px-5 py-4">
            {!showChangePassword ? (
              <button
                onClick={() => setShowChangePassword(true)}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors w-full"
              >
                <Lock className="w-4 h-4" />
                Change Password
              </button>
            ) : (
              <form onSubmit={handleChangePassword} className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  Change Password
                </p>
                <div className="relative">
                  <Input
                    type={showCurrentPw ? "text" : "password"}
                    placeholder="Current password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    disabled={changePasswordMutation.isPending}
                    className="bg-secondary border-border h-9 text-sm rounded-lg pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPw(!showCurrentPw)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showCurrentPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="relative">
                  <Input
                    type={showNewPw ? "text" : "password"}
                    placeholder="New password (min 6 chars)"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={changePasswordMutation.isPending}
                    className="bg-secondary border-border h-9 text-sm rounded-lg pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPw(!showNewPw)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showNewPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="flex gap-2">
                  <Button
                    type="submit"
                    size="sm"
                    className="flex-1 h-8 text-xs"
                    disabled={changePasswordMutation.isPending || pwSuccess}
                  >
                    {changePasswordMutation.isPending ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                    ) : pwSuccess ? (
                      <Check className="w-3.5 h-3.5 mr-1" />
                    ) : null}
                    {pwSuccess ? "Done!" : "Save"}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-8 text-xs"
                    onClick={() => {
                      setShowChangePassword(false);
                      setCurrentPassword("");
                      setNewPassword("");
                      setPwSuccess(false);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
