/**
 * AuthGuard — wraps protected routes.
 * Checks for a valid client session in localStorage.
 * If not authenticated, redirects to /login with a ?redirect= param.
 *
 * Uses synchronous initialization to avoid flash-of-redirect on client-side navigation.
 */
import { useEffect } from "react";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

function hasValidSession(): boolean {
  try {
    const raw = localStorage.getItem("clientSession");
    if (!raw) return false;
    const session = JSON.parse(raw);
    return !!(session && session.id);
  } catch {
    return false;
  }
}

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const [, navigate] = useLocation();

  // Synchronous check — no useState needed, avoids re-render race
  const isAuthenticated = hasValidSession();

  useEffect(() => {
    if (!isAuthenticated) {
      const currentPath = window.location.pathname;
      navigate(`/login?redirect=${encodeURIComponent(currentPath)}`);
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return <>{children}</>;
}
