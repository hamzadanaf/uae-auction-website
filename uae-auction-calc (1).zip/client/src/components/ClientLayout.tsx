/**
 * ClientLayout — Collapsible sidebar layout for authenticated client pages.
 * Replaces the old top Navbar for logged-in clients.
 * Includes: nav items, CarFax placeholder, language/theme toggles, account popover, logout.
 */
import { useAuth } from "@/_core/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { trpc } from "@/lib/trpc";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import {
  Calculator,
  BookOpen,
  BarChart3,
  Building2,
  Car,
  Sun,
  Moon,
  Globe,
  LogOut,
  PanelLeft,
  User,
  Phone,
  Lock,
  Check,
  Loader2,
  Eye,
  EyeOff,
  FileSearch,
  Settings,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface ClientSession {
  id: number;
  username: string;
  displayName: string | null;
  email: string | null;
  phoneNumber?: string | null;
  role: string;
  createdAt?: string | null;
}

function getClientSession(): ClientSession | null {
  try {
    const raw = localStorage.getItem("clientSession");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

const SIDEBAR_WIDTH_KEY = "client-sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 200;
const MAX_WIDTH = 400;

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  return (
    <SidebarProvider
      style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}
    >
      <ClientSidebarContent setSidebarWidth={setSidebarWidth}>
        {children}
      </ClientSidebarContent>
    </SidebarProvider>
  );
}

function ClientSidebarContent({
  children,
  setSidebarWidth,
}: {
  children: React.ReactNode;
  setSidebarWidth: (w: number) => void;
}) {
  const [location, navigate] = useLocation();
  const { lang, setLang, t, isRTL } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user: authUser, logout: authLogout, isAuthenticated } = useAuth();
  const [session, setSession] = useState<ClientSession | null>(null);
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  useEffect(() => {
    setSession(getClientSession());
  }, []);

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };
    const handleMouseUp = () => setIsResizing(false);

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  const displayUser = authUser || session;
  const isAdmin = displayUser?.role === "admin";

  const handleLogout = async () => {
    localStorage.removeItem("clientSession");
    setSession(null);
    try { await authLogout(); } catch {}
    navigate("/login");
  };

  // Client nav items
  const navItems = [
    { href: "/calculator", label: t("nav.calculator"), icon: Calculator },
    { href: "/fee-guide", label: t("nav.feeGuide"), icon: BookOpen },
    { href: "/deal-queue", label: t("nav.dealQueue"), icon: BarChart3 },
    { href: "/services", label: "Services", icon: Building2 },
    { href: "/vehicle-models", label: "Models", icon: Car },
  ];

  // Admin sees admin panel link
  if (isAdmin) {
    navItems.length = 0;
    navItems.push({ href: "/admin", label: "Admin Panel", icon: Settings });
  }

  const activeItem = navItems.find((item) => location === item.href);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r-0" disableTransition={isResizing}>
          {/* Header: toggle + brand */}
          <SidebarHeader className="h-16 justify-center">
            <div className="flex items-center gap-3 px-2 transition-all w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none shrink-0"
                aria-label="Toggle sidebar"
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed && (
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
                    <Calculator className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="font-heading font-bold text-sm leading-tight tracking-tight text-foreground truncate">
                      {t("nav.brand")} <span className="text-primary">{t("nav.brandAccent")}</span>
                    </span>
                    <span className="text-[9px] text-muted-foreground leading-none tracking-widest uppercase">
                      {t("nav.subtitle")}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </SidebarHeader>

          {/* Navigation items */}
          <SidebarContent className="gap-0">
            <SidebarMenu className="px-2 py-1">
              {navItems.map((item) => {
                const isActive = location === item.href;
                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                      isActive={isActive}
                      onClick={() => navigate(item.href)}
                      tooltip={item.label}
                      className="h-10 transition-all font-normal"
                    >
                      <item.icon className={`h-4 w-4 ${isActive ? "text-primary" : ""}`} />
                      <span>{item.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}

              {/* Divider */}
              <div className="h-px bg-border/50 my-2 mx-2" />

              {/* CarFax — Coming Soon */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => toast.info("CarFax integration coming soon!", { description: "Vehicle history reports will be available in a future update." })}
                  tooltip="CarFax (Coming Soon)"
                  className="h-10 transition-all font-normal opacity-60 hover:opacity-100"
                >
                  <FileSearch className="h-4 w-4" />
                  <span>CarFax</span>
                  <span className="ml-auto text-[9px] font-semibold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full group-data-[collapsible=icon]:hidden">
                    Soon
                  </span>
                </SidebarMenuButton>
              </SidebarMenuItem>

              {/* Divider */}
              <div className="h-px bg-border/50 my-2 mx-2" />

              {/* Language Toggle */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setLang(lang === "en" ? "ar" : "en")}
                  tooltip={lang === "en" ? "التبديل إلى العربية" : "Switch to English"}
                  className="h-10 transition-all font-normal"
                >
                  <Globe className="h-4 w-4" />
                  <span>{lang === "en" ? "العربية" : "English"}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>

              {/* Theme Toggle */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={toggleTheme}
                  tooltip={theme === "dark" ? t("settings.light") : t("settings.dark")}
                  className="h-10 transition-all font-normal"
                >
                  {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  <span>{theme === "dark" ? t("settings.light") : t("settings.dark")}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>

          {/* Footer: user account + logout */}
          <SidebarFooter className="p-3">
            <SidebarMenu>
              {/* Account */}
              <SidebarMenuItem>
                <SidebarAccountPopover displayUser={displayUser} session={session} isCollapsed={isCollapsed} />
              </SidebarMenuItem>

              {/* Logout */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={handleLogout}
                  tooltip="Sign Out"
                  className="h-10 transition-all font-normal text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Sign Out</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarFooter>
        </Sidebar>

        {/* Resize handle */}
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => { if (!isCollapsed) setIsResizing(true); }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        {/* Mobile top bar */}
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-3 backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />
              <span className="text-sm font-medium tracking-tight text-foreground">
                {activeItem?.label ?? "Menu"}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setLang(lang === "en" ? "ar" : "en")}
                className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
              >
                <Globe className="w-4 h-4" />
              </button>
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
              >
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}
        <main className="flex-1">{children}</main>
      </SidebarInset>
    </>
  );
}

/**
 * Account popover in the sidebar footer — shows user info and change password form.
 */
function SidebarAccountPopover({
  displayUser,
  session,
  isCollapsed,
}: {
  displayUser: any;
  session: ClientSession | null;
  isCollapsed: boolean;
}) {
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [pwSuccess, setPwSuccess] = useState(false);

  const { data: accountDetails } = trpc.accounts.getMyAccount.useQuery(undefined, {
    enabled: !!session,
  });

  const changePasswordMutation = trpc.accounts.changePassword.useMutation({
    onSuccess: () => {
      setPwSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      toast.success("Password changed successfully");
      setTimeout(() => {
        setShowChangePassword(false);
        setPwSuccess(false);
      }, 1500);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to change password");
    },
  });

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      toast.error("Please fill in both fields");
      return;
    }
    if (newPassword.length < 6) {
      toast.error("New password must be at least 6 characters");
      return;
    }
    changePasswordMutation.mutate({ currentPassword, newPassword });
  };

  const displayName = displayUser?.displayName || displayUser?.name || displayUser?.username || "User";
  const firstLetter = displayName.charAt(0).toUpperCase();
  const details = accountDetails || session;
  const phoneNumber = details?.phoneNumber;
  const username = details?.username || session?.username;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="flex items-center gap-3 rounded-lg px-1 py-1.5 hover:bg-accent/50 transition-colors w-full text-left focus:outline-none group-data-[collapsible=icon]:justify-center">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <span className="text-sm font-bold text-primary">{firstLetter}</span>
          </div>
          <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
            <p className="text-sm font-medium truncate leading-none text-foreground">{displayName}</p>
            <p className="text-[10px] text-muted-foreground truncate mt-1">{username}</p>
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 bg-card border-border/50 shadow-2xl shadow-black/30"
        side="right"
        align="end"
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-border/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-lg font-bold text-primary">{firstLetter}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{displayName}</p>
              <p className="text-xs text-muted-foreground truncate">{username}</p>
            </div>
          </div>
        </div>

        {/* Account Details */}
        <div className="px-5 py-4 space-y-3">
          {phoneNumber && (
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Phone</p>
                <p className="text-sm text-foreground" dir="ltr">{phoneNumber}</p>
              </div>
            </div>
          )}
          {details?.email && (
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Email</p>
                <p className="text-sm text-foreground">{details.email}</p>
              </div>
            </div>
          )}
          {details?.createdAt && (
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-muted-foreground shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Member Since</p>
                <p className="text-sm text-foreground">
                  {new Date(details.createdAt).toLocaleDateString("en-AE", { month: "long", year: "numeric" })}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Change Password */}
        {session && (
          <div className="border-t border-border/30 px-5 py-4">
            {!showChangePassword ? (
              <button
                onClick={() => setShowChangePassword(true)}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors w-full"
              >
                <Lock className="w-4 h-4" />
                Change Password
              </button>
            ) : (
              <form onSubmit={handleChangePassword} className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  Change Password
                </p>
                <div className="relative">
                  <Input
                    type={showCurrentPw ? "text" : "password"}
                    placeholder="Current password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    disabled={changePasswordMutation.isPending}
                    className="bg-secondary border-border h-9 text-sm rounded-lg pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPw(!showCurrentPw)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showCurrentPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="relative">
                  <Input
                    type={showNewPw ? "text" : "password"}
                    placeholder="New password (min 6 chars)"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={changePasswordMutation.isPending}
                    className="bg-secondary border-border h-9 text-sm rounded-lg pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPw(!showNewPw)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showNewPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="flex gap-2">
                  <Button
                    type="submit"
                    size="sm"
                    className="flex-1 h-8 text-xs"
                    disabled={changePasswordMutation.isPending || pwSuccess}
                  >
                    {changePasswordMutation.isPending ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                    ) : pwSuccess ? (
                      <Check className="w-3.5 h-3.5 mr-1" />
                    ) : null}
                    {pwSuccess ? "Done!" : "Save"}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-8 text-xs"
                    onClick={() => {
                      setShowChangePassword(false);
                      setCurrentPassword("");
                      setNewPassword("");
                      setPwSuccess(false);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
