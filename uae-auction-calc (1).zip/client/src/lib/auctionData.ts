/**
 * US-to-UAE Import Calculator Data
 * Copart/IAAI fee schedules, UAE customs, registration, spare parts
 */

// ─── USD / AED Exchange Rate ───
export const USD_TO_AED = 3.685;

// ─── Copart/IAAI Buyer Fee Function (Exact) ───
export function calculateBuyerFee(price: number): number {
  if (price < 50) return 1.00;
  if (price < 100) return 1.00;
  if (price < 200) return 25.00;
  if (price < 300) return 60.00;
  if (price < 350) return 85.00;
  if (price < 400) return 100.00;
  if (price < 450) return 125.00;
  if (price < 500) return 135.00;
  if (price < 550) return 145.00;
  if (price < 600) return 155.00;
  if (price < 700) return 170.00;
  if (price < 800) return 195.00;
  if (price < 900) return 215.00;
  if (price < 1000) return 230.00;
  if (price < 1200) return 250.00;
  if (price < 1300) return 270.00;
  if (price < 1400) return 285.00;
  if (price < 1500) return 300.00;
  if (price < 1600) return 315.00;
  if (price < 1700) return 330.00;
  if (price < 1800) return 350.00;
  if (price < 2000) return 370.00;
  if (price < 2400) return 390.00;
  if (price < 2500) return 425.00;
  if (price < 3000) return 460.00;
  if (price < 3500) return 505.00;
  if (price < 4000) return 555.00;
  if (price < 4500) return 600.00;
  if (price < 5000) return 625.00;
  if (price < 5500) return 650.00;
  if (price < 6000) return 675.00;
  if (price < 6500) return 700.00;
  if (price < 7000) return 720.00;
  if (price < 7500) return 755.00;
  if (price < 8000) return 775.00;
  if (price < 8500) return 800.00;
  if (price < 9000) return 820.00;
  if (price < 10000) return 820.00;
  if (price < 10500) return 850.00;
  if (price < 11000) return 850.00;
  if (price < 11500) return 850.00;
  if (price < 12000) return 860.00;
  if (price < 12500) return 875.00;
  if (price < 15000) return 890.00;
  return price * 0.06;
}

// ─── Copart/IAAI Virtual Bid Fee (Live-Bid) ───
export function calculateVirtualBidFee(price: number): number {
  if (price <= 100) return 0.00;
  if (price <= 500) return 50.00;
  if (price <= 1000) return 65.00;
  if (price <= 1500) return 85.00;
  if (price <= 2000) return 95.00;
  if (price <= 4000) return 110.00;
  if (price <= 6000) return 125.00;
  if (price <= 8000) return 145.00;
  return 160.00;
}

export const COPART_TITLE_FEE = 20;
export const COPART_ENV_FEE = 15;
export const COPART_GATE_FEE = 95;

// Export buyer fees as arrays for FeeGuide
export const COPART_BUYER_FEES_ARRAY = [
  { min: 0, max: 50, fee: 1 },
  { min: 50, max: 100, fee: 1 },
  { min: 100, max: 200, fee: 25 },
  { min: 200, max: 300, fee: 60 },
  { min: 300, max: 350, fee: 85 },
  { min: 350, max: 400, fee: 100 },
  { min: 400, max: 450, fee: 125 },
  { min: 450, max: 500, fee: 135 },
  { min: 500, max: 550, fee: 145 },
  { min: 550, max: 600, fee: 155 },
  { min: 600, max: 700, fee: 170 },
  { min: 700, max: 800, fee: 195 },
  { min: 800, max: 900, fee: 215 },
  { min: 900, max: 1000, fee: 230 },
  { min: 1000, max: 1200, fee: 250 },
  { min: 1200, max: 1300, fee: 270 },
  { min: 1300, max: 1400, fee: 285 },
  { min: 1400, max: 1500, fee: 300 },
  { min: 1500, max: 1600, fee: 315 },
  { min: 1600, max: 1700, fee: 330 },
  { min: 1700, max: 1800, fee: 350 },
  { min: 1800, max: 2000, fee: 370 },
  { min: 2000, max: 2400, fee: 390 },
  { min: 2400, max: 2500, fee: 425 },
  { min: 2500, max: 3000, fee: 460 },
  { min: 3000, max: 3500, fee: 505 },
  { min: 3500, max: 4000, fee: 555 },
  { min: 4000, max: 4500, fee: 600 },
  { min: 4500, max: 5000, fee: 625 },
  { min: 5000, max: 5500, fee: 650 },
  { min: 5500, max: 6000, fee: 675 },
  { min: 6000, max: 6500, fee: 700 },
  { min: 6500, max: 7000, fee: 720 },
  { min: 7000, max: 7500, fee: 755 },
  { min: 7500, max: 8000, fee: 775 },
  { min: 8000, max: 8500, fee: 800 },
  { min: 8500, max: 9000, fee: 820 },
  { min: 9000, max: 10000, fee: 820 },
  { min: 10000, max: 10500, fee: 850 },
  { min: 10500, max: 11000, fee: 850 },
  { min: 11000, max: 11500, fee: 850 },
  { min: 11500, max: 12000, fee: 860 },
  { min: 12000, max: 12500, fee: 875 },
  { min: 12500, max: 15000, fee: 890 },
  { min: 15000, max: Infinity, fee: null, percent: 6 },
];

export const COPART_BUYER_FEES = COPART_BUYER_FEES_ARRAY;
export const IAAI_BUYER_FEES = COPART_BUYER_FEES_ARRAY;

export const COPART_VIRTUAL_FEES_ARRAY = [
  { min: 0, max: 100, fee: 0 },
  { min: 100, max: 500, fee: 50 },
  { min: 500, max: 1000, fee: 65 },
  { min: 1000, max: 1500, fee: 85 },
  { min: 1500, max: 2000, fee: 95 },
  { min: 2000, max: 4000, fee: 110 },
  { min: 4000, max: 6000, fee: 125 },
  { min: 6000, max: 8000, fee: 145 },
  { min: 8000, max: Infinity, fee: 160 },
];

export const COPART_VIRTUAL_FEES = COPART_VIRTUAL_FEES_ARRAY;

// ─── Fee Calculator Functions ───
export function getCopartTotalFees(bid: number): {
  buyerFee: number; gateFee: number; envFee: number; virtualFee: number; titleFee: number; total: number;
} {
  const buyerFee = calculateBuyerFee(bid);
  const virtualFee = calculateVirtualBidFee(bid);
  const total = buyerFee + COPART_GATE_FEE + COPART_ENV_FEE + virtualFee + COPART_TITLE_FEE;
  return { buyerFee, gateFee: COPART_GATE_FEE, envFee: COPART_ENV_FEE, virtualFee, titleFee: COPART_TITLE_FEE, total };
}

// IAAI uses same fees as Copart
export function getIAAITotalFees(bid: number) {
  return getCopartTotalFees(bid);
}

// ─── Average Repair Costs by Damage Type (AED) ───
export const REPAIR_COSTS_BY_DAMAGE: Record<string, number> = {
  "Front End": 3500,
  "Rear End": 2800,
  "Side": 2500,
  "Rollover": 5500,
  "Water/Flood": 4200,
  "Fire/Burn": 6000,
  "Hail": 1800,
  "Vandalism/Theft": 2200,
  "Mechanical": 3000,
  "Minor Dents": 800,
  "Biohazard": 1500,
  "All Over": 7500,
};

// ─── UAE Import Costs ───
export const UAE_CUSTOMS_RATE = 0.05;
export const UAE_VAT_RATE = 0.05;

export function calculateUAEImportTax(cifValueAED: number) {
  const customsDuty = cifValueAED * UAE_CUSTOMS_RATE;
  const vat = (cifValueAED + customsDuty) * UAE_VAT_RATE;
  return { customsDuty, vat, total: customsDuty + vat };
}

// ─── UAE Registration Fees by Emirate ───
export interface EmirateRegistration {
  id: string;
  name: string;
  registrationFee: number;
  inspectionFee: number;
  plateFee: number;
  otherFees: number;
  total: number;
  notes: string;
}



export const EMIRATES_REGISTRATION: EmirateRegistration[] = [
  {
    id: "dubai",
    name: "Dubai",
    registrationFee: 500,
    inspectionFee: 150,
    plateFee: 200,
    otherFees: 100,
    total: 950,
    notes: "RTA - Fastest processing",
  },
  {
    id: "abu-dhabi",
    name: "Abu Dhabi",
    registrationFee: 450,
    inspectionFee: 150,
    plateFee: 180,
    otherFees: 80,
    total: 860,
    notes: "DARB - Lowest fees",
  },
  {
    id: "sharjah",
    name: "Sharjah",
    registrationFee: 400,
    inspectionFee: 120,
    plateFee: 160,
    otherFees: 70,
    total: 750,
    notes: "STA",
  },
  {
    id: "ajman",
    name: "Ajman",
    registrationFee: 350,
    inspectionFee: 100,
    plateFee: 140,
    otherFees: 60,
    total: 650,
    notes: "ATA",
  },
  {
    id: "umm-al-quwain",
    name: "Umm Al Quwain",
    registrationFee: 320,
    inspectionFee: 100,
    plateFee: 130,
    otherFees: 50,
    total: 600,
    notes: "UQTA",
  },
  {
    id: "ras-al-khaimah",
    name: "Ras Al Khaimah",
    registrationFee: 330,
    inspectionFee: 110,
    plateFee: 140,
    otherFees: 50,
    total: 630,
    notes: "RAKKTA",
  },
  {
    id: "fujairah",
    name: "Fujairah",
    registrationFee: 310,
    inspectionFee: 100,
    plateFee: 130,
    otherFees: 50,
    total: 590,
    notes: "FTA",
  },
];

// ─── Spare Parts with UAE Market Prices ───
export interface SparePart {
  id: string;
  category: string;
  name: string;
  priceAED: number;
}

export const SPARE_PARTS: SparePart[] = [
  // Engine & Drivetrain
  { id: "engine", category: "Engine & Drivetrain", name: "Engine", priceAED: 8000 },
  { id: "transmission", category: "Engine & Drivetrain", name: "Transmission", priceAED: 6500 },
  { id: "radiator", category: "Engine & Drivetrain", name: "Radiator", priceAED: 1200 },
  { id: "ac-compressor", category: "Engine & Drivetrain", name: "AC Compressor", priceAED: 1500 },

  // Body Parts
  { id: "front-bumper", category: "Body Parts", name: "Front Bumper", priceAED: 800 },
  { id: "rear-bumper", category: "Body Parts", name: "Rear Bumper", priceAED: 700 },
  { id: "hood", category: "Body Parts", name: "Hood", priceAED: 600 },
  { id: "trunk-lid", category: "Body Parts", name: "Trunk Lid", priceAED: 700 },
  { id: "fender", category: "Body Parts", name: "Fender", priceAED: 500 },
  { id: "door", category: "Body Parts", name: "Door", priceAED: 1200 },
  { id: "roof", category: "Body Parts", name: "Roof Panel", priceAED: 1500 },

  // Glass
  { id: "windshield", category: "Glass", name: "Windshield", priceAED: 1000 },
  { id: "rear-window", category: "Glass", name: "Rear Window", priceAED: 800 },
  { id: "side-window", category: "Glass", name: "Side Window", priceAED: 500 },

  // Electrical
  { id: "headlights", category: "Electrical", name: "Headlights (Pair)", priceAED: 1200 },
  { id: "taillights", category: "Electrical", name: "Taillights (Pair)", priceAED: 900 },
  { id: "alternator", category: "Electrical", name: "Alternator", priceAED: 1800 },
  { id: "battery", category: "Electrical", name: "Battery", priceAED: 400 },

  // Suspension
  { id: "shock-absorbers", category: "Suspension", name: "Shock Absorbers (Set)", priceAED: 1600 },
  { id: "springs", category: "Suspension", name: "Springs (Set)", priceAED: 1200 },
  { id: "control-arms", category: "Suspension", name: "Control Arms (Pair)", priceAED: 1400 },

  // Brakes
  { id: "brake-pads", category: "Brakes", name: "Brake Pads (Set)", priceAED: 600 },
  { id: "brake-rotors", category: "Brakes", name: "Brake Rotors (Set)", priceAED: 1000 },
  { id: "brake-calipers", category: "Brakes", name: "Brake Calipers (Pair)", priceAED: 1800 },

  // Interior
  { id: "dashboard", category: "Interior", name: "Dashboard", priceAED: 2000 },
  { id: "seats", category: "Interior", name: "Seats (Set)", priceAED: 3000 },
  { id: "carpet", category: "Interior", name: "Carpet/Floor Mats", priceAED: 500 },
];

// ─── Damage Type to Parts Mapping ───
export const DAMAGE_TYPE_PARTS: Record<string, string[]> = {
  "Front End": ["front-bumper", "hood", "headlights", "radiator", "fender", "windshield", "ac-compressor"],
  "Rear End": ["rear-bumper", "trunk-lid", "taillights", "rear-window"],
  "Side": ["door", "fender", "side-window", "control-arms"],
  "Rollover": ["windshield", "roof", "door", "side-window", "dashboard"],
  "Water/Flood": ["engine", "transmission", "alternator", "battery", "carpet"],
  "Fire/Burn": ["engine", "transmission", "dashboard", "seats", "headlights"],
  "Hail": ["windshield", "hood", "roof", "headlights", "taillights"],
  "Vandalism/Theft": ["headlights", "taillights", "door", "windshield"],
  "Mechanical": ["transmission", "radiator", "shock-absorbers", "brake-pads"],
  "Minor Dents": ["fender", "door", "hood"],
  "Biohazard": ["seats", "carpet", "dashboard"],
  "All Over": [
    "engine", "transmission", "front-bumper", "rear-bumper", "hood", "trunk-lid",
    "windshield", "rear-window", "headlights", "taillights", "seats", "dashboard"
  ],
};

// ─── Market Price Database (65+ Models) ───
export interface CarPriceRange {
  make: string;
  model: string;
  year: number;
  lowAED: number;
  midAED: number;
  highAED: number;
}

export const CAR_MARKET_PRICES: CarPriceRange[] = [
  // Toyota
  { make: "Toyota", model: "Camry", year: 2022, lowAED: 45000, midAED: 52000, highAED: 60000 },
  { make: "Toyota", model: "Camry", year: 2021, lowAED: 40000, midAED: 47000, highAED: 54000 },
  { make: "Toyota", model: "Corolla", year: 2022, lowAED: 35000, midAED: 42000, highAED: 48000 },
  { make: "Toyota", model: "Corolla", year: 2021, lowAED: 30000, midAED: 37000, highAED: 43000 },
  { make: "Toyota", model: "RAV4", year: 2022, lowAED: 55000, midAED: 65000, highAED: 75000 },
  { make: "Toyota", model: "Highlander", year: 2022, lowAED: 70000, midAED: 82000, highAED: 95000 },
  { make: "Toyota", model: "4Runner", year: 2022, lowAED: 80000, midAED: 95000, highAED: 110000 },

  // Honda
  { make: "Honda", model: "Civic", year: 2022, lowAED: 38000, midAED: 45000, highAED: 52000 },
  { make: "Honda", model: "Accord", year: 2022, lowAED: 48000, midAED: 56000, highAED: 65000 },
  { make: "Honda", model: "CR-V", year: 2022, lowAED: 52000, midAED: 62000, highAED: 72000 },
  { make: "Honda", model: "Pilot", year: 2022, lowAED: 65000, midAED: 78000, highAED: 90000 },

  // Nissan
  { make: "Nissan", model: "Altima", year: 2022, lowAED: 42000, midAED: 50000, highAED: 58000 },
  { make: "Nissan", model: "Maxima", year: 2022, lowAED: 55000, midAED: 65000, highAED: 75000 },
  { make: "Nissan", model: "Rogue", year: 2022, lowAED: 48000, midAED: 58000, highAED: 68000 },
  { make: "Nissan", model: "Murano", year: 2022, lowAED: 60000, midAED: 72000, highAED: 85000 },
  { make: "Nissan", model: "Pathfinder", year: 2022, lowAED: 68000, midAED: 82000, highAED: 95000 },

  // Hyundai
  { make: "Hyundai", model: "Elantra", year: 2022, lowAED: 32000, midAED: 38000, highAED: 45000 },
  { make: "Hyundai", model: "Sonata", year: 2022, lowAED: 40000, midAED: 48000, highAED: 56000 },
  { make: "Hyundai", model: "Santa Fe", year: 2022, lowAED: 50000, midAED: 60000, highAED: 70000 },
  { make: "Hyundai", model: "Palisade", year: 2022, lowAED: 58000, midAED: 70000, highAED: 82000 },

  // Kia
  { make: "Kia", model: "Forte", year: 2022, lowAED: 32000, midAED: 38000, highAED: 45000 },
  { make: "Kia", model: "Optima", year: 2022, lowAED: 42000, midAED: 50000, highAED: 58000 },
  { make: "Kia", model: "Sorento", year: 2022, lowAED: 50000, midAED: 60000, highAED: 70000 },
  { make: "Kia", model: "Telluride", year: 2022, lowAED: 65000, midAED: 78000, highAED: 90000 },

  // Ford
  { make: "Ford", model: "Focus", year: 2022, lowAED: 30000, midAED: 36000, highAED: 42000 },
  { make: "Ford", model: "Fusion", year: 2022, lowAED: 38000, midAED: 45000, highAED: 52000 },
  { make: "Ford", model: "Escape", year: 2022, lowAED: 48000, midAED: 58000, highAED: 68000 },
  { make: "Ford", model: "Edge", year: 2022, lowAED: 58000, midAED: 70000, highAED: 82000 },
  { make: "Ford", model: "Explorer", year: 2022, lowAED: 65000, midAED: 78000, highAED: 90000 },
  { make: "Ford", model: "F-150", year: 2022, lowAED: 75000, midAED: 90000, highAED: 105000 },

  // Chevrolet
  { make: "Chevrolet", model: "Cruze", year: 2022, lowAED: 28000, midAED: 34000, highAED: 40000 },
  { make: "Chevrolet", model: "Malibu", year: 2022, lowAED: 36000, midAED: 43000, highAED: 50000 },
  { make: "Chevrolet", model: "Equinox", year: 2022, lowAED: 45000, midAED: 54000, highAED: 63000 },
  { make: "Chevrolet", model: "Traverse", year: 2022, lowAED: 58000, midAED: 70000, highAED: 82000 },
  { make: "Chevrolet", model: "Silverado", year: 2022, lowAED: 72000, midAED: 86000, highAED: 100000 },

  // BMW
  { make: "BMW", model: "3 Series", year: 2022, lowAED: 65000, midAED: 78000, highAED: 92000 },
  { make: "BMW", model: "5 Series", year: 2022, lowAED: 85000, midAED: 102000, highAED: 120000 },
  { make: "BMW", model: "X3", year: 2022, lowAED: 75000, midAED: 90000, highAED: 105000 },
  { make: "BMW", model: "X5", year: 2022, lowAED: 95000, midAED: 115000, highAED: 135000 },

  // Mercedes-Benz
  { make: "Mercedes-Benz", model: "C-Class", year: 2022, lowAED: 70000, midAED: 84000, highAED: 98000 },
  { make: "Mercedes-Benz", model: "E-Class", year: 2022, lowAED: 90000, midAED: 108000, highAED: 126000 },
  { make: "Mercedes-Benz", model: "GLC", year: 2022, lowAED: 80000, midAED: 96000, highAED: 112000 },
  { make: "Mercedes-Benz", model: "GLE", year: 2022, lowAED: 100000, midAED: 120000, highAED: 140000 },

  // Audi
  { make: "Audi", model: "A4", year: 2022, lowAED: 68000, midAED: 82000, highAED: 96000 },
  { make: "Audi", model: "A6", year: 2022, lowAED: 88000, midAED: 105000, highAED: 122000 },
  { make: "Audi", model: "Q3", year: 2022, lowAED: 75000, midAED: 90000, highAED: 105000 },
  { make: "Audi", model: "Q5", year: 2022, lowAED: 95000, midAED: 114000, highAED: 133000 },

  // Mazda
  { make: "Mazda", model: "Mazda3", year: 2022, lowAED: 35000, midAED: 42000, highAED: 49000 },
  { make: "Mazda", model: "Mazda6", year: 2022, lowAED: 45000, midAED: 54000, highAED: 63000 },
  { make: "Mazda", model: "CX-5", year: 2022, lowAED: 50000, midAED: 60000, highAED: 70000 },

  // Subaru
  { make: "Subaru", model: "Impreza", year: 2022, lowAED: 38000, midAED: 45000, highAED: 52000 },
  { make: "Subaru", model: "Legacy", year: 2022, lowAED: 48000, midAED: 57000, highAED: 66000 },
  { make: "Subaru", model: "Outback", year: 2022, lowAED: 52000, midAED: 62000, highAED: 72000 },
  { make: "Subaru", model: "Forester", year: 2022, lowAED: 50000, midAED: 60000, highAED: 70000 },

  // Volkswagen
  { make: "Volkswagen", model: "Jetta", year: 2022, lowAED: 32000, midAED: 38000, highAED: 45000 },
  { make: "Volkswagen", model: "Passat", year: 2022, lowAED: 42000, midAED: 50000, highAED: 58000 },
  { make: "Volkswagen", model: "Tiguan", year: 2022, lowAED: 50000, midAED: 60000, highAED: 70000 },

  // Lexus
  { make: "Lexus", model: "ES", year: 2022, lowAED: 65000, midAED: 78000, highAED: 91000 },
  { make: "Lexus", model: "RX", year: 2022, lowAED: 75000, midAED: 90000, highAED: 105000 },
  { make: "Lexus", model: "NX", year: 2022, lowAED: 60000, midAED: 72000, highAED: 84000 },

  // Jeep
  { make: "Jeep", model: "Wrangler", year: 2022, lowAED: 58000, midAED: 70000, highAED: 82000 },
  { make: "Jeep", model: "Grand Cherokee", year: 2022, lowAED: 62000, midAED: 75000, highAED: 88000 },
  { make: "Jeep", model: "Cherokee", year: 2022, lowAED: 48000, midAED: 58000, highAED: 68000 },

  // GMC
  { make: "GMC", model: "Sierra", year: 2022, lowAED: 75000, midAED: 90000, highAED: 105000 },
  { make: "GMC", model: "Yukon", year: 2022, lowAED: 85000, midAED: 102000, highAED: 120000 },
  { make: "GMC", model: "Terrain", year: 2022, lowAED: 48000, midAED: 58000, highAED: 68000 },

  // RAM
  { make: "RAM", model: "1500", year: 2022, lowAED: 78000, midAED: 94000, highAED: 110000 },
  { make: "RAM", model: "2500", year: 2022, lowAED: 92000, midAED: 110000, highAED: 128000 },

  // Dodge
  { make: "Dodge", model: "Charger", year: 2022, lowAED: 55000, midAED: 66000, highAED: 77000 },
  { make: "Dodge", model: "Durango", year: 2022, lowAED: 62000, midAED: 75000, highAED: 88000 },

  // Chrysler
  { make: "Chrysler", model: "300", year: 2022, lowAED: 58000, midAED: 70000, highAED: 82000 },
  { make: "Chrysler", model: "Pacifica", year: 2022, lowAED: 65000, midAED: 78000, highAED: 91000 },
];

// ─── Helper to find market price ───
export function getMarketPrice(make: string, model: string, year: number) {
  const match = CAR_MARKET_PRICES.find(
    (car) => car.make.toLowerCase() === make.toLowerCase() &&
             car.model.toLowerCase() === model.toLowerCase() &&
             car.year === year
  );
  return match || null;
}

// ─── Alias for backward compatibility ───
export const EMIRATES = EMIRATES_REGISTRATION;

// ─── Formatting Helpers ───
export function formatUSD(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatAED(value: number): string {
  return new Intl.NumberFormat('en-AE', {
    style: 'currency',
    currency: 'AED',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

// ─── Helper to generate marketplace search links ───
export function generateMarketplaceLinks(make: string, model: string, year: number) {
  const encodedMake = encodeURIComponent(make);
  const encodedModel = encodeURIComponent(model);
  
  return {
    dubicars: `https://www.dubicars.com/uae/used/${encodedMake.toLowerCase()}/${encodedModel.toLowerCase()}?year=${year}`,
    dubizzle: `https://dubai.dubizzle.com/motors/used-cars/${encodedMake.toLowerCase()}/${encodedModel.toLowerCase()}/`,
    opensouq: `https://www.opensooq.com/en/search?q=${encodedMake}+${encodedModel}+${year}`,
  };
}
