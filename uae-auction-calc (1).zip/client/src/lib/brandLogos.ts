/**
 * Brand logo URL mapping using logo.dev CDN
 * Maps brand names (lowercase) to their website domains for logo fetching
 */

const BRAND_DOMAINS: Record<string, string> = {
  acura: "acura.com",
  "alfa romeo": "alfaromeo.com",
  "aston martin": "astonmartin.com",
  audi: "audi.com",
  bentley: "bentleymotors.com",
  bmw: "bmw.com",
  buick: "buick.com",
  cadillac: "cadillac.com",
  chevrolet: "chevrolet.com",
  chrysler: "chrysler.com",
  dodge: "dodge.com",
  ferrari: "ferrari.com",
  fiat: "fiat.com",
  ford: "ford.com",
  genesis: "genesis.com",
  gmc: "gmc.com",
  honda: "honda.com",
  hyundai: "hyundai.com",
  infiniti: "infiniti.com",
  jaguar: "jaguar.com",
  jeep: "jeep.com",
  kia: "kia.com",
  lamborghini: "lamborghini.com",
  "land rover": "landrover.com",
  lexus: "lexus.com",
  lincoln: "lincoln.com",
  lucid: "lucidmotors.com",
  maserati: "maserati.com",
  maybach: "mercedes-benz.com",
  mazda: "mazda.com",
  mclaren: "mclaren.com",
  "mercedes-benz": "mercedes-benz.com",
  mini: "mini.com",
  mitsubishi: "mitsubishi-motors.com",
  nissan: "nissan.com",
  peugeot: "peugeot.com",
  porsche: "porsche.com",
  ram: "ramtrucks.com",
  renault: "renault.com",
  rivian: "rivian.com",
  "rolls-royce": "rolls-roycemotorcars.com",
  smart: "smart.com",
  subaru: "subaru.com",
  suzuki: "suzuki.com",
  tesla: "tesla.com",
  toyota: "toyota.com",
  volkswagen: "volkswagen.com",
  volvo: "volvocars.com",
};

/**
 * Get the logo URL for a car brand
 * Uses logo.dev CDN with a public token
 */
export function getBrandLogoUrl(brand: string, size: number = 80): string {
  const key = brand.toLowerCase().trim();
  const domain = BRAND_DOMAINS[key];
  if (!domain) {
    // Fallback: try brand name + .com
    return `https://img.logo.dev/${key.replace(/\s+/g, "")}.com?token=pk_X-1ZO13GSgeOoUrIuJ6GMQ&format=png&size=${size}`;
  }
  return `https://img.logo.dev/${domain}?token=pk_X-1ZO13GSgeOoUrIuJ6GMQ&format=png&size=${size}`;
}

/**
 * Get all brand domains for reference
 */
export function getAllBrandDomains(): Record<string, string> {
  return { ...BRAND_DOMAINS };
}

/**
 * Region colors for brand categorization
 */
export const REGION_COLORS: Record<string, { bg: string; text: string; border: string; label: string }> = {
  american: { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/20", label: "American" },
  japanese: { bg: "bg-red-500/10", text: "text-red-400", border: "border-red-500/20", label: "Japanese" },
  european: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20", label: "European" },
  korean: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20", label: "Korean" },
};

/**
 * Category icons and labels
 */
export const CATEGORY_INFO: Record<string, { emoji: string; label: string }> = {
  sedan: { emoji: "🚗", label: "Sedan" },
  suv: { emoji: "🚙", label: "SUV" },
  truck: { emoji: "🛻", label: "Truck" },
  coupe: { emoji: "🏎️", label: "Coupe" },
  hatchback: { emoji: "🚗", label: "Hatchback" },
  van: { emoji: "🚐", label: "Van" },
  electric: { emoji: "⚡", label: "Electric" },
  sports: { emoji: "🏎️", label: "Sports" },
  luxury: { emoji: "✨", label: "Luxury" },
  crossover: { emoji: "🚙", label: "Crossover" },
};
