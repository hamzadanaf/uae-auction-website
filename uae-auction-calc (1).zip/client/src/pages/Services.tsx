/**
 * Services Directory — Client-facing page showing shipping, insurance, and parts shops.
 * Each section is controlled by admin Feature Toggles (site settings).
 * If a toggle is OFF, that section is hidden from clients.
 * Clients can request quotes from companies.
 */
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useFeatureToggles } from "@/hooks/useFeatureToggles";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useState } from "react";
import {
  Ship,
  Shield,
  Wrench,
  Phone,
  Globe,
  MapPin,
  Star,
  Loader2,
  Info,
  Building2,
  MessageSquare,
  Clock,
  CheckCircle2,
  Send,
  History,
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: "easeOut" as const },
  }),
};

const statusColors: Record<string, string> = {
  pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  sent: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  responded: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  closed: "bg-muted text-muted-foreground border-border",
};

function CompanyCard({
  company,
  type,
  onRequestQuote,
}: {
  company: any;
  type: "shipping" | "insurance" | "parts";
  onRequestQuote: (company: any, type: "shipping" | "insurance" | "parts") => void;
}) {
  const iconMap = { shipping: Ship, insurance: Shield, parts: Wrench };
  const Icon = iconMap[type];

  return (
    <Card className="glass-card border-border/40 hover:border-primary/30 transition-all duration-200">
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-heading font-semibold text-sm text-foreground truncate">
              {company.name}
            </h3>
            {company.description && (
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                {company.description}
              </p>
            )}

            <div className="mt-3 space-y-1.5">
              {company.phone && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Phone className="w-3.5 h-3.5 shrink-0" />
                  <a href={`tel:${company.phone}`} className="hover:text-primary transition-colors" dir="ltr">
                    {company.phone}
                  </a>
                </div>
              )}
              {company.website && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Globe className="w-3.5 h-3.5 shrink-0" />
                  <a
                    href={company.website.startsWith("http") ? company.website : `https://${company.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-primary transition-colors truncate"
                  >
                    {company.website.replace(/^https?:\/\//, "")}
                  </a>
                </div>
              )}
              {company.location && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{company.location}</span>
                </div>
              )}
              {(company.specialties || company.services || company.coverageTypes) && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Star className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{company.specialties || company.services || company.coverageTypes}</span>
                </div>
              )}
            </div>

            <Button
              variant="outline"
              size="sm"
              className="mt-4 w-full gap-1.5 text-xs"
              onClick={() => onRequestQuote(company, type)}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              Request Quote
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState({ type }: { type: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <Building2 className="w-12 h-12 text-muted-foreground/30 mb-4" />
      <p className="text-sm text-muted-foreground">
        No {type} listed yet. Check back soon!
      </p>
    </div>
  );
}

function QuoteRequestDialog({
  open,
  onOpenChange,
  company,
  companyType,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  company: any;
  companyType: "shipping" | "insurance" | "parts";
}) {
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [vehicleInfo, setVehicleInfo] = useState("");
  const [message, setMessage] = useState("");

  const utils = trpc.useUtils();
  const submitQuote = trpc.directory.submitQuoteRequest.useMutation({
    onSuccess: () => {
      toast.success("Quote request submitted!", {
        description: `Your request has been sent to ${company?.name}. We'll get back to you soon.`,
      });
      utils.directory.myQuoteRequests.invalidate();
      onOpenChange(false);
      setClientName("");
      setClientPhone("");
      setVehicleInfo("");
      setMessage("");
    },
    onError: (err) => {
      toast.error("Failed to submit quote request", { description: err.message });
    },
  });

  if (!company) return null;

  const typeLabels = { shipping: "Shipping", insurance: "Insurance", parts: "Spare Parts" };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-primary" />
            Request Quote
          </DialogTitle>
          <DialogDescription className="text-xs">
            Send a quote request to <strong>{company.name}</strong> ({typeLabels[companyType]})
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div>
            <Label className="text-xs">Your Name</Label>
            <Input
              placeholder="Full name"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              className="text-sm"
            />
          </div>
          <div>
            <Label className="text-xs">Phone Number</Label>
            <Input
              placeholder="+971 50 123 4567"
              value={clientPhone}
              onChange={(e) => setClientPhone(e.target.value)}
              className="text-sm"
              dir="ltr"
            />
          </div>
          <div>
            <Label className="text-xs">Vehicle Info (VIN, Year, Make, Model)</Label>
            <Input
              placeholder="e.g., 2023 Toyota Camry, VIN: 1HGBH41..."
              value={vehicleInfo}
              onChange={(e) => setVehicleInfo(e.target.value)}
              className="text-sm"
            />
          </div>
          <div>
            <Label className="text-xs">Message / Details</Label>
            <Textarea
              placeholder="Describe what you need..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="text-sm min-h-[80px]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            size="sm"
            className="gap-1.5"
            disabled={submitQuote.isPending || !clientName.trim()}
            onClick={() =>
              submitQuote.mutate({
                companyType,
                companyId: company.id,
                companyName: company.name,
                clientName: clientName.trim(),
                clientPhone: clientPhone.trim() || undefined,
                vehicleInfo: vehicleInfo.trim() || undefined,
                message: message.trim() || undefined,
              })
            }
          >
            {submitQuote.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            Send Request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function QuoteHistory() {
  const { data: quotes, isLoading } = trpc.directory.myQuoteRequests.useQuery();

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="w-5 h-5 animate-spin text-primary" />
      </div>
    );
  }

  if (!quotes || quotes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <History className="w-10 h-10 text-muted-foreground/30 mb-3" />
        <p className="text-sm text-muted-foreground">No quote requests yet.</p>
        <p className="text-xs text-muted-foreground mt-1">
          Browse companies above and click "Request Quote" to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {quotes.map((q: any) => (
        <Card key={q.id} className="glass-card border-border/40">
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm truncate">{q.companyName}</span>
                  <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${statusColors[q.status] || ""}`}>
                    {q.status}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    {new Date(q.createdAt).toLocaleDateString("en-AE", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                  {q.vehicleInfo && (
                    <div className="truncate">Vehicle: {q.vehicleInfo}</div>
                  )}
                  {q.message && (
                    <div className="truncate">Message: {q.message}</div>
                  )}
                </div>
              </div>
              {q.status === "responded" && (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function Services() {
  const { t } = useLanguage();
  const toggles = useFeatureToggles();

  // Quote request dialog state
  const [quoteDialogOpen, setQuoteDialogOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<any>(null);
  const [selectedType, setSelectedType] = useState<"shipping" | "insurance" | "parts">("shipping");
  const [showHistory, setShowHistory] = useState(false);

  const handleRequestQuote = (company: any, type: "shipping" | "insurance" | "parts") => {
    setSelectedCompany(company);
    setSelectedType(type);
    setQuoteDialogOpen(true);
  };

  // Only fetch data for enabled sections
  const shippingQuery = trpc.directory.listActiveShippingCompanies.useQuery(undefined, {
    enabled: toggles.shippingQuotesEnabled,
    staleTime: 60_000,
  });
  const insuranceQuery = trpc.directory.listActiveInsuranceCompanies.useQuery(undefined, {
    enabled: toggles.insuranceQuotesEnabled,
    staleTime: 60_000,
  });
  const partsQuery = trpc.directory.listActivePartsShops.useQuery(undefined, {
    enabled: toggles.partsQuotesEnabled,
    staleTime: 60_000,
  });

  // Determine which tabs to show
  const availableTabs: { value: string; label: string; icon: React.ElementType }[] = [];
  if (toggles.shippingQuotesEnabled) {
    availableTabs.push({ value: "shipping", label: "Shipping Companies", icon: Ship });
  }
  if (toggles.insuranceQuotesEnabled) {
    availableTabs.push({ value: "insurance", label: "Insurance Companies", icon: Shield });
  }
  if (toggles.partsQuotesEnabled) {
    availableTabs.push({ value: "parts", label: "Spare Parts Shops", icon: Wrench });
  }

  if (toggles.isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <main className="container py-6 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
      </div>
    );
  }

  // If ALL toggles are off, show a message
  if (availableTabs.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <main className="container py-6">
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Building2 className="w-16 h-16 text-muted-foreground/20 mb-6" />
            <h1 className="font-heading text-xl font-bold mb-2">Services Directory</h1>
            <p className="text-sm text-muted-foreground max-w-md">
              Service listings are not available at the moment. Please check back later.
            </p>
          </div>
        </main>
      </div>
    );
  }

  const defaultTab = availableTabs[0].value;

  return (
    <div className="min-h-screen bg-background">
      <main className="container py-6">
        <motion.div initial="hidden" animate="visible" custom={0} variants={fadeUp}>
          <div className="flex items-center justify-between mb-2">
            <h1 className="font-heading text-2xl sm:text-3xl font-bold">
              Services <span className="text-gradient">Directory</span>
            </h1>
            <Button
              variant={showHistory ? "default" : "outline"}
              size="sm"
              className="gap-1.5 text-xs"
              onClick={() => setShowHistory(!showHistory)}
            >
              <History className="w-3.5 h-3.5" />
              My Requests
            </Button>
          </div>
          <p className="text-muted-foreground text-sm mb-8 max-w-2xl">
            Trusted companies for shipping, insurance, and spare parts. Request quotes directly from this page.
          </p>
        </motion.div>

        {showHistory ? (
          <motion.div initial="hidden" animate="visible" custom={1} variants={fadeUp}>
            <div className="flex items-center gap-2 mb-4">
              <History className="w-4 h-4 text-primary" />
              <h2 className="font-heading font-semibold text-lg">My Quote Requests</h2>
            </div>
            <QuoteHistory />
          </motion.div>
        ) : (
          <Tabs defaultValue={defaultTab} className="space-y-6">
            <TabsList className="grid w-full h-auto gap-1 bg-secondary/30 p-1" style={{ gridTemplateColumns: `repeat(${availableTabs.length}, 1fr)` }}>
              {availableTabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <TabsTrigger key={tab.value} value={tab.value} className="text-xs gap-1.5 py-2">
                    <Icon className="w-3.5 h-3.5" /> {tab.label}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {/* Shipping Companies */}
            {toggles.shippingQuotesEnabled && (
              <TabsContent value="shipping">
                {shippingQuery.isLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : !shippingQuery.data || shippingQuery.data.length === 0 ? (
                  <EmptyState type="shipping companies" />
                ) : (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {shippingQuery.data.map((company: any) => (
                      <CompanyCard key={company.id} company={company} type="shipping" onRequestQuote={handleRequestQuote} />
                    ))}
                  </div>
                )}
                <div className="mt-6 p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-2">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Contact shipping companies directly for quotes. Prices vary by vehicle size, origin port, and season.
                  </p>
                </div>
              </TabsContent>
            )}

            {/* Insurance Companies */}
            {toggles.insuranceQuotesEnabled && (
              <TabsContent value="insurance">
                {insuranceQuery.isLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : !insuranceQuery.data || insuranceQuery.data.length === 0 ? (
                  <EmptyState type="insurance companies" />
                ) : (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {insuranceQuery.data.map((company: any) => (
                      <CompanyCard key={company.id} company={company} type="insurance" onRequestQuote={handleRequestQuote} />
                    ))}
                  </div>
                )}
                <div className="mt-6 p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-2">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Insurance is recommended for all imported vehicles. Contact companies for coverage options and rates.
                  </p>
                </div>
              </TabsContent>
            )}

            {/* Parts Shops */}
            {toggles.partsQuotesEnabled && (
              <TabsContent value="parts">
                {partsQuery.isLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : !partsQuery.data || partsQuery.data.length === 0 ? (
                  <EmptyState type="spare parts shops" />
                ) : (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {partsQuery.data.map((shop: any) => (
                      <CompanyCard key={shop.id} company={shop} type="parts" onRequestQuote={handleRequestQuote} />
                    ))}
                  </div>
                )}
                <div className="mt-6 p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-2">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Prices vary by vehicle make, model, and part condition (OEM vs aftermarket). Contact shops for exact quotes.
                  </p>
                </div>
              </TabsContent>
            )}
          </Tabs>
        )}
      </main>

      {/* Quote Request Dialog */}
      <QuoteRequestDialog
        open={quoteDialogOpen}
        onOpenChange={setQuoteDialogOpen}
        company={selectedCompany}
        companyType={selectedType}
      />
    </div>
  );
}
