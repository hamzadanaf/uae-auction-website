import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Calculator,
  TrendingUp,
  Zap,
  BarChart3,
  CheckCircle,
  ArrowRight,
  Sun,
  Moon,
  Globe,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function PublicHome() {
  const { t, lang, setLang, isRTL } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const features = [
    {
      icon: Calculator,
      title: t("home.feature1.title") || "VIN Decoder",
      description:
        t("home.feature1.desc") ||
        "Instantly decode any VIN and get detailed vehicle information from NHTSA and auction databases.",
    },
    {
      icon: TrendingUp,
      title: t("home.feature2.title") || "Accurate Calculations",
      description:
        t("home.feature2.desc") ||
        "Real auction fees, shipping rates, customs duties, and VAT calculations — no guesswork.",
    },
    {
      icon: Zap,
      title: t("home.feature3.title") || "AI Damage Analysis",
      description:
        t("home.feature3.desc") ||
        "Upload photos and get AI-powered damage assessment with repair cost estimates in AED.",
    },
    {
      icon: BarChart3,
      title: t("home.feature4.title") || "Profit Calculator",
      description:
        t("home.feature4.desc") ||
        "Compare total cost against UAE market price to calculate your profit margin instantly.",
    },
  ];

  const navItems = [
    { href: "/how-it-works", label: t("nav.howItWorks") || "How It Works" },
    { href: "/pricing", label: t("nav.pricing") || "Pricing" },
    { href: "/faq", label: t("nav.faq") || "FAQ" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center group-hover:bg-primary/25 transition-colors">
              <Calculator className="w-5 h-5 text-primary" />
            </div>
            <span className="font-heading font-bold text-lg">
              {t("nav.brand") || "AuctionCalc"}
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all"
              >
                {item.label}
              </Link>
            ))}

            {/* Divider */}
            <div className="w-px h-6 bg-border/50 mx-2" />

            {/* Language Toggle */}
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all"
              title={lang === "en" ? "التبديل إلى العربية" : "Switch to English"}
            >
              <Globe className="w-4 h-4" />
              <span className="text-xs font-semibold">{lang === "en" ? "AR" : "EN"}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all"
              title={theme === "dark" ? "Light mode" : "Dark mode"}
            >
              {theme === "dark" ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>

            {/* Login Button */}
            <Link href="/login">
              <Button variant="outline" size="sm" className="ml-2">
                {t("nav.login") || "Login"}
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="p-2 rounded-lg hover:bg-secondary/50"
            >
              <Globe className="w-4 h-4" />
            </button>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-secondary/50"
            >
              {theme === "dark" ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg hover:bg-secondary/50"
            >
              ☰
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border/50 bg-background">
            <div className="container py-4 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                >
                  {item.label}
                </Link>
              ))}
              <Link href="/login" className="block">
                <Button className="w-full" size="sm">
                  {t("nav.login") || "Login"}
                </Button>
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-16 border-b border-border/50">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <div className="inline-block mb-6 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
              <span className="text-sm font-semibold text-primary uppercase tracking-wide">
                {t("home.badge") || "For Serious Copart & IAAI Buyers"}
              </span>
            </div>

            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6 leading-tight">
              {t("home.hero.title1") || "Stop guessing."}
              <br />
              <span className="text-gradient">
                {t("home.hero.title2") || "Know your max bid"}
              </span>
              <br />
              {t("home.hero.title3") || "before you click \"Bid.\""}
            </h1>

            <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
              {t("home.hero.subtitle") ||
                "Decode VINs, calculate all costs (auction fees, shipping, customs, VAT), analyze damage with AI, and know your profit margin — all in seconds."}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Link href="/login">
                <Button size="lg" className="gap-2">
                  {t("home.hero.cta1") || "Get Started"}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="/how-it-works">
                <Button size="lg" variant="outline" className="gap-2">
                  {t("home.hero.cta2") || "See How It Works"}
                </Button>
              </Link>
            </div>

            <p className="text-sm text-muted-foreground">
              ✓ {t("home.hero.note") || "1 VIN evaluation included — no credit card required"}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-heading font-bold mb-4">
              {t("home.features.title") || "Everything You Need"}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t("home.features.subtitle") ||
                "Complete toolkit for calculating import costs and maximizing profit on every vehicle."}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="p-6 rounded-lg border border-border/50 hover:border-primary/50 transition-colors bg-card/50"
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-primary/5 border-y border-border/50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: t("home.benefits.b1.title") || "160+ Models",
                description:
                  t("home.benefits.b1.desc") ||
                  "Market pricing database covering most common US auction vehicles.",
              },
              {
                title: t("home.benefits.b2.title") || "382 Shipping Rates",
                description:
                  t("home.benefits.b2.desc") ||
                  "City-specific shipping quotes from major US auction locations.",
              },
              {
                title: t("home.benefits.b3.title") || "Real-Time Calculations",
                description:
                  t("home.benefits.b3.desc") ||
                  "Exact auction fees, customs duties, and VAT based on actual rates.",
              },
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <CheckCircle className="w-8 h-8 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground text-sm">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-heading font-bold mb-6">
              {t("home.cta.title") || "Ready to Calculate Smarter?"}
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              {t("home.cta.subtitle") ||
                "Join serious Copart and IAAI buyers who use AuctionCalc to make data-driven bidding decisions."}
            </p>
            <Link href="/login">
              <Button size="lg" className="gap-2">
                {t("home.cta.button") || "Get Started Now"}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 bg-card/50">
        <div className="container text-center text-sm text-muted-foreground">
          <p>
            © 2026 {t("nav.brand") || "AuctionCalc"}. {t("footer.rights") || "All rights reserved."}
          </p>
        </div>
      </footer>
    </div>
  );
}
