import { useLanguage } from "@/contexts/LanguageContext";
import PublicNavbar from "@/components/PublicNavbar";
import { motion } from "framer-motion";
import {
  Search,
  Calculator,
  Truck,
  FileText,
  CheckCircle,
  TrendingUp,
} from "lucide-react";

interface Step {
  icon: React.ElementType;
  title: string;
  description: string;
  details: string[];
}

export default function HowItWorks() {
  const { t, isRTL } = useLanguage();

  const steps: Step[] = [
    {
      icon: Search,
      title: t("howitworks.step1.title") || "1. Search & Decode VIN",
      description:
        t("howitworks.step1.desc") ||
        "Enter any 17-character VIN to instantly decode vehicle information from NHTSA database.",
      details: [
        t("howitworks.step1.detail1") || "Get make, model, year, engine size",
        t("howitworks.step1.detail2") || "View transmission and trim level",
        t("howitworks.step1.detail3") || "Search Copart & IAAI auctions",
      ],
    },
    {
      icon: Calculator,
      title: t("howitworks.step2.title") || "2. Calculate Total Cost",
      description:
        t("howitworks.step2.desc") ||
        "Automatically calculate all costs: auction fees, shipping, customs, VAT, and registration.",
      details: [
        t("howitworks.step2.detail1") || "Exact Copart & IAAI fee tables",
        t("howitworks.step2.detail2") || "382 city-specific shipping rates",
        t("howitworks.step2.detail3") || "UAE customs & VAT calculations",
      ],
    },
    {
      icon: FileText,
      title: t("howitworks.step3.title") || "3. AI Damage Analysis",
      description:
        t("howitworks.step3.desc") ||
        "Upload vehicle photos and get AI-powered damage assessment with repair cost estimates.",
      details: [
        t("howitworks.step3.detail1") || "Analyze damage per area",
        t("howitworks.step3.detail2") || "Get repair cost estimates in AED",
        t("howitworks.step3.detail3") || "Severity scoring (1-10)",
      ],
    },
    {
      icon: Truck,
      title: t("howitworks.step4.title") || "4. Shipping & Customs",
      description:
        t("howitworks.step4.desc") ||
        "Get accurate shipping quotes and understand all customs requirements for UAE import.",
      details: [
        t("howitworks.step4.detail1") || "Auto-fill shipping from auction location",
        t("howitworks.step4.detail2") || "5% customs duty calculation",
        t("howitworks.step4.detail3") || "4-6 week transit time estimate",
      ],
    },
    {
      icon: TrendingUp,
      title: t("howitworks.step5.title") || "5. Calculate Profit Margin",
      description:
        t("howitworks.step5.desc") ||
        "See your potential profit by comparing total cost against UAE market price.",
      details: [
        t("howitworks.step5.detail1") || "160+ vehicle models in database",
        t("howitworks.step5.detail2") || "Real-time market price estimates",
        t("howitworks.step5.detail3") || "ROI percentage calculation",
      ],
    },
    {
      icon: CheckCircle,
      title: t("howitworks.step6.title") || "6. Save & Export",
      description:
        t("howitworks.step6.desc") ||
        "Save deals to your queue and export professional PDF reports for analysis.",
      details: [
        t("howitworks.step6.detail1") || "Compare multiple vehicles",
        t("howitworks.step6.detail2") || "Export PDF cost breakdown",
        t("howitworks.step6.detail3") || "Track profit margins",
      ],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-background">
      <PublicNavbar />

      <div className="pt-20 pb-16">
        {/* Header */}
        <div className="bg-gradient-to-b from-primary/10 to-transparent py-12 border-b border-border/50">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4">
              {t("howitworks.title") || "How It Works"}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              {t("howitworks.subtitle") ||
                "A complete guide to calculating your US car import costs and profit margins in just 6 simple steps."}
            </p>
          </div>
        </div>

        {/* Steps */}
        <div className="container py-16">
          <motion.div
            className="space-y-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;

              return (
                <motion.div key={index} variants={itemVariants}>
                  <div
                    className={`grid grid-cols-1 md:grid-cols-2 gap-8 items-center ${
                      !isEven && !isRTL ? "md:grid-cols-2 md:[&>*:nth-child(1)]:order-2 md:[&>*:nth-child(2)]:order-1" : ""
                    }`}
                  >
                    {/* Icon & Title */}
                    <div className={`${!isEven && !isRTL ? "md:col-start-2" : ""}`}>
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-primary/10 border border-primary/20">
                            <Icon className="h-8 w-8 text-primary" />
                          </div>
                        </div>
                        <div>
                          <h2 className="text-2xl font-heading font-bold mb-2">
                            {step.title}
                          </h2>
                          <p className="text-muted-foreground mb-4">
                            {step.description}
                          </p>
                          <ul className="space-y-2">
                            {step.details.map((detail, i) => (
                              <li key={i} className="flex items-start gap-2">
                                <div className="h-2 w-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                                <span className="text-sm text-foreground">
                                  {detail}
                                </span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Visual Indicator */}
                    <div
                      className={`hidden md:flex items-center justify-center ${
                        !isEven && !isRTL ? "md:col-start-1" : ""
                      }`}
                    >
                      <div className="relative w-full h-64 rounded-lg bg-gradient-to-br from-primary/5 to-primary/10 border border-primary/20 flex items-center justify-center">
                        <div className="text-center">
                          <div className="text-6xl font-heading font-bold text-primary/20 mb-2">
                            {index + 1}
                          </div>
                          <Icon className="h-24 w-24 text-primary/20 mx-auto" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Connector Line */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center my-8">
                      <div className="h-12 w-1 bg-gradient-to-b from-primary/50 to-transparent rounded-full" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </motion.div>

          {/* Key Benefits */}
          <motion.div
            className="mt-20 p-8 rounded-lg bg-primary/5 border border-primary/20"
            variants={itemVariants}
            initial="hidden"
            animate="visible"
          >
            <h2 className="text-2xl font-heading font-bold mb-6">
              {t("howitworks.benefits.title") || "Why Use AuctionCalc?"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-semibold mb-2 text-foreground">
                  {t("howitworks.benefits.b1.title") || "Accurate Calculations"}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {t("howitworks.benefits.b1.desc") ||
                    "Real auction fee tables, shipping rates, and customs rates — no guesswork."}
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2 text-foreground">
                  {t("howitworks.benefits.b2.title") || "Save Time"}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {t("howitworks.benefits.b2.desc") ||
                    "Calculate costs in seconds instead of hours. Compare multiple vehicles instantly."}
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2 text-foreground">
                  {t("howitworks.benefits.b3.title") || "Better Decisions"}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {t("howitworks.benefits.b3.desc") ||
                    "AI damage analysis and profit calculations help you bid smarter."}
                </p>
              </div>
            </div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            className="mt-12 text-center"
            variants={itemVariants}
            initial="hidden"
            animate="visible"
          >
            <h2 className="text-2xl font-heading font-bold mb-4">
              {t("howitworks.cta.title") || "Ready to Get Started?"}
            </h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              {t("howitworks.cta.message") ||
                "Log in to your account and start calculating your first vehicle import today."}
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
