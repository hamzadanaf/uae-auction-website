/**
 * Vehicle Models — Brand Grid & Model Browser with Per-Year Pricing
 * Gulf Luxe Design: deep navy, emerald accents, frosted glass
 * Shows 48 brands in a responsive grid with logos, click to browse models with year-by-year pricing
 * Each model-year links to Dubizzle for real marketplace comparison
 */
import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { getBrandLogoUrl, REGION_COLORS, CATEGORY_INFO } from "@/lib/brandLogos";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  ArrowLeft,
  Car,
  DollarSign,
  Calendar,
  Tag,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Filter,
  X,
  Loader2,
  TrendingUp,
  Database,
  Globe2,
  Sparkles,
  ExternalLink,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type ViewMode = "brands" | "models";

export default function VehicleModels() {
  const { t } = useLanguage();
  const [viewMode, setViewMode] = useState<ViewMode>("brands");
  const [selectedBrand, setSelectedBrand] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [regionFilter, setRegionFilter] = useState<string>("");

  // Fetch brands
  const { data: brands, isLoading: brandsLoading } = trpc.vehicleModels.getBrands.useQuery();

  // Fetch models for selected brand
  const { data: models, isLoading: modelsLoading } = trpc.vehicleModels.getModelsByBrand.useQuery(
    { brand: selectedBrand },
    { enabled: !!selectedBrand }
  );

  // Fetch stats
  const { data: stats } = trpc.vehicleModels.getStats.useQuery();

  // Filter brands
  const filteredBrands = useMemo(() => {
    if (!brands) return [];
    return brands.filter((b) => {
      const matchesSearch = !searchQuery || b.brand.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRegion = !regionFilter || b.region === regionFilter;
      return matchesSearch && matchesRegion;
    });
  }, [brands, searchQuery, regionFilter]);

  // Group brands by region
  const brandsByRegion = useMemo(() => {
    const grouped: Record<string, typeof filteredBrands> = {};
    for (const b of filteredBrands) {
      if (!grouped[b.region]) grouped[b.region] = [];
      grouped[b.region].push(b);
    }
    return grouped;
  }, [filteredBrands]);

  const handleBrandClick = (brand: string) => {
    setSelectedBrand(brand);
    setViewMode("models");
  };

  const handleBack = () => {
    setViewMode("brands");
    setSelectedBrand("");
  };

  const formatPrice = (price: number | null) => {
    if (!price) return "—";
    return new Intl.NumberFormat("en-AE", { style: "currency", currency: "AED", maximumFractionDigits: 0 }).format(price);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="py-6 pb-12">
        <div className="container max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <AnimatePresence mode="wait">
              {viewMode === "brands" ? (
                <motion.div
                  key="brands-header"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
                      <Database className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h1 className="text-2xl font-heading font-bold text-foreground">
                        Vehicle Models Database
                      </h1>
                      <p className="text-sm text-muted-foreground">
                        Browse {stats?.totalBrands ?? "..."} brands and {stats?.totalModels ?? "..."} models with per-year UAE market prices
                      </p>
                    </div>
                  </div>

                  {/* Stats Bar */}
                  {stats && (
                    <div className="flex flex-wrap gap-4 mt-4 mb-6">
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/50">
                        <Car className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">{stats.totalBrands} Brands</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/50">
                        <Tag className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">{stats.totalModels} Models</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/50">
                        <Calendar className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">{stats.minYear}–{stats.maxYear}</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/50">
                        <Database className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">{stats.totalRows?.toLocaleString()} price entries</span>
                      </div>
                    </div>
                  )}

                  {/* Search & Filter */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search brands..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 bg-card border-border/50"
                      />
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery("")}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant={regionFilter === "" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setRegionFilter("")}
                        className="text-xs"
                      >
                        All
                      </Button>
                      {Object.entries(REGION_COLORS).map(([key, val]) => (
                        <Button
                          key={key}
                          variant={regionFilter === key ? "default" : "outline"}
                          size="sm"
                          onClick={() => setRegionFilter(regionFilter === key ? "" : key)}
                          className="text-xs"
                        >
                          {val.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="models-header"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <button
                    onClick={handleBack}
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to All Brands
                  </button>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-xl bg-card border border-border/50 flex items-center justify-center p-2 overflow-hidden">
                      <img
                        src={getBrandLogoUrl(selectedBrand, 120)}
                        alt={selectedBrand}
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none";
                        }}
                      />
                    </div>
                    <div>
                      <h1 className="text-2xl font-heading font-bold text-foreground">
                        {selectedBrand}
                      </h1>
                      <p className="text-sm text-muted-foreground">
                        {models?.length ?? "..."} models with per-year UAE market prices (2010–2026)
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Content */}
          <AnimatePresence mode="wait">
            {viewMode === "brands" ? (
              <motion.div
                key="brands-grid"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {brandsLoading ? (
                  <div className="flex items-center justify-center py-20">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : filteredBrands.length === 0 ? (
                  <div className="text-center py-20">
                    <Car className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                    <p className="text-muted-foreground">No brands found matching your search.</p>
                  </div>
                ) : regionFilter ? (
                  /* Flat grid when filtered by region */
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {filteredBrands.map((brand, i) => (
                      <BrandCard
                        key={brand.brand}
                        brand={brand}
                        index={i}
                        onClick={() => handleBrandClick(brand.brand)}
                      />
                    ))}
                  </div>
                ) : (
                  /* Grouped by region */
                  <div className="space-y-8">
                    {(["american", "japanese", "european", "korean"] as const).map((region) => {
                      const regionBrands = brandsByRegion[region];
                      if (!regionBrands || regionBrands.length === 0) return null;
                      const rc = REGION_COLORS[region];
                      return (
                        <div key={region}>
                          <div className="flex items-center gap-2 mb-4">
                            <Globe2 className={`w-4 h-4 ${rc.text}`} />
                            <h2 className="text-lg font-heading font-semibold text-foreground">
                              {rc.label} Brands
                            </h2>
                            <Badge variant="outline" className={`${rc.bg} ${rc.text} ${rc.border} text-xs`}>
                              {regionBrands.length}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                            {regionBrands.map((brand, i) => (
                              <BrandCard
                                key={brand.brand}
                                brand={brand}
                                index={i}
                                onClick={() => handleBrandClick(brand.brand)}
                              />
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="models-list"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {modelsLoading ? (
                  <div className="flex items-center justify-center py-20">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : !models || models.length === 0 ? (
                  <div className="text-center py-20">
                    <Car className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                    <p className="text-muted-foreground">No models found for this brand.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {models.map((model, i) => (
                      <ModelCard
                        key={model.model}
                        model={model}
                        brand={selectedBrand}
                        index={i}
                        formatPrice={formatPrice}
                      />
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/**
 * Brand Card Component
 */
function BrandCard({
  brand,
  index,
  onClick,
}: {
  brand: {
    brand: string;
    modelCount: number;
    totalRows: number;
    region: string;
    brandLogoUrl: string | null;
    dubizzleBrandSlug: string | null;
    minYear: number;
    maxYear: number;
  };
  index: number;
  onClick: () => void;
}) {
  const [imgError, setImgError] = useState(false);
  const rc = REGION_COLORS[brand.region] ?? REGION_COLORS.american;

  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.5), duration: 0.3 }}
      onClick={onClick}
      className="group relative flex flex-col items-center gap-3 p-5 rounded-xl bg-card border border-border/50 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 cursor-pointer"
    >
      {/* Logo */}
      <div className="w-14 h-14 rounded-xl bg-background/80 border border-border/30 flex items-center justify-center p-2 group-hover:scale-110 transition-transform duration-300 overflow-hidden">
        {!imgError ? (
          <img
            src={getBrandLogoUrl(brand.brand, 100)}
            alt={brand.brand}
            className="w-full h-full object-contain"
            loading="lazy"
            onError={() => setImgError(true)}
          />
        ) : (
          <Car className="w-6 h-6 text-muted-foreground" />
        )}
      </div>

      {/* Brand Name */}
      <div className="text-center">
        <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
          {brand.brand}
        </h3>
        <p className="text-xs text-muted-foreground mt-0.5">
          {brand.modelCount} {brand.modelCount === 1 ? "model" : "models"}
        </p>
        <p className="text-[10px] text-muted-foreground/70">
          {brand.minYear}–{brand.maxYear}
        </p>
      </div>

      {/* Region Badge */}
      <Badge
        variant="outline"
        className={`${rc.bg} ${rc.text} ${rc.border} text-[10px] px-1.5 py-0 absolute top-2 right-2`}
      >
        {rc.label.charAt(0)}
      </Badge>

      {/* Arrow */}
      <ChevronRight className="w-4 h-4 text-muted-foreground/0 group-hover:text-primary absolute right-3 top-1/2 -translate-y-1/2 group-hover:translate-x-0 -translate-x-2 transition-all duration-300" />
    </motion.button>
  );
}

/**
 * Build Dubizzle URL for a specific brand/model/year
 */
function getDubizzleUrl(brandSlug: string | null, modelSlug: string | null, year?: number): string | null {
  if (!brandSlug || !modelSlug) return null;
  if (year) {
    return `https://uae.dubizzle.com/motors/used-cars/${brandSlug}/${modelSlug}/${year}/`;
  }
  return `https://uae.dubizzle.com/motors/used-cars/${brandSlug}/${modelSlug}/`;
}

/**
 * Model Card Component — shows model with expandable per-year pricing table
 */
function ModelCard({
  model,
  brand,
  index,
  formatPrice,
}: {
  model: {
    model: string;
    category: string;
    region: string;
    dubizzleBrandSlug: string | null;
    dubizzleModelSlug: string | null;
    years: Array<{
      id: number;
      year: number;
      uaeMarketPriceLow: number | null;
      uaeMarketPriceMid: number | null;
      uaeMarketPriceHigh: number | null;
      auctionAvgPriceUSD: number | null;
    }>;
  };
  brand: string;
  index: number;
  formatPrice: (p: number | null) => string;
}) {
  const [expanded, setExpanded] = useState(false);
  const catInfo = CATEGORY_INFO[model.category] ?? { emoji: "🚗", label: model.category };
  const rc = REGION_COLORS[model.region] ?? REGION_COLORS.american;

  // Get the latest year's price for the summary
  const latestYear = model.years[model.years.length - 1];
  const oldestYear = model.years[0];
  const dubizzleBaseUrl = getDubizzleUrl(model.dubizzleBrandSlug, model.dubizzleModelSlug);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.05, 0.8), duration: 0.3 }}
      className="rounded-xl bg-card border border-border/50 hover:border-primary/30 transition-all duration-300 overflow-hidden"
    >
      {/* Summary Header — always visible */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-5 text-left flex items-center gap-4 cursor-pointer hover:bg-accent/5 transition-colors"
      >
        <div className="flex-1">
          <div className="flex items-start justify-between mb-1">
            <h3 className="text-lg font-heading font-bold text-foreground">
              {model.model}
            </h3>
            <Badge variant="outline" className={`${rc.bg} ${rc.text} ${rc.border} text-xs shrink-0 ml-2`}>
              {catInfo.emoji} {catInfo.label}
            </Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {oldestYear?.year}–{latestYear?.year}
            </span>
            <span className="flex items-center gap-1">
              <Tag className="w-3.5 h-3.5" />
              {model.years.length} years
            </span>
            {latestYear && (
              <span className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5" />
                {formatPrice(latestYear.uaeMarketPriceLow)} – {formatPrice(latestYear.uaeMarketPriceHigh)}
                <span className="text-xs text-muted-foreground/70">({latestYear.year})</span>
              </span>
            )}
          </div>
        </div>
        <div className="shrink-0">
          {expanded ? (
            <ChevronUp className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          )}
        </div>
      </button>

      {/* Expanded Per-Year Pricing Table */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5">
              {/* Dubizzle link */}
              {dubizzleBaseUrl && (
                <a
                  href={dubizzleBaseUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 mb-3 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  View all {brand} {model.model} on Dubizzle
                </a>
              )}

              {/* Price Table */}
              <div className="rounded-lg border border-border/50 overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-accent/10 border-b border-border/50">
                      <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">Year</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">Low (AED)</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">Mid (AED)</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">High (AED)</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">Auction (USD)</th>
                      <th className="px-3 py-2 text-center text-xs font-medium text-muted-foreground">Dubizzle</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...model.years].reverse().map((yearData, yi) => {
                      const dubUrl = getDubizzleUrl(model.dubizzleBrandSlug, model.dubizzleModelSlug, yearData.year);
                      return (
                        <tr
                          key={yearData.year}
                          className={`border-b border-border/30 last:border-0 hover:bg-accent/5 transition-colors ${yi === 0 ? "bg-primary/5" : ""}`}
                        >
                          <td className="px-3 py-2 font-medium text-foreground">
                            {yearData.year}
                            {yi === 0 && (
                              <Badge variant="outline" className="ml-1.5 text-[9px] px-1 py-0 text-primary border-primary/30">
                                Latest
                              </Badge>
                            )}
                          </td>
                          <td className="px-3 py-2 text-right text-muted-foreground tabular-nums">
                            {yearData.uaeMarketPriceLow?.toLocaleString() ?? "—"}
                          </td>
                          <td className="px-3 py-2 text-right font-semibold text-primary tabular-nums">
                            {yearData.uaeMarketPriceMid?.toLocaleString() ?? "—"}
                          </td>
                          <td className="px-3 py-2 text-right text-muted-foreground tabular-nums">
                            {yearData.uaeMarketPriceHigh?.toLocaleString() ?? "—"}
                          </td>
                          <td className="px-3 py-2 text-right text-muted-foreground tabular-nums">
                            {yearData.auctionAvgPriceUSD ? `$${yearData.auctionAvgPriceUSD.toLocaleString()}` : "—"}
                          </td>
                          <td className="px-3 py-2 text-center">
                            {dubUrl ? (
                              <a
                                href={dubUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center justify-center w-7 h-7 rounded-md hover:bg-primary/10 text-primary transition-colors"
                                title={`View ${yearData.year} ${brand} ${model.model} on Dubizzle`}
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            ) : (
                              <span className="text-muted-foreground/30">—</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
