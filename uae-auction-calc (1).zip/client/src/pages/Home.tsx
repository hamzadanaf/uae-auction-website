/**
 * Landing Page — US-to-UAE Car Import Calculator
 * Gulf Luxe Design: deep navy, emerald accents, frosted glass
 */
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Calculator,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
  BarChart3,
  Zap,
  Car,
  Ship,
  Wrench,
  MapPin,
  Sparkles,
  Search,
} from "lucide-react";

const HERO_IMG =
  "https://private-us-east-1.manuscdn.com/sessionFile/GXIOzFzlTnmftgpUifna0S/sandbox/heMidtopssZIZTQVhWntm4-img-1_1770976234000_na1fn_aGVyby1iZw.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR1hJT3pGemxUbm1mdGdwVWlmbmEwUy9zYW5kYm94L2hlTWlkdG9wc3NaSVpUUVZoV250bTQtaW1nLTFfMTc3MDk3NjIzNDAwMF9uYTFmbl9hR1Z5YnkxaVp3LmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=k4pizqjsiGStN8wz~DvlzhMRVzbvnafVJYWjHNMAC5hTUlXRGLYwyzrr9AkGOsByokl1z7lP6rHMiVwYb5bu28vqZNzc7dMradDop2kZIUdNWxuGkH7SyNazm0VzBtYI65i~YW1E0w4u~-a4t4AlVSOhucJfIUOSTHF9kCxK9XryNvezwfdd5zH2WLkqFrdNK~1Dxh~cTkrIjoSxu4-WOlUgT2OJf~KE1EKfvXCNdbNy4kBhHFWqJ8Ll1vACdTn7C~PjH5F6opoiygDr0tU-c6O7NCCOOATGPY~wY5wv1XAJuMu9muzvcxyD5VX~EU7ZQvhCsKcqRcD6pA51TQdtNQ__";

const CALC_IMG =
  "https://private-us-east-1.manuscdn.com/sessionFile/GXIOzFzlTnmftgpUifna0S/sandbox/heMidtopssZIZTQVhWntm4_1770976241287_na1fn_cHJvZml0LWlsbHVzdHJhdGlvbg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvR1hJT3pGemxUbm1mdGdwVWlmbmEwUy9zYW5kYm94L2hlTWlkdG9wc3NaSVpUUVZoV250bTQtaW1nLTRfMTc3MDk3NjIzNzAwMF9uYTFmbl9kV0ZsTFhOcmVXeHBibVUuanBnP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=wFXi5BaNoOFJX-pW7ES~lVj8wqF0iV863IPrg8V8vYFS4az3EPGIIrur0IKJXekl4X9u4cefQM9JvsgJOafi26mheszvFW4jgRcQAeiptcc~3Zex1uVUW~l49aMKVN13TCeQNXHOanw0LhJeroq3CsJQUBdJMtiHRpGqaOzu-qhdu-ftFPfBgSFbxx-n63h58p~xziT-NK1P~NJanssRkEkekqbmXVa5BDo1oCM~gDdCVRZ5wz~CVHeRf8jHjWuleHOcq2MZqDkKxzHYIcg09vCq6ncIK~73yrtMUdrZUIfjU-y14z7kCDLcIchgmt7rSz6EBSplXXnctj7uNKtWdg__";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: "easeOut" as const },
  }),
};

export default function Home() {
  let { user, loading, error, isAuthenticated, logout } = useAuth();
  const { t, isRTL } = useLanguage();

  const features = [
    { icon: Car, title: t("feat.vinDecoder"), desc: t("feat.vinDecoderDesc") },
    { icon: Calculator, title: t("feat.auctionFees"), desc: t("feat.auctionFeesDesc") },
    { icon: Ship, title: t("feat.shippingCalc"), desc: t("feat.shippingCalcDesc") },
    { icon: ShieldCheck, title: t("feat.customsVat"), desc: t("feat.customsVatDesc") },
    { icon: Wrench, title: t("feat.spareParts"), desc: t("feat.sparePartsDesc") },
    { icon: MapPin, title: t("feat.emirateReg"), desc: t("feat.emirateRegDesc") },
    { icon: Sparkles, title: t("feat.autoMarket"), desc: t("feat.autoMarketDesc") },
    { icon: Search, title: t("feat.marketplace"), desc: t("feat.marketplaceDesc") },
  ];

  const stats = [
    { value: "VIN", label: t("stats.autoDecode") },
    { value: "160+", label: t("stats.carModels") },
    { value: "~10.25%", label: t("stats.importTax") },
    { value: "7", label: t("stats.emirates") },
  ];

  const steps = [
    { step: "1", title: t("home.step1"), desc: t("home.step1Desc") },
    { step: "2", title: t("home.step2"), desc: t("home.step2Desc") },
    { step: "3", title: t("home.step3"), desc: t("home.step3Desc") },
    { step: "4", title: t("home.step4"), desc: t("home.step4Desc") },
    { step: "5", title: t("home.step5"), desc: t("home.step5Desc") },
    { step: "6", title: t("home.step6"), desc: t("home.step6Desc") },
    { step: "7", title: t("home.step7"), desc: t("home.step7Desc") },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="Luxury car auction showroom" className="w-full h-full object-cover" />
          <div className={`absolute inset-0 ${isRTL ? "bg-gradient-to-l" : "bg-gradient-to-r"} from-background via-background/85 to-background/40`} />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>

        <div className="container relative z-10 pt-24 pb-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="max-w-xl">
              <motion.div
                initial="hidden" animate="visible" custom={0} variants={fadeUp}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium mb-6"
              >
                <Zap className="w-3.5 h-3.5" />
                {t("home.badge")}
              </motion.div>

              <motion.h1
                initial="hidden" animate="visible" custom={1} variants={fadeUp}
                className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight mb-6 text-foreground"
              >
                {t("home.title1")}{" "}
                <span className="text-gradient">{t("home.titleAccent")}</span>
                <br />
                {t("home.title2")}
              </motion.h1>

              <motion.p
                initial="hidden" animate="visible" custom={2} variants={fadeUp}
                className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-md"
              >
                {t("home.subtitle")}
              </motion.p>

              <motion.div
                initial="hidden" animate="visible" custom={3} variants={fadeUp}
                className="flex flex-wrap gap-4"
              >
                <Link href="/calculator">
                  <Button
                    size="lg"
                    className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 h-12 text-base glow-emerald"
                  >
                    <Calculator className={`w-5 h-5 ${isRTL ? "ml-2" : "mr-2"}`} />
                    {t("home.startCalc")}
                    <ArrowRight className={`w-4 h-4 ${isRTL ? "mr-2 rotate-180" : "ml-2"}`} />
                  </Button>
                </Link>
                <Link href="/fee-guide">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-border bg-secondary/50 text-foreground hover:bg-secondary h-12 text-base"
                  >
                    <BarChart3 className={`w-5 h-5 ${isRTL ? "ml-2" : "mr-2"}`} />
                    {t("home.feeRef")}
                  </Button>
                </Link>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.8, ease: "easeOut" as const }}
              className="hidden lg:flex justify-center"
            >
              <div className="w-[380px] h-[320px] rounded-2xl glass-card p-6 glow-emerald">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">{t("home.quickExample")}</div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.bid")}</span><span className="text-foreground font-medium">$5,000</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.auctionFees")}</span><span className="text-foreground font-medium">$905</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.shipping")}</span><span className="text-foreground font-medium">$1,200</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.customsVat")}</span><span className="text-foreground font-medium">AED 2,670</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.parts")}</span><span className="text-foreground font-medium">AED 3,500</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{t("home.registration")}</span><span className="text-foreground font-medium">AED 630</span></div>
                  <div className="border-t border-border/30 pt-2 mt-2 flex justify-between font-bold"><span className="text-foreground">{t("home.total")}</span><span className="text-primary">AED 32,860</span></div>
                  <div className="flex justify-between font-bold"><span className="text-foreground">{t("home.uaeMarket")}</span><span className="text-primary">AED 45,000</span></div>
                  <div className="text-center mt-3 py-2 rounded-lg bg-primary/10 border border-primary/20">
                    <span className="text-primary font-bold text-lg">+37% {t("home.roi")}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="relative z-10 -mt-8">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass-card rounded-2xl p-6 glow-emerald"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="font-heading text-3xl font-bold text-gradient mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}
            className="text-center mb-12"
          >
            <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4">
              {t("home.howItWorks")} <span className="text-gradient">{t("home.howItWorksAccent")}</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              {t("home.howItWorksDesc")}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
            {steps.map((item, i) => (
              <motion.div
                key={item.step}
                initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i} variants={fadeUp}
                className="flex items-start gap-3 p-4 rounded-xl bg-secondary/20 border border-border/20"
              >
                <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                  {item.step}
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-sm mb-0.5">{item.title}</h3>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-secondary/10">
        <div className="container">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}
            className="text-center mb-16"
          >
            <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4">
              {t("home.builtFor")} <span className="text-gradient">{t("home.builtForAccent")}</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              {t("home.builtForDesc")}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i} variants={fadeUp}
                  className="glass-card glass-card-hover rounded-xl p-6 transition-all duration-300"
                >
                  <div className="w-11 h-11 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}
            className="text-center max-w-2xl mx-auto"
          >
            <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4">
              {t("home.readyTo")} <span className="text-gradient">{t("home.readyToAccent")}</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              {t("home.ctaDesc")}
            </p>
            <Link href="/calculator">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-10 h-14 text-lg glow-emerald">
                <Calculator className={`w-5 h-5 ${isRTL ? "ml-2" : "mr-2"}`} />
                {t("home.openCalc")}
                <ArrowRight className={`w-5 h-5 ${isRTL ? "mr-2 rotate-180" : "ml-2"}`} />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/20 py-8">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            <span className="font-heading font-bold text-sm">{t("nav.brand")} {t("nav.brandAccent")}</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {t("footer.disclaimer")}
          </p>
          <p className="text-xs text-muted-foreground">
            Powered by Hamza Al Danaf
          </p>
        </div>
      </footer>
    </div>
  );
}
