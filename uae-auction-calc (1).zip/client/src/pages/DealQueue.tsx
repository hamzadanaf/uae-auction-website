/**
 * Deal Queue — Save & Compare multiple VIN calculations side-by-side
 */
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { formatAED, formatUSD, USD_TO_AED } from "@/lib/auctionData";
import { motion, AnimatePresence } from "framer-motion";
import {
  Trash2,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Car,
  Loader2,
  FileText,
  StickyNote,
  Check,
  X,
  ArrowUpDown,
  Eye,
  Columns,
  List,
  AlertTriangle,
  LogIn,
  ShieldCheck,
  DollarSign,
  Sparkles,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

type SortField = "date" | "profit" | "margin" | "cost" | "bid";
type SortDir = "asc" | "desc";
type ViewMode = "grid" | "compare";

export default function DealQueuePage() {
  const { t } = useLanguage();
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [sortField, setSortField] = useState<SortField>("date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [noteText, setNoteText] = useState("");

  const { data: deals, isLoading, refetch } = trpc.dealQueue.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const deleteMutation = trpc.dealQueue.delete.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Deal removed from queue");
    },
  });

  const updateNotesMutation = trpc.dealQueue.updateNotes.useMutation({
    onSuccess: () => {
      refetch();
      setEditingNoteId(null);
      toast.success("Notes updated");
    },
  });

  const sortedDeals = useMemo(() => {
    if (!deals) return [];
    const sorted = [...deals].sort((a, b) => {
      switch (sortField) {
        case "profit":
          return a.estimatedProfitAED - b.estimatedProfitAED;
        case "margin":
          return a.profitMarginPercent - b.profitMarginPercent;
        case "cost":
          return a.totalCostAED - b.totalCostAED;
        case "bid":
          return a.bidAmountUSD - b.bidAmountUSD;
        default:
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }
    });
    return sortDir === "desc" ? sorted.reverse() : sorted;
  }, [deals, sortField, sortDir]);

  const comparedDeals = useMemo(() => {
    if (!deals) return [];
    return deals.filter((d) => compareIds.includes(d.id));
  }, [deals, compareIds]);

  const toggleCompare = (id: number) => {
    setCompareIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : prev.length < 4 ? [...prev, id] : prev
    );
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("desc");
    }
  };

  const handlePdfExport = async (deal: any) => {
    try {
      const batchInput = encodeURIComponent(
        JSON.stringify({
          "0": {
            json: {
              vin: deal.vin,
              vehicleInfo: deal.vehicleInfo,
              auctionHouse: deal.auctionHouse,
              bidAmountUSD: deal.bidAmountUSD,
              shippingCostUSD: deal.shippingCostUSD,
              mileage: deal.mileage,
              uaeMarketPriceAED: deal.uaeMarketPriceAED,
              emirate: deal.emirate,
              includeRegistration: deal.includeRegistration === 1,
              costBreakdown: deal.costBreakdown,
              damageAnalysis: deal.damageAnalysis || undefined,
              photoUrl: deal.photoUrl || undefined,
            },
          },
        })
      );

      const res = await fetch(`/api/trpc/pdfExport.generateReport?batch=1`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ "0": { json: {
          vin: deal.vin,
          vehicleInfo: deal.vehicleInfo,
          auctionHouse: deal.auctionHouse,
          bidAmountUSD: deal.bidAmountUSD,
          shippingCostUSD: deal.shippingCostUSD,
          mileage: deal.mileage,
          uaeMarketPriceAED: deal.uaeMarketPriceAED,
          emirate: deal.emirate,
          includeRegistration: deal.includeRegistration === 1,
          costBreakdown: deal.costBreakdown,
          damageAnalysis: deal.damageAnalysis || undefined,
          photoUrl: deal.photoUrl || undefined,
        }}}),
      });

      const data = await res.json();
      const html = data?.[0]?.result?.data?.json?.html;
      if (!html) throw new Error("Failed to generate report");

      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(html);
        printWindow.document.close();
        setTimeout(() => printWindow.print(), 500);
      }
    } catch (err) {
      toast.error("Failed to generate PDF report");
    }
  };

  // ─── Auth Gate ───
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="py-6 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <div className="py-6 container max-w-lg">
          <Card className="glass-card border-border/50">
            <CardContent className="p-8 text-center">
              <LogIn className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2 className="font-heading text-xl font-bold mb-2">Sign In Required</h2>
              <p className="text-muted-foreground mb-6">
                Sign in to save deals and compare them side-by-side.
              </p>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-primary hover:bg-primary/90"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="py-6 container max-w-7xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-heading text-3xl font-bold">
               {t("dealQueue.title")} <span className="text-gradient">{t("dealQueue.titleAccent")}</span>
            </h1>
            <p className="text-muted-foreground mt-1">
              {deals?.length || 0} saved deal{(deals?.length || 0) !== 1 ? "s" : ""} — compare side-by-side to find the best ROI
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* View Toggle */}
            <div className="flex items-center bg-secondary/50 rounded-lg p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === "grid" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("compare")}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === "compare" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Columns className="w-4 h-4" />
              </button>
            </div>

            {/* Sort Buttons */}
            {(["date", "profit", "margin", "cost", "bid"] as SortField[]).map((f) => (
              <Button
                key={f}
                variant="outline"
                size="sm"
                onClick={() => handleSort(f)}
                className={`text-xs ${sortField === f ? "border-primary/50 text-primary" : ""}`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
                {sortField === f && (
                  <ArrowUpDown className="w-3 h-3 ml-1" />
                )}
              </Button>
            ))}
          </div>
        </div>

        {/* Compare Bar */}
        <AnimatePresence>
          {compareIds.length > 0 && viewMode === "grid" && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-6 p-4 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-between"
            >
              <span className="text-sm font-medium">
                <Columns className="w-4 h-4 inline mr-2" />
                {compareIds.length} deal{compareIds.length !== 1 ? "s" : ""} selected for comparison (max 4)
              </span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setCompareIds([])}
                >
                  Clear
                </Button>
                <Button
                  size="sm"
                  onClick={() => setViewMode("compare")}
                  className="bg-primary hover:bg-primary/90"
                >
                  Compare Now
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading */}
        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        )}

        {/* Empty State */}
        {!isLoading && (!deals || deals.length === 0) && (
          <Card className="glass-card border-border/50">
            <CardContent className="p-12 text-center">
              <Car className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="font-heading text-xl font-bold mb-2">No Deals Saved Yet</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                {t("dealQueue.subtitle")}
              </p>
              <Button
                onClick={() => (window.location.href = "/calculator")}
                className="bg-primary hover:bg-primary/90"
              >
                Open Calculator
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Compare View */}
        {viewMode === "compare" && comparedDeals.length > 0 && (() => {
          // Pre-compute best/worst for highlighting
          const bestIdx = (arr: number[], mode: "max" | "min") => {
            if (arr.length === 0) return -1;
            let idx = 0;
            for (let i = 1; i < arr.length; i++) {
              if (mode === "max" ? arr[i] > arr[idx] : arr[i] < arr[idx]) idx = i;
            }
            return idx;
          };

          const profitMargins = comparedDeals.map((d) => d.profitMarginPercent);
          const profits = comparedDeals.map((d) => d.estimatedProfitAED);
          const totalCosts = comparedDeals.map((d) => d.totalCostAED);
          const bidAmounts = comparedDeals.map((d) => d.bidAmountUSD);
          const mileages = comparedDeals.map((d) => d.mileage);
          const damageScores = comparedDeals.map((d) => d.damageAnalysis?.overallSeverityScore ?? 99);
          const marketPrices = comparedDeals.map((d) => d.uaeMarketPriceAED);

          const bestProfitIdx = bestIdx(profitMargins, "max");
          const bestCostIdx = bestIdx(totalCosts, "min");
          const bestBidIdx = bestIdx(bidAmounts, "min");
          const bestMileageIdx = bestIdx(mileages, "min");
          const bestDamageIdx = bestIdx(damageScores, "min");
          const bestMarketIdx = bestIdx(marketPrices, "max");

          type CompRow = {
            label: string;
            icon?: string;
            getValue: (d: any) => string;
            getNumeric?: (d: any) => number;
            bestMode?: "max" | "min";
            section?: boolean;
            highlight?: boolean;
          };

          const rows: CompRow[] = [
            { label: "VEHICLE INFO", section: true, getValue: () => "" },
            { label: "VIN", getValue: (d: any) => d.vin },
            { label: "Mileage", getValue: (d: any) => `${d.mileage.toLocaleString()} mi`, getNumeric: (d: any) => d.mileage, bestMode: "min" },
            { label: "Auction", getValue: (d: any) => d.auctionHouse.toUpperCase() },
            { label: "COST BREAKDOWN", section: true, getValue: () => "" },
            { label: "Bid Amount", icon: "💰", getValue: (d: any) => formatUSD(d.bidAmountUSD), getNumeric: (d: any) => d.bidAmountUSD, bestMode: "min", highlight: true },
            { label: "Auction Fees", getValue: (d: any) => formatUSD(d.costBreakdown?.auctionFeesUSD || 0), getNumeric: (d: any) => d.costBreakdown?.auctionFeesUSD || 0, bestMode: "min" },
            { label: "Shipping", getValue: (d: any) => formatUSD(d.shippingCostUSD), getNumeric: (d: any) => d.shippingCostUSD, bestMode: "min" },
            { label: "Total Landed (AED)", getValue: (d: any) => formatAED(d.costBreakdown?.totalLandedAED || 0), getNumeric: (d: any) => d.costBreakdown?.totalLandedAED || 0, bestMode: "min" },
            { label: "Customs + VAT", getValue: (d: any) => formatAED((d.costBreakdown?.customsDutyAED || 0) + (d.costBreakdown?.vatAED || 0)), getNumeric: (d: any) => (d.costBreakdown?.customsDutyAED || 0) + (d.costBreakdown?.vatAED || 0), bestMode: "min" },
            { label: "Parts & Repairs", getValue: (d: any) => formatAED(d.costBreakdown?.partsAED || 0), getNumeric: (d: any) => d.costBreakdown?.partsAED || 0, bestMode: "min" },
            { label: "Total Investment", icon: "📊", getValue: (d: any) => formatAED(d.totalCostAED), getNumeric: (d: any) => d.totalCostAED, bestMode: "min", highlight: true },
            { label: "PROFITABILITY", section: true, getValue: () => "" },
            { label: "UAE Market Price", getValue: (d: any) => formatAED(d.uaeMarketPriceAED), getNumeric: (d: any) => d.uaeMarketPriceAED, bestMode: "max", highlight: true },
            { label: "Estimated Profit", icon: "📈", getValue: (d: any) => formatAED(d.estimatedProfitAED), getNumeric: (d: any) => d.estimatedProfitAED, bestMode: "max", highlight: true },
            { label: "Profit Margin", icon: "🏆", getValue: (d: any) => `${d.profitMarginPercent}%`, getNumeric: (d: any) => d.profitMarginPercent, bestMode: "max", highlight: true },
            { label: "DAMAGE ASSESSMENT", section: true, getValue: () => "" },
            {
              label: "AI Damage Score",
              icon: "🔍",
              getValue: (d: any) =>
                d.damageAnalysis
                  ? `${d.damageAnalysis.overallSeverityScore}/10 — ${d.damageAnalysis.overallSeverity.toUpperCase()}`
                  : "N/A",
              getNumeric: (d: any) => d.damageAnalysis?.overallSeverityScore ?? 99,
              bestMode: "min",
            },
            {
              label: "Est. Repair Cost (AED)",
              getValue: (d: any) =>
                d.damageAnalysis?.estimatedTotalRepairAED
                  ? `${formatAED(d.damageAnalysis.estimatedTotalRepairAED.low)} - ${formatAED(d.damageAnalysis.estimatedTotalRepairAED.high)}`
                  : d.damageAnalysis?.estimatedTotalRepairUSD
                  ? `${formatUSD(d.damageAnalysis.estimatedTotalRepairUSD.low)} - ${formatUSD(d.damageAnalysis.estimatedTotalRepairUSD.high)}`
                  : "N/A",
              getNumeric: (d: any) => d.damageAnalysis?.estimatedTotalRepairAED?.low ?? d.damageAnalysis?.estimatedTotalRepairUSD?.low ?? 99999,
              bestMode: "min",
            },
          ];

          return (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading text-lg font-semibold">
                Side-by-Side <span className="text-gradient">Comparison</span>
              </h2>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setViewMode("grid");
                  setCompareIds([]);
                }}
              >
                Back to Grid
              </Button>
            </div>

            {/* Winner Badges */}
            {comparedDeals.length >= 2 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                {[
                  { label: "Best ROI", idx: bestProfitIdx, icon: "🏆", value: `${profitMargins[bestProfitIdx]}%`, color: "emerald" },
                  { label: "Lowest Cost", idx: bestCostIdx, icon: "💰", value: formatAED(totalCosts[bestCostIdx]), color: "blue" },
                  { label: "Least Damage", idx: bestDamageIdx, icon: "🛡️", value: damageScores[bestDamageIdx] < 99 ? `${damageScores[bestDamageIdx]}/10` : "N/A", color: "amber" },
                  { label: "Lowest Bid", idx: bestBidIdx, icon: "🔨", value: formatUSD(bidAmounts[bestBidIdx]), color: "purple" },
                ].map((badge) => {
                  const deal = comparedDeals[badge.idx];
                  if (!deal) return null;
                  const colorMap: Record<string, string> = {
                    emerald: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400",
                    blue: "bg-blue-500/10 border-blue-500/30 text-blue-400",
                    amber: "bg-amber-500/10 border-amber-500/30 text-amber-400",
                    purple: "bg-purple-500/10 border-purple-500/30 text-purple-400",
                  };
                  return (
                    <div key={badge.label} className={`rounded-xl border p-3 ${colorMap[badge.color]}`}>
                      <div className="text-lg mb-1">{badge.icon}</div>
                      <div className="text-[10px] uppercase font-medium opacity-70">{badge.label}</div>
                      <div className="font-heading font-bold text-sm">
                        {deal.vehicleInfo.year} {deal.vehicleInfo.make}
                      </div>
                      <div className="text-xs font-semibold mt-0.5">{badge.value}</div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="overflow-x-auto rounded-xl border border-border/50">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-secondary/30">
                    <th className="p-3 text-left text-xs text-muted-foreground uppercase font-medium w-48 sticky left-0 bg-secondary/30 z-10">
                      Metric
                    </th>
                    {comparedDeals.map((deal, di) => {
                      const isBestROI = di === bestProfitIdx;
                      return (
                        <th key={deal.id} className="p-3 text-center min-w-[220px] relative">
                          {isBestROI && comparedDeals.length >= 2 && (
                            <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-b-md uppercase tracking-wider">
                              Best Deal
                            </div>
                          )}
                          <div className={`flex flex-col items-center gap-1 pt-1 ${isBestROI ? "ring-2 ring-emerald-500/30 rounded-lg p-2" : ""}`}>
                            {deal.photoUrl && (
                              <img
                                src={deal.photoUrl}
                                alt=""
                                className="w-24 h-16 object-cover rounded-md"
                              />
                            )}
                            <span className="font-heading text-sm font-semibold">
                              {deal.vehicleInfo.year} {deal.vehicleInfo.make}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {deal.vehicleInfo.model}
                            </span>
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => {
                    if (row.section) {
                      return (
                        <tr key={row.label} className="bg-primary/5">
                          <td
                            colSpan={comparedDeals.length + 1}
                            className="p-2 px-3 text-[10px] font-bold uppercase tracking-widest text-primary/70 sticky left-0"
                          >
                            {row.label}
                          </td>
                        </tr>
                      );
                    }

                    // Find best value index for this row
                    let bestValIdx = -1;
                    if (row.getNumeric && row.bestMode && comparedDeals.length >= 2) {
                      const nums = comparedDeals.map((d) => row.getNumeric!(d));
                      bestValIdx = bestIdx(nums, row.bestMode);
                    }

                    return (
                      <tr
                        key={row.label}
                        className={`border-b border-border/20 ${
                          row.highlight ? "bg-secondary/15" : i % 2 === 0 ? "" : "bg-secondary/5"
                        }`}
                      >
                        <td className="p-3 text-sm font-medium text-muted-foreground sticky left-0 bg-background/80 backdrop-blur-sm z-10">
                          {row.icon && <span className="mr-1.5">{row.icon}</span>}
                          {row.label}
                        </td>
                        {comparedDeals.map((deal, di) => {
                          const isBest = di === bestValIdx && comparedDeals.length >= 2;
                          return (
                            <td
                              key={deal.id}
                              className={`p-3 text-sm text-center font-medium transition-colors ${
                                isBest
                                  ? "text-emerald-400 font-bold bg-emerald-500/5"
                                  : row.highlight
                                  ? "text-foreground"
                                  : ""
                              }`}
                            >
                              <span className="inline-flex items-center gap-1">
                                {row.getValue(deal)}
                                {isBest && <span className="text-emerald-400 text-[10px]">✓</span>}
                              </span>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Detailed Best Deal Summary */}
            {comparedDeals.length >= 2 && (() => {
              const bestProfit = comparedDeals[bestProfitIdx];
              const lowestCost = comparedDeals[bestCostIdx];
              const leastDamage = comparedDeals[bestDamageIdx];
              const allSame = bestProfitIdx === bestCostIdx && bestCostIdx === bestDamageIdx;

              return (
                <div className="mt-4 space-y-3">
                  <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                    <div className="flex items-center gap-2 mb-3">
                      <Sparkles className="w-5 h-5 text-emerald-400" />
                      <span className="font-heading font-bold text-emerald-400 text-lg">Recommendation</span>
                    </div>
                    {allSame ? (
                      <p className="text-sm text-muted-foreground">
                        <strong className="text-foreground">
                          {bestProfit.vehicleInfo.year} {bestProfit.vehicleInfo.make} {bestProfit.vehicleInfo.model}
                        </strong>{" "}
                        is the clear winner — it has the <strong className="text-emerald-400">highest ROI ({bestProfit.profitMarginPercent}%)</strong>,
                        the <strong className="text-blue-400">lowest total cost ({formatAED(bestProfit.totalCostAED)})</strong>,
                        and the <strong className="text-amber-400">least damage
                        {bestProfit.damageAnalysis ? ` (${bestProfit.damageAnalysis.overallSeverityScore}/10)` : ""}</strong>.
                      </p>
                    ) : (
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <p>
                          🏆 <strong className="text-emerald-400">Best ROI:</strong>{" "}
                          <strong className="text-foreground">
                            {bestProfit.vehicleInfo.year} {bestProfit.vehicleInfo.make} {bestProfit.vehicleInfo.model}
                          </strong>{" "}
                          — {bestProfit.profitMarginPercent}% margin ({formatAED(bestProfit.estimatedProfitAED)} profit)
                        </p>
                        {bestCostIdx !== bestProfitIdx && (
                          <p>
                            💰 <strong className="text-blue-400">Lowest Cost:</strong>{" "}
                            <strong className="text-foreground">
                              {lowestCost.vehicleInfo.year} {lowestCost.vehicleInfo.make} {lowestCost.vehicleInfo.model}
                            </strong>{" "}
                            — {formatAED(lowestCost.totalCostAED)} total investment
                          </p>
                        )}
                        {bestDamageIdx !== bestProfitIdx && leastDamage.damageAnalysis && (
                          <p>
                            🛡️ <strong className="text-amber-400">Least Damage:</strong>{" "}
                            <strong className="text-foreground">
                              {leastDamage.vehicleInfo.year} {leastDamage.vehicleInfo.make} {leastDamage.vehicleInfo.model}
                            </strong>{" "}
                            — {leastDamage.damageAnalysis.overallSeverityScore}/10 severity
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>
          );
        })()}

        {/* Grid View */}
        {viewMode === "grid" && sortedDeals.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <AnimatePresence>
              {sortedDeals.map((deal, i) => (
                <motion.div
                  key={deal.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Card
                    className={`glass-card border-border/50 overflow-hidden transition-all ${
                      compareIds.includes(deal.id) ? "ring-2 ring-primary" : ""
                    }`}
                  >
                    {/* Photo Header */}
                    {deal.photoUrl && (
                      <div className="relative h-36 overflow-hidden">
                        <img
                          src={deal.photoUrl}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
                        <div className="absolute bottom-2 left-3 right-3 flex items-end justify-between">
                          <div>
                            <p className="font-heading font-bold text-sm">
                              {deal.vehicleInfo.year} {deal.vehicleInfo.make}
                            </p>
                            <p className="text-xs text-muted-foreground">{deal.vehicleInfo.model}</p>
                          </div>
                          {deal.damageAnalysis && (
                            <span
                              className={`text-xs font-bold px-2 py-0.5 rounded ${
                                deal.damageAnalysis.overallSeverityScore <= 3
                                  ? "bg-emerald-500/20 text-emerald-400"
                                  : deal.damageAnalysis.overallSeverityScore <= 6
                                  ? "bg-amber-500/20 text-amber-400"
                                  : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              DMG {deal.damageAnalysis.overallSeverityScore}/10
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* No Photo Header */}
                    {!deal.photoUrl && (
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base font-heading flex items-center gap-2">
                          <Car className="w-4 h-4 text-primary" />
                          {deal.vehicleInfo.year} {deal.vehicleInfo.make} {deal.vehicleInfo.model}
                        </CardTitle>
                        <p className="text-xs text-muted-foreground">{deal.vin}</p>
                      </CardHeader>
                    )}

                    <CardContent className={`${deal.photoUrl ? "pt-3" : "pt-0"} pb-4 px-4`}>
                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        <div className="bg-secondary/30 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground uppercase">Bid</span>
                          <p className="text-sm font-semibold">{formatUSD(deal.bidAmountUSD)}</p>
                        </div>
                        <div className="bg-secondary/30 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground uppercase">Total Cost</span>
                          <p className="text-sm font-semibold">{formatAED(deal.totalCostAED)}</p>
                        </div>
                        <div className="bg-secondary/30 rounded-lg p-2">
                          <span className="text-[10px] text-muted-foreground uppercase">Market Price</span>
                          <p className="text-sm font-semibold text-primary">
                            {formatAED(deal.uaeMarketPriceAED)}
                          </p>
                        </div>
                        <div
                          className={`rounded-lg p-2 ${
                            deal.estimatedProfitAED >= 0
                              ? "bg-emerald-500/10"
                              : "bg-red-500/10"
                          }`}
                        >
                          <span className="text-[10px] text-muted-foreground uppercase">Profit</span>
                          <p
                            className={`text-sm font-bold ${
                              deal.estimatedProfitAED >= 0 ? "text-emerald-400" : "text-red-400"
                            }`}
                          >
                            {formatAED(deal.estimatedProfitAED)}{" "}
                            <span className="text-[10px]">({deal.profitMarginPercent}%)</span>
                          </p>
                        </div>
                      </div>

                      {/* Meta */}
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                        <span>{deal.mileage.toLocaleString()} mi</span>
                        <span>•</span>
                        <span>{deal.auctionHouse.toUpperCase()}</span>
                        <span>•</span>
                        <span>{deal.emirate}</span>
                      </div>

                      {/* Notes */}
                      {editingNoteId === deal.id ? (
                        <div className="mb-3 flex gap-2">
                          <Input
                            value={noteText}
                            onChange={(e) => setNoteText(e.target.value)}
                            placeholder="Add a note..."
                            className="text-xs h-8"
                          />
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                            onClick={() =>
                              updateNotesMutation.mutate({ id: deal.id, notes: noteText })
                            }
                          >
                            <Check className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                            onClick={() => setEditingNoteId(null)}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : deal.notes ? (
                        <p
                          className="text-xs text-muted-foreground italic mb-3 cursor-pointer hover:text-foreground transition-colors"
                          onClick={() => {
                            setEditingNoteId(deal.id);
                            setNoteText(deal.notes || "");
                          }}
                        >
                          📝 {deal.notes}
                        </p>
                      ) : null}

                      {/* Actions */}
                      <div className="flex items-center gap-1.5">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              className={`h-7 text-xs ${
                                compareIds.includes(deal.id) ? "border-primary text-primary" : ""
                              }`}
                              onClick={() => toggleCompare(deal.id)}
                            >
                              <Columns className="w-3 h-3 mr-1" />
                              {compareIds.includes(deal.id) ? "Selected" : "Compare"}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Add to side-by-side comparison</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs"
                              onClick={() => handlePdfExport(deal)}
                            >
                              <FileText className="w-3 h-3 mr-1" />
                              PDF
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Export as PDF report</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs"
                              onClick={() => {
                                setEditingNoteId(deal.id);
                                setNoteText(deal.notes || "");
                              }}
                            >
                              <StickyNote className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Add/edit notes</TooltipContent>
                        </Tooltip>

                        <div className="flex-1" />

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                              onClick={() => {
                                if (confirm("Remove this deal from the queue?")) {
                                  deleteMutation.mutate({ id: deal.id });
                                }
                              }}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Delete deal</TooltipContent>
                        </Tooltip>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Compare View with no deals selected */}
        {viewMode === "compare" && comparedDeals.length === 0 && sortedDeals.length > 0 && (
          <Card className="glass-card border-border/50">
            <CardContent className="p-8 text-center">
              <Columns className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="font-heading text-lg font-bold mb-2">No Deals Selected</h3>
              <p className="text-muted-foreground mb-4">
                Switch to grid view and click "Compare" on 2-4 deals to compare them side-by-side.
              </p>
              <Button variant="outline" onClick={() => setViewMode("grid")}>
                Back to Grid
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
