/**
 * Fee Guide — US Auction Fees + UAE Import Costs Reference
 * Now reads data from admin Fee Guide Editor (database) with fallback to hardcoded data.
 */
import PublicNavbar from "@/components/PublicNavbar";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useFeeSchedules } from "@/hooks/useFeeSchedules";
import { useFeatureToggles } from "@/hooks/useFeatureToggles";
import { formatUSD, formatAED } from "@/lib/auctionData";
import { SPARE_PARTS } from "@/lib/auctionData";
import { motion } from "framer-motion";
import {
  DollarSign,
  Ship,
  Shield,
  MapPin,
  Wrench,
  Info,
  Loader2,
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: "easeOut" as const },
  }),
};

export default function FeeGuide() {
  const { t } = useLanguage();
  const fees = useFeeSchedules();
  const toggles = useFeatureToggles();

  // Check if user is logged in (has client session)
  const isLoggedIn = !!localStorage.getItem("clientSession");

  if (fees.isLoading) {
    return (
      <div className="min-h-screen bg-background">
        {isLoggedIn ? null : <PublicNavbar />}
        <main className="container py-6 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {isLoggedIn ? null : <PublicNavbar />}

      <main className="container py-6">
        <motion.div initial="hidden" animate="visible" custom={0} variants={fadeUp}>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold mb-2">
            {t("feeGuide.title")} <span className="text-gradient">{t("feeGuide.titleAccent")}</span>
          </h1>
          <p className="text-muted-foreground text-sm mb-8 max-w-2xl">
            {t("feeGuide.subtitle")}
          </p>
        </motion.div>

        <Tabs defaultValue="auction" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 h-auto gap-1 bg-secondary/30 p-1">
            <TabsTrigger value="auction" className="text-xs gap-1.5 py-2">
              <DollarSign className="w-3.5 h-3.5" /> {t("feeGuide.auctionFees") || "Auction Fees"}
            </TabsTrigger>
            <TabsTrigger value="shipping" className="text-xs gap-1.5 py-2">
              <Ship className="w-3.5 h-3.5" /> {t("calc.shipping") || "Shipping"}
            </TabsTrigger>
            <TabsTrigger value="import" className="text-xs gap-1.5 py-2">
              <Shield className="w-3.5 h-3.5" /> {t("feeGuide.uaeImport") || "Import Tax"}
            </TabsTrigger>
            <TabsTrigger value="registration" className="text-xs gap-1.5 py-2">
              <MapPin className="w-3.5 h-3.5" /> {t("home.registration") || "Registration"}
            </TabsTrigger>
            <TabsTrigger value="parts" className="text-xs gap-1.5 py-2">
              <Wrench className="w-3.5 h-3.5" /> {t("calc.spareParts") || "Parts"}
            </TabsTrigger>
          </TabsList>

          {/* ─── AUCTION FEES (from DB or fallback) ─── */}
          <TabsContent value="auction" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Copart Buyer Fees */}
              <Card className="glass-card border-border/40">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-heading flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400">C</div>
                    Copart Buyer Fees (Secured)
                  </CardTitle>
                  <p className="text-xs text-muted-foreground">
                    Gate Fee: {formatUSD(fees.fixedFees.gateFee)} | Env Fee: {formatUSD(fees.fixedFees.envFee)} | Title: {formatUSD(fees.fixedFees.titleFee)}
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="max-h-80 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="sticky top-0 bg-card">
                        <tr className="border-b border-border/40">
                          <th className="text-left py-2 pr-2 text-muted-foreground font-medium">Bid Range</th>
                          <th className="text-right py-2 text-muted-foreground font-medium">Buyer Fee</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fees.buyerFees.map((tier: any, i: number) => (
                          <tr key={i} className="border-b border-border/10 hover:bg-secondary/20">
                            <td className="py-1.5 pr-2 tabular-nums">
                              {formatUSD(tier.min)} — {tier.max === Infinity || tier.max === null || tier.max === 0 ? "+" : formatUSD(tier.max)}
                            </td>
                            <td className="py-1.5 text-right tabular-nums font-medium">
                              {tier.fee !== null && tier.fee !== undefined ? formatUSD(tier.fee) : `${tier.percent}%`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="mt-4 pt-3 border-t border-border/20">
                    <p className="text-xs font-semibold mb-2">Virtual Bid Fee (Live-Bid)</p>
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      {fees.virtualFees.map((tier: any, i: number) => (
                        <div key={i} className="flex justify-between bg-secondary/20 rounded px-2 py-1">
                          <span className="text-muted-foreground tabular-nums">
                            {formatUSD(tier.min)}{tier.max === Infinity || tier.max === null || tier.max === 0 ? "+" : `-${formatUSD(tier.max)}`}
                          </span>
                          <span className="font-medium tabular-nums">{formatUSD(tier.fee)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Fixed Fees Summary */}
                  {fees.fixedFees.allEntries.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-border/20">
                      <p className="text-xs font-semibold mb-2">Fixed Fees</p>
                      <div className="space-y-1">
                        {fees.fixedFees.allEntries.map((entry: any) => (
                          <div key={entry.key} className="flex justify-between text-xs">
                            <span className="text-muted-foreground">{entry.label}</span>
                            <span className="font-medium tabular-nums">{formatUSD(entry.value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* IAAI Buyer Fees (same schedule) */}
              <Card className="glass-card border-border/40">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-heading flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-xs font-bold text-orange-400">I</div>
                    IAAI Buyer Fees (Licensed)
                  </CardTitle>
                  <p className="text-xs text-muted-foreground">Internet Bid Fee: $79</p>
                </CardHeader>
                <CardContent>
                  <div className="max-h-80 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="sticky top-0 bg-card">
                        <tr className="border-b border-border/40">
                          <th className="text-left py-2 pr-2 text-muted-foreground font-medium">Bid Range</th>
                          <th className="text-right py-2 text-muted-foreground font-medium">Buyer Fee</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fees.buyerFees.map((tier: any, i: number) => (
                          <tr key={i} className="border-b border-border/10 hover:bg-secondary/20">
                            <td className="py-1.5 pr-2 tabular-nums">
                              {formatUSD(tier.min)} — {tier.max === Infinity || tier.max === null || tier.max === 0 ? "+" : formatUSD(tier.max)}
                            </td>
                            <td className="py-1.5 text-right tabular-nums font-medium">
                              {tier.fee !== null && tier.fee !== undefined ? formatUSD(tier.fee) : `${tier.percent}%`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ─── SHIPPING (from DB or fallback) ─── */}
          <TabsContent value="shipping">
            <Card className="glass-card border-border/40">
              <CardHeader>
                <CardTitle className="text-base font-heading">Shipping US to UAE</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Typical shipping costs from US ports to Jebel Ali (Dubai) port.
                </p>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border/40">
                      <th className="text-left py-3 text-xs text-muted-foreground font-medium">Method</th>
                      <th className="text-left py-3 text-xs text-muted-foreground font-medium">Cost Range</th>
                      <th className="text-left py-3 text-xs text-muted-foreground font-medium">Transit Time</th>
                      <th className="text-left py-3 text-xs text-muted-foreground font-medium">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fees.shippingMethods.map((method: any) => (
                      <tr key={method.key} className="border-b border-border/20">
                        <td className="py-3 font-medium">{method.label}</td>
                        <td className="py-3 tabular-nums">
                          {formatUSD(method.costMin)} — {method.costMax > 0 ? formatUSD(method.costMax) : "+"}
                        </td>
                        <td className="py-3">{method.transit}</td>
                        <td className="py-3 text-xs text-muted-foreground">{method.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-2">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Prices vary by US origin port (NJ, GA, TX, CA are most common), vehicle size, and season.
                    Inland towing from auction to port is typically $100-$500 extra.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── IMPORT TAX (from DB or fallback) ─── */}
          <TabsContent value="import">
            <Card className="glass-card border-border/40">
              <CardHeader>
                <CardTitle className="text-base font-heading">UAE Customs Duty & VAT</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-secondary/30 border border-border/20">
                    <h3 className="font-semibold text-sm mb-1">Customs Duty</h3>
                    <p className="text-3xl font-bold text-primary">{(fees.importTax.customsRate * 100).toFixed(0)}%</p>
                    <p className="text-xs text-muted-foreground mt-1">of CIF value (Cost + Insurance + Freight)</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30 border border-border/20">
                    <h3 className="font-semibold text-sm mb-1">VAT</h3>
                    <p className="text-3xl font-bold text-primary">{(fees.importTax.vatRate * 100).toFixed(0)}%</p>
                    <p className="text-xs text-muted-foreground mt-1">of (CIF value + Customs Duty)</p>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-secondary/20">
                  <h3 className="font-semibold text-sm mb-3">Example Calculation</h3>
                  {(() => {
                    const exRate = fees.importTax.exchangeRate;
                    const customsRate = fees.importTax.customsRate;
                    const vatRate = fees.importTax.vatRate;
                    const carPrice = 5000;
                    const shipping = 1200;
                    const totalUSD = carPrice + shipping;
                    const cifAED = totalUSD * exRate;
                    const customs = cifAED * customsRate;
                    const vat = (cifAED + customs) * vatRate;
                    return (
                      <div className="space-y-1.5 text-xs">
                        <div className="flex justify-between"><span className="text-muted-foreground">Car Price (bid + fees)</span><span className="tabular-nums">{formatUSD(carPrice)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="tabular-nums">{formatUSD(shipping)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Total in USD</span><span className="tabular-nums font-medium">{formatUSD(totalUSD)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">CIF in AED (×{exRate})</span><span className="tabular-nums font-medium">{formatAED(cifAED)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Customs Duty ({(customsRate * 100).toFixed(0)}%)</span><span className="tabular-nums">{formatAED(customs)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">VAT ({(vatRate * 100).toFixed(0)}% on CIF+Duty)</span><span className="tabular-nums">{formatAED(vat)}</span></div>
                        <div className="flex justify-between font-semibold border-t border-border/20 pt-1.5"><span>Total Import Tax</span><span className="tabular-nums text-primary">{formatAED(customs + vat)}</span></div>
                      </div>
                    );
                  })()}
                </div>

                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-2">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>Effective total tax rate is approximately <strong>{((fees.importTax.customsRate + fees.importTax.vatRate * (1 + fees.importTax.customsRate)) * 100).toFixed(2)}%</strong> of CIF value.</p>
                    <p>Cars older than 5 years may face import restrictions in the UAE.</p>
                    <p>Exchange rate used: 1 USD = {fees.importTax.exchangeRate} AED (fixed peg).</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── REGISTRATION (from DB or fallback) ─── */}
          <TabsContent value="registration">
            <Card className="glass-card border-border/40">
              <CardHeader>
                <CardTitle className="text-base font-heading">Registration Fees by Emirate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/40">
                        <th className="text-left py-3 text-xs text-muted-foreground font-medium">Emirate</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Registration</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Inspection</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Plate</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Other</th>
                        <th className="text-right py-3 text-xs text-primary font-semibold">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fees.emirateRegistration.map((e: any) => (
                        <tr key={e.id} className="border-b border-border/10 hover:bg-secondary/20">
                          <td className="py-2.5 font-medium">{e.name}</td>
                          <td className="py-2.5 text-right tabular-nums">{formatAED(e.registrationFee)}</td>
                          <td className="py-2.5 text-right tabular-nums">{formatAED(e.inspectionFee)}</td>
                          <td className="py-2.5 text-right tabular-nums">{formatAED(e.plateFee)}</td>
                          <td className="py-2.5 text-right tabular-nums">{e.otherFees > 0 ? formatAED(e.otherFees) : "—"}</td>
                          <td className="py-2.5 text-right tabular-nums font-semibold text-primary">{formatAED(e.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 space-y-2">
                  {fees.emirateRegistration.filter((e: any) => e.otherFees > 0 && e.notes).map((e: any) => (
                    <p key={e.id} className="text-xs text-muted-foreground">
                      <strong>{e.name}:</strong> {e.notes}
                    </p>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── SPARE PARTS ─── */}
          <TabsContent value="parts">
            <Card className="glass-card border-border/40">
              <CardHeader>
                <CardTitle className="text-base font-heading">UAE Spare Parts Price Guide</CardTitle>
                <p className="text-xs text-muted-foreground">Approximate prices in AED. Actual prices vary by make, model, and supplier.</p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/40">
                        <th className="text-left py-3 text-xs text-muted-foreground font-medium">Part</th>
                        <th className="text-left py-3 text-xs text-muted-foreground font-medium">Category</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Min</th>
                        <th className="text-right py-3 text-xs text-muted-foreground font-medium">Max</th>
                        <th className="text-right py-3 text-xs text-primary font-semibold">Average</th>
                      </tr>
                    </thead>
                    <tbody>
                      {SPARE_PARTS.map((part) => (
                        <tr key={part.id} className="border-b border-border/10 hover:bg-secondary/20">
                          <td className="py-2 font-medium">{part.name}</td>
                          <td className="py-2 text-xs text-muted-foreground">{part.category}</td>
                          <td className="py-2 text-right tabular-nums">{formatAED(part.priceAED * 0.8)}</td>
                          <td className="py-2 text-right tabular-nums">{formatAED(part.priceAED * 1.2)}</td>
                          <td className="py-2 text-right tabular-nums font-semibold text-primary">{formatAED(part.priceAED)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
