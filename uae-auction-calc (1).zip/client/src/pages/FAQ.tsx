import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import PublicNavbar from "@/components/PublicNavbar";
import { motion, AnimatePresence } from "framer-motion";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export default function FAQPage() {
  const { t, isRTL } = useLanguage();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const faqItems: FAQItem[] = [
    // Calculator & Features
    {
      id: "calc-1",
      category: "calculator",
      question: t("faq.calc1.question") || "How do I decode a VIN?",
      answer: t("faq.calc1.answer") || "Enter any 17-character VIN in the calculator. The system automatically fetches vehicle information from NHTSA and auction databases.",
    },
    {
      id: "calc-2",
      category: "calculator",
      question: t("faq.calc2.question") || "What information does the VIN decoder provide?",
      answer: t("faq.calc2.answer") || "The decoder provides make, model, year, body type, engine size, transmission, trim level, and other technical specifications.",
    },
    {
      id: "calc-3",
      category: "calculator",
      question: t("faq.calc3.question") || "Can I search for auction listings?",
      answer: t("faq.calc3.answer") || "Yes! Enter a VIN to search Copart and IAAI auctions. The calculator displays available lots with photos, damage info, and pricing.",
    },
    {
      id: "calc-4",
      category: "calculator",
      question: t("faq.calc4.question") || "What is the AI damage analysis?",
      answer: t("faq.calc4.answer") || "Upload photos of vehicle damage and our AI analyzes each area, estimates repair costs, and provides severity scores for better decision-making.",
    },

    // Fees & Costs
    {
      id: "fees-1",
      category: "fees",
      question: t("faq.fees1.question") || "How are Copart fees calculated?",
      answer: t("faq.fees1.answer") || "Copart charges a buyer's fee (typically 8-10% of hammer price) plus documentation and title fees. Our calculator uses exact Copart fee tables.",
    },
    {
      id: "fees-2",
      category: "fees",
      question: t("faq.fees2.question") || "What are IAAI buyer fees?",
      answer: t("faq.fees2.answer") || "IAAI charges 9-12% buyer's fee depending on vehicle price, plus admin and title fees. Exact rates are calculated based on your bid amount.",
    },
    {
      id: "fees-3",
      category: "fees",
      question: t("faq.fees3.question") || "Are there hidden fees?",
      answer: t("faq.fees3.answer") || "No. Our calculator shows all fees: auction buyer's fee, documentation, title transfer, shipping, customs, VAT, and registration. No surprises.",
    },
    {
      id: "fees-4",
      category: "fees",
      question: t("faq.fees4.question") || "How is the exchange rate calculated?",
      answer: t("faq.fees4.answer") || "We use the official rate of 3.685 AED/USD. You can manually override this in the calculator if you have a different rate.",
    },

    // Shipping & Logistics
    {
      id: "ship-1",
      category: "shipping",
      question: t("faq.ship1.question") || "How much does shipping cost?",
      answer: t("faq.ship1.answer") || "Shipping varies by auction location and destination port. Our calculator has 382 city-specific rates. Average cost is $800-1,500 per vehicle.",
    },
    {
      id: "ship-2",
      category: "shipping",
      question: t("faq.ship2.question") || "What shipping ports are available?",
      answer: t("faq.ship2.answer") || "We support major UAE ports: Jebel Ali (Dubai), Khalifa Port (Abu Dhabi), Fujairah Port, and Ras Al Khaimah. Select your preferred port.",
    },
    {
      id: "ship-3",
      category: "shipping",
      question: t("faq.ship3.question") || "How long does shipping take?",
      answer: t("faq.ship3.answer") || "Typical transit time is 4-6 weeks from US auction to UAE port. Add 1-2 weeks for customs clearance and delivery.",
    },
    {
      id: "ship-4",
      category: "shipping",
      question: t("faq.ship4.question") || "Is shipping insurance included?",
      answer: t("faq.ship4.answer") || "Shipping costs do not include insurance. We recommend purchasing cargo insurance (typically 2-3% of vehicle value) for protection.",
    },

    // Customs & Taxes
    {
      id: "customs-1",
      category: "customs",
      question: t("faq.customs1.question") || "What is the UAE import duty?",
      answer: t("faq.customs1.answer") || "UAE charges 5% customs duty on the CIF value (Cost + Insurance + Freight). This is calculated automatically in the total cost.",
    },
    {
      id: "customs-2",
      category: "customs",
      question: t("faq.customs2.question") || "What is VAT in UAE?",
      answer: t("faq.customs2.answer") || "UAE VAT is 5% on the vehicle price plus auction fees (not including shipping). It's added to your total import cost.",
    },
    {
      id: "customs-3",
      category: "customs",
      question: t("faq.customs3.question") || "What documents do I need for customs?",
      answer: t("faq.customs3.answer") || "You need: original title, bill of lading, commercial invoice, packing list, and certificate of origin. Your shipping agent handles most paperwork.",
    },
    {
      id: "customs-4",
      category: "customs",
      question: t("faq.customs4.question") || "Can I import salvage title vehicles?",
      answer: t("faq.customs4.answer") || "Yes, but salvage titles have restrictions. Some emirates require inspection and may limit registration. Check local regulations before bidding.",
    },

    // Registration & Legal
    {
      id: "reg-1",
      category: "registration",
      question: t("faq.reg1.question") || "How much does vehicle registration cost?",
      answer: t("faq.reg1.answer") || "Registration fees vary by emirate: Dubai (AED 500-800), Abu Dhabi (AED 400-600), Sharjah (AED 300-500). Our calculator shows exact rates.",
    },
    {
      id: "reg-2",
      category: "registration",
      question: t("faq.reg2.question") || "How long does registration take?",
      answer: t("faq.reg2.answer") || "Registration typically takes 1-3 days after customs clearance. You can register online or visit the RTA office in your emirate.",
    },
    {
      id: "reg-3",
      category: "registration",
      question: t("faq.reg3.question") || "Do I need a local sponsor?",
      answer: t("faq.reg3.answer") || "No. As a UAE resident, you can register vehicles directly. Non-residents may need assistance from a local agent.",
    },
    {
      id: "reg-4",
      category: "registration",
      question: t("faq.reg4.question") || "What is the age limit for imported vehicles?",
      answer: t("faq.reg4.answer") || "Most emirates allow vehicles up to 10-15 years old. Older vehicles may require inspection. Check your emirate's specific rules.",
    },

    // Account & Usage
    {
      id: "account-1",
      category: "account",
      question: t("faq.account1.question") || "How do I create an account?",
      answer: t("faq.account1.answer") || "Contact your administrator for login credentials. Once you have a username and password, log in to access the calculator.",
    },
    {
      id: "account-2",
      category: "account",
      question: t("faq.account2.question") || "Can I save my calculations?",
      answer: t("faq.account2.answer") || "Yes! Use the Deal Queue feature to save vehicles you're interested in. Compare multiple deals side-by-side and track profit margins.",
    },
    {
      id: "account-3",
      category: "account",
      question: t("faq.account3.question") || "How do I export a calculation report?",
      answer: t("faq.account3.answer") || "Click 'Export PDF' in the calculator to generate a professional report with all costs, damage analysis, and profit calculations.",
    },
    {
      id: "account-4",
      category: "account",
      question: t("faq.account4.question") || "What if I forgot my password?",
      answer: t("faq.account4.answer") || "Click 'Forgot Password?' on the login page and follow the email instructions to reset your password.",
    },
  ];

  const categories = [
    { id: "calculator", label: t("faq.category.calculator") || "Calculator" },
    { id: "fees", label: t("faq.category.fees") || "Fees & Costs" },
    { id: "shipping", label: t("faq.category.shipping") || "Shipping" },
    { id: "customs", label: t("faq.category.customs") || "Customs & Taxes" },
    { id: "registration", label: t("faq.category.registration") || "Registration" },
    { id: "account", label: t("faq.category.account") || "Account & Usage" },
  ];

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-background">
      <PublicNavbar />
      
      <div className="pt-20 pb-16">
        {/* Header */}
        <div className="bg-gradient-to-b from-primary/10 to-transparent py-12 border-b border-border/50">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4">
              {t("faq.title") || "Frequently Asked Questions"}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              {t("faq.subtitle") || "Find answers to common questions about the UAE AuctionCalc calculator, fees, shipping, and more."}
            </p>
          </div>
        </div>

        {/* FAQ Content */}
        <div className="container py-12">
          {categories.map((category) => {
            const categoryItems = faqItems.filter((item) => item.category === category.id);
            
            return (
              <div key={category.id} className="mb-12">
                <h2 className="text-2xl font-heading font-bold mb-6 text-foreground">
                  {category.label}
                </h2>

                <div className="space-y-3">
                  {categoryItems.map((item) => (
                    <motion.div
                      key={item.id}
                      className="border border-border/50 rounded-lg overflow-hidden hover:border-primary/50 transition-colors"
                      layout
                    >
                      <button
                        onClick={() => toggleExpand(item.id)}
                        className={`w-full px-6 py-4 flex items-center justify-between bg-card hover:bg-card/80 transition-colors ${
                          isRTL ? "flex-row-reverse" : ""
                        }`}
                      >
                        <span className="text-left font-medium text-foreground">
                          {item.question}
                        </span>
                        <motion.div
                          animate={{ rotate: expandedId === item.id ? 180 : 0 }}
                          transition={{ duration: 0.2 }}
                          className={`flex-shrink-0 ${isRTL ? "mr-4" : "ml-4"}`}
                        >
                          <ChevronDown className="w-5 h-5 text-primary" />
                        </motion.div>
                      </button>

                      <AnimatePresence>
                        {expandedId === item.id && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden bg-background/50 border-t border-border/30"
                          >
                            <div className="px-6 py-4 text-muted-foreground leading-relaxed">
                              {item.answer}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Contact Section */}
          <div className="mt-16 p-8 rounded-lg bg-primary/5 border border-primary/20">
            <h3 className="text-xl font-heading font-bold mb-2">
              {t("faq.contact.title") || "Still have questions?"}
            </h3>
            <p className="text-muted-foreground mb-4">
              {t("faq.contact.message") || "Contact your administrator for additional support or specific questions about your account."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
