import { useState } from "react";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Settings,
  Save,
  Plus,
  Trash2,
  Star,
  Eye,
  EyeOff,
  ArrowLeft,
  Loader2,
  CheckCircle,
  DollarSign,
  Zap,
} from "lucide-react";
import { Link } from "wouter";

interface PlanForm {
  id?: number;
  name: string;
  slug: string;
  description: string;
  priceMonthlyAED: number;
  priceAnnualAED: number;
  vinLimitPerMonth: number;
  features: string[];
  isActive: number;
  isPopular: number;
  sortOrder: number;
}

export default function AdminSettings() {
  const [editingPlan, setEditingPlan] = useState<PlanForm | null>(null);
  const [newFeature, setNewFeature] = useState("");
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const { data: plans, isLoading, refetch } = trpc.admin.getPlans.useQuery();

  const updatePlan = trpc.admin.updatePlan.useMutation({
    onSuccess: () => {
      setSuccess("Plan updated successfully!");
      setError("");
      refetch();
      setTimeout(() => setSuccess(""), 3000);
    },
    onError: (err) => setError(err.message),
  });

  const createPlan = trpc.admin.createPlan.useMutation({
    onSuccess: () => {
      setSuccess("Plan created successfully!");
      setError("");
      setEditingPlan(null);
      refetch();
      setTimeout(() => setSuccess(""), 3000);
    },
    onError: (err) => setError(err.message),
  });

  const deletePlan = trpc.admin.deletePlan.useMutation({
    onSuccess: () => {
      setSuccess("Plan deleted successfully!");
      refetch();
      setTimeout(() => setSuccess(""), 3000);
    },
    onError: (err) => setError(err.message),
  });

  const handleSavePlan = (plan: PlanForm) => {
    if (plan.id) {
      updatePlan.mutate({
        id: plan.id,
        name: plan.name,
        description: plan.description,
        priceMonthlyAED: plan.priceMonthlyAED,
        priceAnnualAED: plan.priceAnnualAED,
        vinLimitPerMonth: plan.vinLimitPerMonth,
        features: plan.features,
        isActive: plan.isActive,
        isPopular: plan.isPopular,
        sortOrder: plan.sortOrder,
      });
    } else {
      createPlan.mutate({
        name: plan.name,
        slug: plan.slug,
        description: plan.description,
        priceMonthlyAED: plan.priceMonthlyAED,
        priceAnnualAED: plan.priceAnnualAED,
        vinLimitPerMonth: plan.vinLimitPerMonth,
        features: plan.features,
        isActive: plan.isActive,
        isPopular: plan.isPopular,
        sortOrder: plan.sortOrder,
      });
    }
  };

  const formatAED = (fils: number) => (fils / 100).toFixed(0);
  const parseFils = (aed: string) => Math.round(parseFloat(aed || "0") * 100);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container max-w-5xl mx-auto px-4 pt-24 pb-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Link href="/admin" className="text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
              <Settings className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-heading font-bold text-foreground">Pricing Plans</h1>
              <p className="text-sm text-muted-foreground">Manage subscription tiers and pricing in AED</p>
            </div>
          </div>
          <Button
            onClick={() =>
              setEditingPlan({
                name: "",
                slug: "",
                description: "",
                priceMonthlyAED: 0,
                priceAnnualAED: 0,
                vinLimitPerMonth: 10,
                features: [],
                isActive: 1,
                isPopular: 0,
                sortOrder: (plans?.length ?? 0) + 1,
              })
            }
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Plan
          </Button>
        </div>

        {/* Alerts */}
        {success && (
          <Alert className="mb-6 bg-primary/10 border-primary/30 text-primary">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Plans Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid gap-6">
            {plans?.map((plan) => (
              <div
                key={plan.id}
                className={`rounded-2xl border bg-card p-6 transition-all ${
                  plan.isPopular ? "border-primary/50 shadow-lg shadow-primary/10" : "border-border/50"
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-heading font-bold text-foreground">{plan.name}</h3>
                      {plan.isPopular === 1 && (
                        <span className="px-2 py-0.5 text-xs font-semibold bg-primary/15 text-primary rounded-full">
                          Popular
                        </span>
                      )}
                      {plan.isActive === 0 && (
                        <span className="px-2 py-0.5 text-xs font-semibold bg-muted text-muted-foreground rounded-full">
                          Hidden
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setEditingPlan({
                          id: plan.id,
                          name: plan.name,
                          slug: plan.slug,
                          description: plan.description || "",
                          priceMonthlyAED: plan.priceMonthlyAED,
                          priceAnnualAED: plan.priceAnnualAED,
                          vinLimitPerMonth: plan.vinLimitPerMonth,
                          features: plan.features,
                          isActive: plan.isActive,
                          isPopular: plan.isPopular,
                          sortOrder: plan.sortOrder,
                        })
                      }
                      className="border-border/50"
                    >
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (confirm("Delete this plan?")) {
                          deletePlan.mutate({ id: plan.id });
                        }
                      }}
                      className="border-destructive/30 text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="rounded-xl bg-secondary/50 p-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                      <DollarSign className="w-3.5 h-3.5" />
                      Monthly
                    </div>
                    <p className="text-lg font-bold text-foreground">
                      {plan.priceMonthlyAED === 0 ? "Custom" : `${formatAED(plan.priceMonthlyAED)} AED`}
                    </p>
                  </div>
                  <div className="rounded-xl bg-secondary/50 p-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                      <DollarSign className="w-3.5 h-3.5" />
                      Annual
                    </div>
                    <p className="text-lg font-bold text-foreground">
                      {plan.priceAnnualAED === 0 ? "Custom" : `${formatAED(plan.priceAnnualAED)} AED`}
                    </p>
                  </div>
                  <div className="rounded-xl bg-secondary/50 p-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                      <Zap className="w-3.5 h-3.5" />
                      VIN Limit
                    </div>
                    <p className="text-lg font-bold text-foreground">
                      {plan.vinLimitPerMonth === 0 ? "Unlimited" : `${plan.vinLimitPerMonth}/mo`}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {plan.features.map((f, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 text-xs bg-primary/10 text-primary rounded-lg"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit/Create Plan Modal */}
        {editingPlan && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-border/50 bg-card shadow-2xl p-6">
              <h2 className="text-xl font-heading font-bold text-foreground mb-6">
                {editingPlan.id ? "Edit Plan" : "Create New Plan"}
              </h2>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Plan Name
                    </label>
                    <Input
                      value={editingPlan.name}
                      onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                      className="bg-secondary border-border mt-1"
                    />
                  </div>
                  {!editingPlan.id && (
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Slug
                      </label>
                      <Input
                        value={editingPlan.slug}
                        onChange={(e) => setEditingPlan({ ...editingPlan, slug: e.target.value })}
                        placeholder="e.g., basic"
                        className="bg-secondary border-border mt-1"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Description
                  </label>
                  <Input
                    value={editingPlan.description}
                    onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })}
                    className="bg-secondary border-border mt-1"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Monthly (AED)
                    </label>
                    <Input
                      type="number"
                      value={formatAED(editingPlan.priceMonthlyAED)}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, priceMonthlyAED: parseFils(e.target.value) })
                      }
                      className="bg-secondary border-border mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Annual (AED)
                    </label>
                    <Input
                      type="number"
                      value={formatAED(editingPlan.priceAnnualAED)}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, priceAnnualAED: parseFils(e.target.value) })
                      }
                      className="bg-secondary border-border mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      VIN Limit/mo
                    </label>
                    <Input
                      type="number"
                      value={editingPlan.vinLimitPerMonth}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, vinLimitPerMonth: parseInt(e.target.value) || 0 })
                      }
                      placeholder="0 = unlimited"
                      className="bg-secondary border-border mt-1"
                    />
                  </div>
                </div>

                {/* Features */}
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Features
                  </label>
                  <div className="mt-2 space-y-2">
                    {editingPlan.features.map((f, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Input
                          value={f}
                          onChange={(e) => {
                            const updated = [...editingPlan.features];
                            updated[i] = e.target.value;
                            setEditingPlan({ ...editingPlan, features: updated });
                          }}
                          className="bg-secondary border-border flex-1"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const updated = editingPlan.features.filter((_, idx) => idx !== i);
                            setEditingPlan({ ...editingPlan, features: updated });
                          }}
                          className="border-destructive/30 text-destructive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    ))}
                    <div className="flex items-center gap-2">
                      <Input
                        value={newFeature}
                        onChange={(e) => setNewFeature(e.target.value)}
                        placeholder="Add a feature..."
                        className="bg-secondary border-border flex-1"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && newFeature.trim()) {
                            e.preventDefault();
                            setEditingPlan({
                              ...editingPlan,
                              features: [...editingPlan.features, newFeature.trim()],
                            });
                            setNewFeature("");
                          }
                        }}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (newFeature.trim()) {
                            setEditingPlan({
                              ...editingPlan,
                              features: [...editingPlan.features, newFeature.trim()],
                            });
                            setNewFeature("");
                          }
                        }}
                        className="border-primary/30 text-primary"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Toggles */}
                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingPlan.isActive === 1}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, isActive: e.target.checked ? 1 : 0 })
                      }
                      className="accent-primary w-4 h-4"
                    />
                    <span className="text-sm text-foreground flex items-center gap-1.5">
                      <Eye className="w-4 h-4" /> Visible
                    </span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingPlan.isPopular === 1}
                      onChange={(e) =>
                        setEditingPlan({ ...editingPlan, isPopular: e.target.checked ? 1 : 0 })
                      }
                      className="accent-primary w-4 h-4"
                    />
                    <span className="text-sm text-foreground flex items-center gap-1.5">
                      <Star className="w-4 h-4" /> Popular Badge
                    </span>
                  </label>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 mt-6 pt-4 border-t border-border/50">
                <Button
                  onClick={() => handleSavePlan(editingPlan)}
                  disabled={updatePlan.isPending || createPlan.isPending}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1"
                >
                  {updatePlan.isPending || createPlan.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  {editingPlan.id ? "Save Changes" : "Create Plan"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setEditingPlan(null)}
                  className="border-border/50"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
