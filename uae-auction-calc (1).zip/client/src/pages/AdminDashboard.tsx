/**
 * Admin Dashboard — Unified management panel with sidebar navigation.
 * Tabs: Dashboard, Users, Pricing, Shipping, Insurance, Parts Shops,
 *       Spare Parts Prices, AI Costs, Deal Queue, Settings
 */
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useTheme } from "@/contexts/ThemeContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { SHIPPING_RATES } from "@shared/shippingData";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Ship,
  ShieldCheck as InsuranceIcon,
  Wrench,
  DollarSign,
  Brain,
  ClipboardList,
  Settings,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  Save,
  Eye,
  EyeOff,
  Star,
  Loader2,
  CheckCircle,
  Clock,
  XCircle,
  UserCheck,
  UserX,
  Search,
  TrendingUp,
  Activity,
  Zap,
  Upload,
  Download,
  Sun,
  Moon,
  ChevronLeft,
  ChevronRight,
  ToggleLeft,
  ToggleRight,
  AlertCircle,
  Menu,
  X,
  MessageSquare,
  FileText,
  Filter,
  Send,
} from "lucide-react";

type AdminTab =
  | "dashboard"
  | "users"
  | "pricing"
  | "shipping"
  | "insurance"
  | "partsShops"
  | "partsPrices"
  | "aiCosts"
  | "feeGuide"
  | "dealQueue"
  | "quoteRequests"
  | "shippingRates"
  | "settings";

const SIDEBAR_ITEMS: { id: AdminTab; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "users", label: "Users", icon: Users },
  { id: "pricing", label: "Pricing Plans", icon: CreditCard },
  { id: "shipping", label: "Shipping Companies", icon: Ship },
  { id: "insurance", label: "Insurance Companies", icon: InsuranceIcon },
  { id: "partsShops", label: "Parts Shops", icon: Wrench },
  { id: "partsPrices", label: "Spare Parts Prices", icon: DollarSign },
  { id: "aiCosts", label: "AI Cost Settings", icon: Brain },
  { id: "feeGuide", label: "Fee Guide Editor", icon: Activity },
  { id: "dealQueue", label: "Deal Queue", icon: ClipboardList },
  { id: "quoteRequests", label: "Quote Requests", icon: Zap },
  { id: "shippingRates", label: "Shipping Rates", icon: TrendingUp },
  { id: "settings", label: "Site Settings", icon: Settings },
];

export default function AdminDashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth({ redirectOnUnauthenticated: true });
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <p className="mb-4 text-foreground">Please login to access the admin panel</p>
          <Button onClick={() => (window.location.href = getLoginUrl())}>Login with Manus</Button>
        </div>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>You do not have permission to access the admin panel</AlertDescription>
        </Alert>
      </div>
    );
  }

  const ActiveIcon = SIDEBAR_ITEMS.find((i) => i.id === activeTab)?.icon ?? LayoutDashboard;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar — Desktop */}
      <aside
        className={`hidden md:flex flex-col border-r border-border/50 bg-sidebar text-sidebar-foreground transition-all duration-300 ${
          sidebarCollapsed ? "w-[68px]" : "w-64"
        }`}
      >
        {/* Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-sidebar-border">
          {!sidebarCollapsed && (
            <span className="font-heading font-bold text-lg tracking-tight truncate">
              Admin Panel
            </span>
          )}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors"
          >
            {sidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 overflow-y-auto py-2 px-2">
          {SIDEBAR_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                title={sidebarCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all mb-0.5 ${
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="border-t border-sidebar-border p-3">
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-sidebar-accent transition-colors"
              title={theme === "dark" ? "Light mode" : "Dark mode"}
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            {!sidebarCollapsed && (
              <button
                onClick={logout}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            )}
          </div>
          {!sidebarCollapsed && user && (
            <div className="px-2 py-1">
              <p className="text-xs font-medium truncate">{user.name || "Admin"}</p>
              <p className="text-xs text-sidebar-foreground/50 truncate">{user.email || ""}</p>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 h-14 flex items-center justify-between px-4 bg-background border-b border-border/50">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 rounded-lg hover:bg-secondary transition-colors"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
        <span className="font-heading font-bold text-lg">Admin Panel</span>
        <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-secondary transition-colors">
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-14 bottom-0 w-64 bg-sidebar border-r border-sidebar-border overflow-y-auto">
            <nav className="py-2 px-2">
              {SIDEBAR_ITEMS.map((item) => {
                const isActive = activeTab === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all mb-0.5 ${
                      isActive
                        ? "bg-sidebar-primary text-sidebar-primary-foreground"
                        : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="border-t border-sidebar-border p-3">
              <button
                onClick={logout}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-colors w-full"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto md:pt-0 pt-14">
        <div className="p-6 max-w-6xl mx-auto">
          {/* Page Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
              <ActiveIcon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-heading font-bold">
                {SIDEBAR_ITEMS.find((i) => i.id === activeTab)?.label}
              </h1>
            </div>
          </div>

          {/* Tab Content */}
          {activeTab === "dashboard" && <DashboardTab />}
          {activeTab === "users" && <UsersTab />}
          {activeTab === "pricing" && <PricingTab />}
          {activeTab === "shipping" && <DirectoryTab type="shipping" />}
          {activeTab === "insurance" && <DirectoryTab type="insurance" />}
          {activeTab === "partsShops" && <DirectoryTab type="parts" />}
          {activeTab === "partsPrices" && <PartsPricesTab />}
          {activeTab === "aiCosts" && <AiCostsTab />}
          {activeTab === "feeGuide" && <FeeGuideEditorTab />}
          {activeTab === "dealQueue" && <DealQueueTab />}
          {activeTab === "quoteRequests" && <QuoteRequestsTab />}
          {activeTab === "shippingRates" && <ShippingRatesTab />}
          {activeTab === "settings" && <SiteSettingsTab />}
        </div>
      </main>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// DASHBOARD TAB
// ═══════════════════════════════════════════════════════════════
function DashboardTab() {
  const { data: stats, isLoading } = trpc.admin.getDashboardStats.useQuery();

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Users className="w-5 h-5" />} label="Total Clients" value={stats?.totalClients ?? 0} color="primary" />
        <StatCard icon={<UserCheck className="w-5 h-5" />} label="Active Clients" value={stats?.activeClients ?? 0} color="emerald" />
        <StatCard icon={<Clock className="w-5 h-5" />} label="Pending Approval" value={stats?.pendingClients ?? 0} color="amber" />
        <StatCard icon={<Search className="w-5 h-5" />} label="Total VIN Searches" value={stats?.totalVinSearches ?? 0} color="blue" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard icon={<Activity className="w-5 h-5" />} label="VIN Searches (Month)" value={stats?.monthlyVinSearches ?? 0} color="violet" />
        <StatCard icon={<CreditCard className="w-5 h-5" />} label="Active Subscriptions" value={stats?.activeSubscriptions ?? 0} color="emerald" />
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label="Monthly Revenue" value={`${((stats?.monthlyRevenueAED ?? 0) / 100).toFixed(0)} AED`} color="primary" isText />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// USERS TAB — Full CRUD with approve/reject + VIN management
// ═══════════════════════════════════════════════════════════════
function UsersTab() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newDisplayName, setNewDisplayName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [editingVin, setEditingVin] = useState<{ accountId: number; type: "limit" | "bonus"; value: string } | null>(null);

  const { data: accounts = [], refetch } = trpc.accounts.listAllAccounts.useQuery();

  const createMutation = trpc.accounts.createAccount.useMutation({
    onSuccess: () => {
      toast.success("Account created");
      setNewUsername(""); setNewPassword(""); setNewDisplayName(""); setNewEmail(""); setNewPhone("");
      setShowCreateDialog(false);
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.accounts.deleteAccount.useMutation({
    onSuccess: () => { toast.success("Account deleted"); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const statusMutation = trpc.accounts.updateAccountStatus.useMutation({
    onSuccess: (data) => { toast.success(`Account ${data.status}`); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const setVinLimitMutation = trpc.siteConfig.setUserVinLimit.useMutation({
    onSuccess: () => { toast.success("VIN limit updated"); setEditingVin(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const addBonusMutation = trpc.siteConfig.addBonusVinCredits.useMutation({
    onSuccess: (data) => { toast.success(`Added credits. New total: ${data.newTotal}`); setEditingVin(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newPassword) { toast.error("Username and password required"); return; }
    createMutation.mutate({ username: newUsername, password: newPassword, displayName: newDisplayName || undefined, email: newEmail || undefined, phoneNumber: newPhone || undefined });
  };

  const pendingAccounts = accounts.filter((a) => a.status === "pending");
  const otherAccounts = accounts.filter((a) => a.status !== "pending");

  return (
    <div className="space-y-6">
      {/* Actions */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {accounts.length} total accounts — {pendingAccounts.length} pending
        </p>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="w-4 h-4 mr-2" /> Create Account
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Client Account</DialogTitle>
              <DialogDescription>Create a new username/password account for a client</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-3">
              <Input placeholder="Username *" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} />
              <Input type="password" placeholder="Password *" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
              <Input placeholder="Display Name" value={newDisplayName} onChange={(e) => setNewDisplayName(e.target.value)} />
              <Input type="tel" placeholder="UAE Phone (+971501234567)" value={newPhone} onChange={(e) => setNewPhone(e.target.value)} />
              <Input type="email" placeholder="Email (optional)" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
              <div className="flex gap-3 pt-2">
                <Button type="submit" className="flex-1" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create"}
                </Button>
                <Button type="button" variant="outline" className="flex-1" onClick={() => setShowCreateDialog(false)}>Cancel</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pending Approvals */}
      {pendingAccounts.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-amber-400 mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" /> Pending Approvals ({pendingAccounts.length})
          </h3>
          <div className="space-y-2">
            {pendingAccounts.map((a) => (
              <UserRow
                key={a.id}
                account={a}
                showApproval
                onApprove={() => statusMutation.mutate({ id: a.id, status: "approved" })}
                onReject={() => statusMutation.mutate({ id: a.id, status: "rejected" })}
                onDelete={() => deleteMutation.mutate({ id: a.id })}
                onEditVin={(type) => setEditingVin({ accountId: a.id, type, value: "" })}
              />
            ))}
          </div>
        </div>
      )}

      {/* All Accounts */}
      <div className="rounded-xl border border-border/50 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/30 bg-secondary/30">
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Client</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Phone</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
              <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">VIN Limit</th>
              <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Bonus</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Joined</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {otherAccounts.map((a) => (
              <tr key={a.id} className="border-b border-border/20 hover:bg-secondary/20 transition-colors">
                <td className="px-4 py-3">
                  <p className="text-sm font-medium">{a.displayName || a.username}</p>
                  <p className="text-xs text-muted-foreground">{a.email || `@${a.username}`}</p>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm text-foreground" dir="ltr">{a.phoneNumber || "—"}</span>
                </td>
                <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                <td className="px-4 py-3 text-center">
                  <button
                    onClick={() => setEditingVin({ accountId: a.id, type: "limit", value: String(a.vinLimitOverride ?? "") })}
                    className="text-sm font-medium hover:text-primary transition-colors"
                  >
                    {a.vinLimitOverride !== null && a.vinLimitOverride !== undefined ? a.vinLimitOverride : "Plan Default"}
                  </button>
                </td>
                <td className="px-4 py-3 text-center">
                  <button
                    onClick={() => setEditingVin({ accountId: a.id, type: "bonus", value: "" })}
                    className="text-sm font-medium hover:text-primary transition-colors"
                  >
                    {a.bonusVinCredits || 0}
                  </button>
                </td>
                <td className="px-4 py-3 text-sm text-muted-foreground">
                  {new Date(a.createdAt).toLocaleDateString("en-AE", { month: "short", day: "numeric", year: "numeric" })}
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-1">
                    {a.status === "rejected" && (
                      <Button size="sm" variant="outline" className="text-emerald-400 border-emerald-500/30 h-8" onClick={() => statusMutation.mutate({ id: a.id, status: "approved" })}>
                        <UserCheck className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    <Button size="sm" variant="outline" className="text-destructive border-destructive/30 h-8" onClick={() => { if (confirm("Delete?")) deleteMutation.mutate({ id: a.id }); }}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* VIN Edit Dialog */}
      {editingVin && (
        <Dialog open onOpenChange={() => setEditingVin(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingVin.type === "limit" ? "Set VIN Limit Override" : "Add Bonus VIN Credits"}</DialogTitle>
              <DialogDescription>
                {editingVin.type === "limit"
                  ? "Set a custom VIN limit for this user. Leave empty to use plan default."
                  : "Add extra VIN credits on top of the user's plan limit."}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <Input
                type="number"
                placeholder={editingVin.type === "limit" ? "e.g., 50 (empty = plan default)" : "e.g., 20"}
                value={editingVin.value}
                onChange={(e) => setEditingVin({ ...editingVin, value: e.target.value })}
              />
              <div className="flex gap-3">
                <Button
                  className="flex-1"
                  onClick={() => {
                    if (editingVin.type === "limit") {
                      const val = editingVin.value.trim() === "" ? null : parseInt(editingVin.value);
                      setVinLimitMutation.mutate({ accountId: editingVin.accountId, vinLimitOverride: val });
                    } else {
                      const credits = parseInt(editingVin.value);
                      if (!credits || credits < 1) { toast.error("Enter a positive number"); return; }
                      addBonusMutation.mutate({ accountId: editingVin.accountId, credits });
                    }
                  }}
                  disabled={setVinLimitMutation.isPending || addBonusMutation.isPending}
                >
                  {(setVinLimitMutation.isPending || addBonusMutation.isPending) ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                  Save
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditingVin(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function UserRow({ account, showApproval, onApprove, onReject, onDelete, onEditVin }: {
  account: any;
  showApproval?: boolean;
  onApprove: () => void;
  onReject: () => void;
  onDelete: () => void;
  onEditVin: (type: "limit" | "bonus") => void;
}) {
  return (
    <Card className="border-amber-500/30 bg-amber-500/5">
      <CardContent className="pt-4 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium">{account.displayName || account.username}</p>
            <p className="text-xs text-muted-foreground">{account.phoneNumber || account.email || `@${account.username}`}</p>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="text-emerald-400 border-emerald-500/30" onClick={onApprove}>
              <UserCheck className="w-4 h-4 mr-1" /> Approve
            </Button>
            <Button size="sm" variant="outline" className="text-red-400 border-red-500/30" onClick={onReject}>
              <UserX className="w-4 h-4 mr-1" /> Reject
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════
// PRICING TAB
// ═══════════════════════════════════════════════════════════════
function PricingTab() {
  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [newFeature, setNewFeature] = useState("");

  const { data: plans, isLoading, refetch } = trpc.admin.getPlans.useQuery();

  const updatePlan = trpc.admin.updatePlan.useMutation({
    onSuccess: () => { toast.success("Plan updated"); setEditingPlan(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });
  const createPlan = trpc.admin.createPlan.useMutation({
    onSuccess: () => { toast.success("Plan created"); setEditingPlan(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });
  const deletePlan = trpc.admin.deletePlan.useMutation({
    onSuccess: () => { toast.success("Plan deleted"); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const formatAED = (fils: number) => (fils / 100).toFixed(0);
  const parseFils = (aed: string) => Math.round(parseFloat(aed || "0") * 100);

  const handleSave = () => {
    if (!editingPlan) return;
    if (editingPlan.id) {
      const { id, features, slug, ...rest } = editingPlan;
      updatePlan.mutate({ id, features, ...rest });
    } else {
      createPlan.mutate({ ...editingPlan, features: editingPlan.features });
    }
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={() => setEditingPlan({ name: "", slug: "", description: "", priceMonthlyAED: 0, priceAnnualAED: 0, vinLimitPerMonth: 10, features: [], isActive: 1, isPopular: 0, sortOrder: (plans?.length ?? 0) + 1 })}>
          <Plus className="w-4 h-4 mr-2" /> Add Plan
        </Button>
      </div>

      <div className="grid gap-4">
        {plans?.map((plan) => (
          <div key={plan.id} className={`rounded-xl border p-5 ${plan.isPopular ? "border-primary/50 shadow-lg shadow-primary/10" : "border-border/50"} bg-card`}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-heading font-bold">{plan.name}</h3>
                {plan.isPopular === 1 && <span className="px-2 py-0.5 text-xs font-semibold bg-primary/15 text-primary rounded-full">Popular</span>}
                {plan.isActive === 0 && <span className="px-2 py-0.5 text-xs font-semibold bg-muted text-muted-foreground rounded-full">Hidden</span>}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setEditingPlan({ ...plan })}>Edit</Button>
                <Button variant="outline" size="sm" className="text-destructive border-destructive/30" onClick={() => { if (confirm("Delete?")) deletePlan.mutate({ id: plan.id }); }}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-3">{plan.description}</p>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="rounded-lg bg-secondary/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Monthly</p>
                <p className="text-lg font-bold">{plan.priceMonthlyAED === 0 ? "Custom" : `${formatAED(plan.priceMonthlyAED)} AED`}</p>
              </div>
              <div className="rounded-lg bg-secondary/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Annual</p>
                <p className="text-lg font-bold">{plan.priceAnnualAED === 0 ? "Custom" : `${formatAED(plan.priceAnnualAED)} AED`}</p>
              </div>
              <div className="rounded-lg bg-secondary/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">VIN Limit</p>
                <p className="text-lg font-bold">{plan.vinLimitPerMonth === 0 ? "Unlimited" : `${plan.vinLimitPerMonth}/mo`}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {plan.features.map((f: string, i: number) => (
                <span key={i} className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-lg">{f}</span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Edit Dialog */}
      {editingPlan && (
        <Dialog open onOpenChange={() => setEditingPlan(null)}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingPlan.id ? "Edit Plan" : "Create Plan"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-xs font-semibold text-muted-foreground">Name</label><Input value={editingPlan.name} onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })} className="mt-1" /></div>
                {!editingPlan.id && <div><label className="text-xs font-semibold text-muted-foreground">Slug</label><Input value={editingPlan.slug} onChange={(e) => setEditingPlan({ ...editingPlan, slug: e.target.value })} className="mt-1" /></div>}
              </div>
              <div><label className="text-xs font-semibold text-muted-foreground">Description</label><Input value={editingPlan.description || ""} onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })} className="mt-1" /></div>
              <div className="grid grid-cols-3 gap-3">
                <div><label className="text-xs font-semibold text-muted-foreground">Monthly (AED)</label><Input type="number" value={formatAED(editingPlan.priceMonthlyAED)} onChange={(e) => setEditingPlan({ ...editingPlan, priceMonthlyAED: parseFils(e.target.value) })} className="mt-1" /></div>
                <div><label className="text-xs font-semibold text-muted-foreground">Annual (AED)</label><Input type="number" value={formatAED(editingPlan.priceAnnualAED)} onChange={(e) => setEditingPlan({ ...editingPlan, priceAnnualAED: parseFils(e.target.value) })} className="mt-1" /></div>
                <div><label className="text-xs font-semibold text-muted-foreground">VIN Limit/mo</label><Input type="number" value={editingPlan.vinLimitPerMonth} onChange={(e) => setEditingPlan({ ...editingPlan, vinLimitPerMonth: parseInt(e.target.value) || 0 })} className="mt-1" placeholder="0=unlimited" /></div>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground">Features</label>
                <div className="mt-2 space-y-2">
                  {editingPlan.features.map((f: string, i: number) => (
                    <div key={i} className="flex gap-2">
                      <Input value={f} onChange={(e) => { const u = [...editingPlan.features]; u[i] = e.target.value; setEditingPlan({ ...editingPlan, features: u }); }} className="flex-1" />
                      <Button variant="outline" size="sm" className="text-destructive" onClick={() => setEditingPlan({ ...editingPlan, features: editingPlan.features.filter((_: string, idx: number) => idx !== i) })}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input value={newFeature} onChange={(e) => setNewFeature(e.target.value)} placeholder="Add feature..." className="flex-1" onKeyDown={(e) => { if (e.key === "Enter" && newFeature.trim()) { e.preventDefault(); setEditingPlan({ ...editingPlan, features: [...editingPlan.features, newFeature.trim()] }); setNewFeature(""); } }} />
                    <Button variant="outline" size="sm" onClick={() => { if (newFeature.trim()) { setEditingPlan({ ...editingPlan, features: [...editingPlan.features, newFeature.trim()] }); setNewFeature(""); } }}><Plus className="w-3.5 h-3.5" /></Button>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editingPlan.isActive === 1} onChange={(e) => setEditingPlan({ ...editingPlan, isActive: e.target.checked ? 1 : 0 })} className="accent-primary w-4 h-4" />
                  <span className="text-sm"><Eye className="w-4 h-4 inline mr-1" />Visible</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editingPlan.isPopular === 1} onChange={(e) => setEditingPlan({ ...editingPlan, isPopular: e.target.checked ? 1 : 0 })} className="accent-primary w-4 h-4" />
                  <span className="text-sm"><Star className="w-4 h-4 inline mr-1" />Popular</span>
                </label>
              </div>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" onClick={handleSave} disabled={updatePlan.isPending || createPlan.isPending}>
                  {(updatePlan.isPending || createPlan.isPending) ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                  {editingPlan.id ? "Save" : "Create"}
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditingPlan(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// DIRECTORY TAB — Shipping / Insurance / Parts Shops
// ═══════════════════════════════════════════════════════════════
function DirectoryTab({ type }: { type: "shipping" | "insurance" | "parts" }) {
  const [editing, setEditing] = useState<any>(null);

  // Queries
  const shippingQuery = trpc.directory.listShippingCompanies.useQuery(undefined, { enabled: type === "shipping" });
  const insuranceQuery = trpc.directory.listInsuranceCompanies.useQuery(undefined, { enabled: type === "insurance" });
  const partsQuery = trpc.directory.listPartsShops.useQuery(undefined, { enabled: type === "parts" });

  const data = type === "shipping" ? shippingQuery.data : type === "insurance" ? insuranceQuery.data : partsQuery.data;
  const isLoading = type === "shipping" ? shippingQuery.isLoading : type === "insurance" ? insuranceQuery.isLoading : partsQuery.isLoading;
  const refetch = type === "shipping" ? shippingQuery.refetch : type === "insurance" ? insuranceQuery.refetch : partsQuery.refetch;

  // Mutations
  const createShipping = trpc.directory.createShippingCompany.useMutation({ onSuccess: () => { toast.success("Created"); setEditing(null); refetch(); } });
  const updateShipping = trpc.directory.updateShippingCompany.useMutation({ onSuccess: () => { toast.success("Updated"); setEditing(null); refetch(); } });
  const deleteShipping = trpc.directory.deleteShippingCompany.useMutation({ onSuccess: () => { toast.success("Deleted"); refetch(); } });

  const createInsurance = trpc.directory.createInsuranceCompany.useMutation({ onSuccess: () => { toast.success("Created"); setEditing(null); refetch(); } });
  const updateInsurance = trpc.directory.updateInsuranceCompany.useMutation({ onSuccess: () => { toast.success("Updated"); setEditing(null); refetch(); } });
  const deleteInsurance = trpc.directory.deleteInsuranceCompany.useMutation({ onSuccess: () => { toast.success("Deleted"); refetch(); } });

  const createParts = trpc.directory.createPartsShop.useMutation({ onSuccess: () => { toast.success("Created"); setEditing(null); refetch(); } });
  const updateParts = trpc.directory.updatePartsShop.useMutation({ onSuccess: () => { toast.success("Updated"); setEditing(null); refetch(); } });
  const deleteParts = trpc.directory.deletePartsShop.useMutation({ onSuccess: () => { toast.success("Deleted"); refetch(); } });

  const handleSave = () => {
    if (!editing) return;
    const { id, createdAt, updatedAt, ...rest } = editing;
    if (type === "shipping") {
      id ? updateShipping.mutate({ id, ...rest }) : createShipping.mutate(rest);
    } else if (type === "insurance") {
      id ? updateInsurance.mutate({ id, ...rest }) : createInsurance.mutate(rest);
    } else {
      id ? updateParts.mutate({ id, ...rest }) : createParts.mutate(rest);
    }
  };

  const handleDelete = (id: number) => {
    if (!confirm("Delete this entry?")) return;
    if (type === "shipping") deleteShipping.mutate({ id });
    else if (type === "insurance") deleteInsurance.mutate({ id });
    else deleteParts.mutate({ id });
  };

  const toggleActive = (item: any) => {
    const newActive = item.isActive === 1 ? 0 : 1;
    const { id, createdAt, updatedAt, ...rest } = item;
    if (type === "shipping") updateShipping.mutate({ id, isActive: newActive });
    else if (type === "insurance") updateInsurance.mutate({ id, isActive: newActive });
    else updateParts.mutate({ id, isActive: newActive });
  };

  const typeLabel = type === "shipping" ? "Shipping Company" : type === "insurance" ? "Insurance Company" : "Parts Shop";

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={() => setEditing({ name: "", email: "", phone: "", website: "", location: "", description: "", isActive: 1, sortOrder: 0, ...(type === "shipping" ? { services: "" } : type === "insurance" ? { coverageTypes: "" } : { area: "", specialties: "" }) })}>
          <Plus className="w-4 h-4 mr-2" /> Add {typeLabel}
        </Button>
      </div>

      {(!data || data.length === 0) ? (
        <div className="text-center py-12 text-muted-foreground">
          <p>No entries yet. Add your first {typeLabel.toLowerCase()}.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {data.map((item: any) => (
            <div key={item.id} className={`rounded-xl border p-4 bg-card transition-all ${item.isActive ? "border-border/50" : "border-border/30 opacity-60"}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold">{item.name}</h3>
                    {!item.isActive && <span className="px-2 py-0.5 text-xs bg-muted text-muted-foreground rounded-full">Hidden</span>}
                  </div>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    {item.email && <p>Email: {item.email}</p>}
                    {item.phone && <p>Phone: {item.phone}</p>}
                    {item.location && <p>Location: {item.location}</p>}
                    {item.services && <p>Services: {item.services}</p>}
                    {item.coverageTypes && <p>Coverage: {item.coverageTypes}</p>}
                    {item.area && <p>Area: {item.area}</p>}
                    {item.specialties && <p>Specialties: {item.specialties}</p>}
                    {item.description && <p className="mt-1 italic">{item.description}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => toggleActive(item)} title={item.isActive ? "Hide" : "Show"}>
                    {item.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setEditing({ ...item })}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="text-destructive border-destructive/30" onClick={() => handleDelete(item.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit/Create Dialog */}
      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editing.id ? `Edit ${typeLabel}` : `Add ${typeLabel}`}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div><label className="text-xs font-semibold text-muted-foreground">Name *</label><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className="mt-1" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-xs font-semibold text-muted-foreground">Email</label><Input value={editing.email || ""} onChange={(e) => setEditing({ ...editing, email: e.target.value })} className="mt-1" /></div>
                <div><label className="text-xs font-semibold text-muted-foreground">Phone</label><Input value={editing.phone || ""} onChange={(e) => setEditing({ ...editing, phone: e.target.value })} className="mt-1" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-xs font-semibold text-muted-foreground">Website</label><Input value={editing.website || ""} onChange={(e) => setEditing({ ...editing, website: e.target.value })} className="mt-1" /></div>
                <div><label className="text-xs font-semibold text-muted-foreground">Location</label><Input value={editing.location || ""} onChange={(e) => setEditing({ ...editing, location: e.target.value })} className="mt-1" /></div>
              </div>
              {type === "shipping" && (
                <div><label className="text-xs font-semibold text-muted-foreground">Services (comma-separated)</label><Input value={editing.services || ""} onChange={(e) => setEditing({ ...editing, services: e.target.value })} placeholder="US to UAE, Container, RoRo" className="mt-1" /></div>
              )}
              {type === "insurance" && (
                <div><label className="text-xs font-semibold text-muted-foreground">Coverage Types (comma-separated)</label><Input value={editing.coverageTypes || ""} onChange={(e) => setEditing({ ...editing, coverageTypes: e.target.value })} placeholder="Comprehensive, Third Party, Salvage" className="mt-1" /></div>
              )}
              {type === "parts" && (
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="text-xs font-semibold text-muted-foreground">Area</label><Input value={editing.area || ""} onChange={(e) => setEditing({ ...editing, area: e.target.value })} placeholder="Sharjah Industrial" className="mt-1" /></div>
                  <div><label className="text-xs font-semibold text-muted-foreground">Specialties</label><Input value={editing.specialties || ""} onChange={(e) => setEditing({ ...editing, specialties: e.target.value })} placeholder="Japanese, American" className="mt-1" /></div>
                </div>
              )}
              <div><label className="text-xs font-semibold text-muted-foreground">Description</label><Input value={editing.description || ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="mt-1" /></div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={editing.isActive === 1} onChange={(e) => setEditing({ ...editing, isActive: e.target.checked ? 1 : 0 })} className="accent-primary w-4 h-4" />
                <span className="text-sm">Visible on client site</span>
              </label>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" /> {editing.id ? "Save" : "Create"}
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SPARE PARTS PRICES TAB
// ═══════════════════════════════════════════════════════════════
function PartsPricesTab() {
  const [editing, setEditing] = useState<any>(null);
  const { data: parts, isLoading, refetch } = trpc.siteConfig.getPartsPrices.useQuery();

  const upsertMutation = trpc.siteConfig.upsertPartPrice.useMutation({
    onSuccess: () => { toast.success("Saved"); setEditing(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.siteConfig.deletePartPrice.useMutation({
    onSuccess: () => { toast.success("Deleted"); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) return <LoadingSpinner />;

  const categories = Array.from(new Set(parts?.map((p) => p.category) ?? []));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{parts?.length ?? 0} parts configured</p>
        <Button onClick={() => setEditing({ partId: "", partName: "", category: "", priceAED: 0, isActive: 1 })}>
          <Plus className="w-4 h-4 mr-2" /> Add Part
        </Button>
      </div>

      {categories.map((cat) => (
        <div key={cat}>
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">{cat}</h3>
          <div className="rounded-xl border border-border/50 overflow-hidden mb-4">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/30 bg-secondary/30">
                  <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Part ID</th>
                  <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Name</th>
                  <th className="text-right px-4 py-2 text-xs font-semibold text-muted-foreground">Price (AED)</th>
                  <th className="text-center px-4 py-2 text-xs font-semibold text-muted-foreground">Active</th>
                  <th className="text-right px-4 py-2 text-xs font-semibold text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {parts?.filter((p) => p.category === cat).map((p) => (
                  <tr key={p.partId} className="border-b border-border/20 hover:bg-secondary/20">
                    <td className="px-4 py-2 text-sm font-mono">{p.partId}</td>
                    <td className="px-4 py-2 text-sm">{p.partName}</td>
                    <td className="px-4 py-2 text-sm text-right font-semibold">{p.priceAED.toLocaleString()}</td>
                    <td className="px-4 py-2 text-center">{p.isActive ? <CheckCircle className="w-4 h-4 text-emerald-400 mx-auto" /> : <XCircle className="w-4 h-4 text-muted-foreground mx-auto" />}</td>
                    <td className="px-4 py-2 text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="outline" size="sm" className="h-7" onClick={() => setEditing({ ...p })}><Edit2 className="w-3.5 h-3.5" /></Button>
                        <Button variant="outline" size="sm" className="h-7 text-destructive border-destructive/30" onClick={() => { if (confirm("Delete?")) deleteMutation.mutate({ partId: p.partId }); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {(!parts || parts.length === 0) && (
        <div className="text-center py-12 text-muted-foreground">
          <p>No parts prices configured yet. Add parts or use "Seed from defaults" to populate.</p>
        </div>
      )}

      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing.id ? "Edit Part Price" : "Add Part Price"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><label className="text-xs font-semibold text-muted-foreground">Part ID</label><Input value={editing.partId} onChange={(e) => setEditing({ ...editing, partId: e.target.value })} placeholder="e.g., front-bumper" className="mt-1" disabled={!!editing.id} /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Part Name</label><Input value={editing.partName} onChange={(e) => setEditing({ ...editing, partName: e.target.value })} className="mt-1" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-xs font-semibold text-muted-foreground">Category</label><Input value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} placeholder="Body, Engine, etc." className="mt-1" /></div>
                <div><label className="text-xs font-semibold text-muted-foreground">Price (AED)</label><Input type="number" value={editing.priceAED} onChange={(e) => setEditing({ ...editing, priceAED: parseInt(e.target.value) || 0 })} className="mt-1" /></div>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={editing.isActive === 1} onChange={(e) => setEditing({ ...editing, isActive: e.target.checked ? 1 : 0 })} className="accent-primary w-4 h-4" />
                <span className="text-sm">Active in calculator</span>
              </label>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" onClick={() => upsertMutation.mutate(editing)} disabled={upsertMutation.isPending}>
                  <Save className="w-4 h-4 mr-2" /> Save
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// AI COST SETTINGS TAB
// ═══════════════════════════════════════════════════════════════
function AiCostsTab() {
  const [editing, setEditing] = useState<any>(null);
  const { data: settings, isLoading, refetch } = trpc.siteConfig.getAiCostSettings.useQuery();

  const upsertMutation = trpc.siteConfig.upsertAiCostSetting.useMutation({
    onSuccess: () => { toast.success("Saved"); setEditing(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Configure cost multipliers and base prices used by AI damage analysis</p>
        <Button onClick={() => setEditing({ settingKey: "", settingValue: "", label: "", description: "" })}>
          <Plus className="w-4 h-4 mr-2" /> Add Setting
        </Button>
      </div>

      <div className="rounded-xl border border-border/50 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/30 bg-secondary/30">
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Key</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Label</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Value</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {settings?.map((s) => (
              <tr key={s.settingKey} className="border-b border-border/20 hover:bg-secondary/20">
                <td className="px-4 py-3 text-sm font-mono">{s.settingKey}</td>
                <td className="px-4 py-3 text-sm">{s.label || "-"}</td>
                <td className="px-4 py-3 text-sm text-right font-semibold">{s.settingValue}</td>
                <td className="px-4 py-3 text-right">
                  <Button variant="outline" size="sm" className="h-7" onClick={() => setEditing({ ...s })}>
                    <Edit2 className="w-3.5 h-3.5" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {(!settings || settings.length === 0) && (
        <div className="text-center py-12 text-muted-foreground">
          <p>No AI cost settings configured yet.</p>
        </div>
      )}

      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing.id ? "Edit AI Cost Setting" : "Add AI Cost Setting"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><label className="text-xs font-semibold text-muted-foreground">Key</label><Input value={editing.settingKey} onChange={(e) => setEditing({ ...editing, settingKey: e.target.value })} placeholder="e.g., cost_multiplier" className="mt-1" disabled={!!editing.id} /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Label</label><Input value={editing.label || ""} onChange={(e) => setEditing({ ...editing, label: e.target.value })} className="mt-1" /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Value</label><Input value={editing.settingValue} onChange={(e) => setEditing({ ...editing, settingValue: e.target.value })} className="mt-1" /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Description</label><Input value={editing.description || ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="mt-1" /></div>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" onClick={() => upsertMutation.mutate(editing)} disabled={upsertMutation.isPending}>
                  <Save className="w-4 h-4 mr-2" /> Save
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// DEAL QUEUE TAB (embedded — links to full page)
// ═══════════════════════════════════════════════════════════════
function DealQueueTab() {
  const { data: deals, isLoading } = trpc.dealQueue.list.useQuery();

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">{deals?.length ?? 0} saved deals</p>

      {(!deals || deals.length === 0) ? (
        <div className="text-center py-12 text-muted-foreground">
          <ClipboardList className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>No deals saved yet</p>
        </div>
      ) : (
        <div className="rounded-xl border border-border/50 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/30 bg-secondary/30">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">VIN</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Vehicle</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Bid (USD)</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Total (AED)</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Profit (AED)</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Date</th>
              </tr>
            </thead>
            <tbody>
              {deals.map((d: any) => (
                <tr key={d.id} className="border-b border-border/20 hover:bg-secondary/20">
                  <td className="px-4 py-3 text-sm font-mono">{d.vin}</td>
                  <td className="px-4 py-3 text-sm">{typeof d.vehicleInfo === 'object' && d.vehicleInfo ? `${d.vehicleInfo.year || ''} ${d.vehicleInfo.make || ''} ${d.vehicleInfo.model || ''}`.trim() : (d.vehicleInfo || '—')}</td>
                  <td className="px-4 py-3 text-sm text-right">${d.bidAmountUSD?.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-right font-semibold">{d.totalCostAED?.toLocaleString()} AED</td>
                  <td className={`px-4 py-3 text-sm text-right font-semibold ${d.estimatedProfitAED >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {d.estimatedProfitAED?.toLocaleString()} AED
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">
                    {new Date(d.createdAt).toLocaleDateString("en-AE", { month: "short", day: "numeric" })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SITE SETTINGS TAB — Feature toggles
// ═══════════════════════════════════════════════════════════════
function SiteSettingsTab() {
  const { data: settings, isLoading, refetch } = trpc.siteConfig.getAllSettings.useQuery();
  const [editing, setEditing] = useState<any>(null);

  const upsertMutation = trpc.siteConfig.upsertSetting.useMutation({
    onSuccess: () => { toast.success("Setting saved"); setEditing(null); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const toggleSetting = (key: string, currentValue: string) => {
    const newValue = currentValue === "true" ? "false" : "true";
    upsertMutation.mutate({ key, value: newValue });
  };

  if (isLoading) return <LoadingSpinner />;

  // Known feature toggles
  const featureToggles = [
    { key: "shipping_quotes_enabled", label: "Shipping Quote Requests", desc: "Allow clients to request shipping quotes from listed companies" },
    { key: "insurance_quotes_enabled", label: "Insurance Quote Requests", desc: "Allow clients to request insurance quotes from listed companies" },
    { key: "parts_quotes_enabled", label: "Parts Shop Quote Requests", desc: "Allow clients to request quotes from spare parts shops" },
  ];

  const settingsMap = new Map(settings?.map((s) => [s.settingKey, s.settingValue]) ?? []);

  return (
    <div className="space-y-6">
      {/* Feature Toggles */}
      <div>
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Feature Toggles</h3>
        <div className="space-y-3">
          {featureToggles.map((ft) => {
            const currentValue = settingsMap.get(ft.key) ?? "false";
            const isEnabled = currentValue === "true";
            return (
              <div key={ft.key} className="flex items-center justify-between rounded-xl border border-border/50 p-4 bg-card">
                <div>
                  <p className="font-medium text-sm">{ft.label}</p>
                  <p className="text-xs text-muted-foreground">{ft.desc}</p>
                </div>
                <button
                  onClick={() => toggleSetting(ft.key, currentValue)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${isEnabled ? "bg-primary" : "bg-muted"}`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${isEnabled ? "left-6" : "left-0.5"}`} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Settings */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Custom Settings</h3>
          <Button size="sm" variant="outline" onClick={() => setEditing({ key: "", value: "", label: "", category: "general" })}>
            <Plus className="w-3.5 h-3.5 mr-1" /> Add
          </Button>
        </div>
        <div className="rounded-xl border border-border/50 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/30 bg-secondary/30">
                <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Key</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Label</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Value</th>
                <th className="text-right px-4 py-2 text-xs font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {settings?.filter((s) => !featureToggles.some((ft) => ft.key === s.settingKey)).map((s) => (
                <tr key={s.settingKey} className="border-b border-border/20 hover:bg-secondary/20">
                  <td className="px-4 py-2 text-sm font-mono">{s.settingKey}</td>
                  <td className="px-4 py-2 text-sm">{s.label || "-"}</td>
                  <td className="px-4 py-2 text-sm">{s.settingValue}</td>
                  <td className="px-4 py-2 text-right">
                    <Button variant="outline" size="sm" className="h-7" onClick={() => setEditing({ key: s.settingKey, value: s.settingValue, label: s.label, category: s.category })}>
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>Edit Setting</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><label className="text-xs font-semibold text-muted-foreground">Key</label><Input value={editing.key} onChange={(e) => setEditing({ ...editing, key: e.target.value })} className="mt-1" /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Label</label><Input value={editing.label || ""} onChange={(e) => setEditing({ ...editing, label: e.target.value })} className="mt-1" /></div>
              <div><label className="text-xs font-semibold text-muted-foreground">Value</label><Input value={editing.value} onChange={(e) => setEditing({ ...editing, value: e.target.value })} className="mt-1" /></div>
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" onClick={() => upsertMutation.mutate(editing)} disabled={upsertMutation.isPending}>
                  <Save className="w-4 h-4 mr-2" /> Save
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// FEE GUIDE EDITOR TAB
// ═══════════════════════════════════════════════════════════════

const FEE_CATEGORIES = [
  { id: "copart_buyer_fee", label: "Copart/IAAI Buyer Fees", desc: "Tiered buyer fees based on bid amount" },
  { id: "copart_virtual_fee", label: "Virtual Bid Fees", desc: "Fees for online bidding" },
  { id: "fixed_fee", label: "Fixed Fees", desc: "Gate fee, environmental fee, title fee, etc." },
  { id: "import_tax", label: "Import Tax & Rates", desc: "UAE customs duty, VAT, exchange rate" },
  { id: "emirate_registration", label: "Emirate Registration Fees", desc: "Registration fees per emirate" },
  { id: "shipping_method", label: "Shipping Methods", desc: "Available shipping methods and costs" },
];

function FeeGuideEditorTab() {
  const { data: allFees, isLoading, refetch } = trpc.siteConfig.getFeeSchedules.useQuery();
  const [activeCategory, setActiveCategory] = useState("copart_buyer_fee");
  const [editing, setEditing] = useState<any>(null);

  const upsertMutation = trpc.siteConfig.upsertFeeSchedule.useMutation({
    onSuccess: () => { toast.success("Fee updated"); setEditing(null); refetch(); },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = trpc.siteConfig.deleteFeeSchedule.useMutation({
    onSuccess: () => { toast.success("Fee deleted"); refetch(); },
    onError: (err: any) => toast.error(err.message),
  });

  if (isLoading) return <LoadingSpinner />;

  const categoryFees = allFees?.filter((f) => f.category === activeCategory) ?? [];
  categoryFees.sort((a, b) => a.sortOrder - b.sortOrder);

  const renderValue = (fee: any) => {
    try {
      const val = JSON.parse(fee.value);
      if (activeCategory === "copart_buyer_fee" || activeCategory === "copart_virtual_fee") {
        if (val.percent) return `${val.percent}%`;
        return `$${val.fee}`;
      }
      if (activeCategory === "fixed_fee") return `$${val.value}`;
      if (activeCategory === "import_tax") {
        return val.rate < 1 ? `${(val.rate * 100).toFixed(1)}%` : val.rate.toString();
      }
      if (activeCategory === "emirate_registration") return `AED ${val.total}`;
      if (activeCategory === "shipping_method") return `$${val.costMin} — $${val.costMax}`;
      return JSON.stringify(val);
    } catch { return fee.value; }
  };

  const renderRange = (fee: any) => {
    try {
      const val = JSON.parse(fee.value);
      if (val.min !== undefined && val.max !== undefined) {
        return val.max ? `$${val.min.toLocaleString()} — $${val.max.toLocaleString()}` : `$${val.min.toLocaleString()}+`;
      }
      return null;
    } catch { return null; }
  };

  return (
    <div className="space-y-6">
      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {FEE_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              activeCategory === cat.id
                ? "bg-primary text-primary-foreground"
                : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Category Description */}
      <p className="text-sm text-muted-foreground">
        {FEE_CATEGORIES.find((c) => c.id === activeCategory)?.desc}
      </p>

      {/* Add Button */}
      <div className="flex justify-end">
        <Button size="sm" variant="outline" onClick={() => setEditing({ category: activeCategory, feeKey: "", label: "", value: "{}", sortOrder: categoryFees.length, isActive: 1, isNew: true })}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Add Entry
        </Button>
      </div>

      {/* Fee Table */}
      <div className="rounded-xl border border-border/50 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/30 bg-secondary/30">
              <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Label</th>
              {(activeCategory === "copart_buyer_fee" || activeCategory === "copart_virtual_fee") && (
                <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Range</th>
              )}
              <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground">Value</th>
              <th className="text-right px-4 py-2 text-xs font-semibold text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {categoryFees.map((fee) => (
              <tr key={fee.id} className="border-b border-border/20 hover:bg-secondary/20">
                <td className="px-4 py-2 text-sm font-medium">{fee.label || fee.feeKey}</td>
                {(activeCategory === "copart_buyer_fee" || activeCategory === "copart_virtual_fee") && (
                  <td className="px-4 py-2 text-sm text-muted-foreground">{renderRange(fee)}</td>
                )}
                <td className="px-4 py-2 text-sm font-mono">{renderValue(fee)}</td>
                <td className="px-4 py-2 text-right">
                  <div className="flex gap-1 justify-end">
                    <Button variant="outline" size="sm" className="h-7" onClick={() => setEditing({ ...fee, isNew: false })}>
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="outline" size="sm" className="h-7 text-red-400 hover:text-red-300" onClick={() => { if (confirm("Delete this fee entry?")) deleteMutation.mutate({ id: fee.id }); }}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {categoryFees.length === 0 && (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-sm text-muted-foreground">No fee entries for this category. Click "Add Entry" to create one.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Edit Dialog */}
      {editing && <FeeEditDialog editing={editing} setEditing={setEditing} upsertMutation={upsertMutation} activeCategory={activeCategory} />}
    </div>
  );
}

function FeeEditDialog({ editing, setEditing, upsertMutation, activeCategory }: any) {
  const [jsonValue, setJsonValue] = useState(() => {
    try {
      return typeof editing.value === "string" ? JSON.parse(editing.value) : editing.value;
    } catch { return {}; }
  });

  const handleSave = () => {
    upsertMutation.mutate({
      category: editing.category || activeCategory,
      feeKey: editing.feeKey,
      label: editing.label,
      value: JSON.stringify(jsonValue),
      sortOrder: editing.sortOrder ?? 0,
      isActive: editing.isActive ?? 1,
    });
  };

  // Render fields based on category
  const renderFields = () => {
    if (activeCategory === "copart_buyer_fee" || activeCategory === "copart_virtual_fee") {
      return (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Min ($)</label><Input type="number" value={jsonValue.min ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, min: Number(e.target.value) })} className="mt-1" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Max ($)</label><Input type="number" value={jsonValue.max ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, max: e.target.value ? Number(e.target.value) : null })} className="mt-1" placeholder="Empty = no max" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Fee ($)</label><Input type="number" value={jsonValue.fee ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, fee: e.target.value ? Number(e.target.value) : null })} className="mt-1" placeholder="Fixed fee" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Percent (%)</label><Input type="number" value={jsonValue.percent ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, percent: e.target.value ? Number(e.target.value) : undefined })} className="mt-1" placeholder="For 15k+" /></div>
          </div>
        </>
      );
    }
    if (activeCategory === "fixed_fee") {
      return (
        <div><label className="text-xs font-semibold text-muted-foreground">Value ($)</label><Input type="number" value={jsonValue.value ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, value: Number(e.target.value) })} className="mt-1" /></div>
      );
    }
    if (activeCategory === "import_tax") {
      return (
        <div><label className="text-xs font-semibold text-muted-foreground">Rate (e.g., 0.05 for 5%, or 3.685 for exchange rate)</label><Input type="number" step="0.001" value={jsonValue.rate ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, rate: Number(e.target.value) })} className="mt-1" /></div>
      );
    }
    if (activeCategory === "emirate_registration") {
      return (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Registration Fee (AED)</label><Input type="number" value={jsonValue.registrationFee ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, registrationFee: Number(e.target.value) })} className="mt-1" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Inspection Fee (AED)</label><Input type="number" value={jsonValue.inspectionFee ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, inspectionFee: Number(e.target.value) })} className="mt-1" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Plate Fee (AED)</label><Input type="number" value={jsonValue.plateFee ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, plateFee: Number(e.target.value) })} className="mt-1" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Other Fees (AED)</label><Input type="number" value={jsonValue.otherFees ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, otherFees: Number(e.target.value) })} className="mt-1" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Total (AED)</label><Input type="number" value={jsonValue.total ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, total: Number(e.target.value) })} className="mt-1" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Notes</label><Input value={jsonValue.notes ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, notes: e.target.value })} className="mt-1" /></div>
          </div>
        </>
      );
    }
    if (activeCategory === "shipping_method") {
      return (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-semibold text-muted-foreground">Cost Min ($)</label><Input type="number" value={jsonValue.costMin ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, costMin: Number(e.target.value) })} className="mt-1" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground">Cost Max ($)</label><Input type="number" value={jsonValue.costMax ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, costMax: Number(e.target.value) })} className="mt-1" /></div>
          </div>
          <div><label className="text-xs font-semibold text-muted-foreground">Transit Time</label><Input value={jsonValue.transit ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, transit: e.target.value })} className="mt-1" /></div>
          <div><label className="text-xs font-semibold text-muted-foreground">Notes</label><Input value={jsonValue.notes ?? ""} onChange={(e) => setJsonValue({ ...jsonValue, notes: e.target.value })} className="mt-1" /></div>
        </>
      );
    }
    // Fallback: raw JSON editor
    return (
      <div><label className="text-xs font-semibold text-muted-foreground">Value (JSON)</label><textarea className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-sm font-mono" rows={4} value={JSON.stringify(jsonValue, null, 2)} onChange={(e) => { try { setJsonValue(JSON.parse(e.target.value)); } catch {} }} /></div>
    );
  };

  return (
    <Dialog open onOpenChange={() => setEditing(null)}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{editing.isNew ? "Add Fee Entry" : "Edit Fee Entry"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><label className="text-xs font-semibold text-muted-foreground">Key</label><Input value={editing.feeKey} onChange={(e) => setEditing({ ...editing, feeKey: e.target.value })} className="mt-1" disabled={!editing.isNew} /></div>
          <div><label className="text-xs font-semibold text-muted-foreground">Label</label><Input value={editing.label || ""} onChange={(e) => setEditing({ ...editing, label: e.target.value })} className="mt-1" /></div>
          {renderFields()}
          <div className="flex gap-3 pt-2">
            <Button className="flex-1" onClick={handleSave} disabled={upsertMutation.isPending}>
              <Save className="w-4 h-4 mr-2" /> Save
            </Button>
            <Button variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════════════════════
// SHARED COMPONENTS
// ═══════════════════════════════════════════════════════════════
function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  );
}

function StatCard({ icon, label, value, color, isText }: { icon: React.ReactNode; label: string; value: number | string; color: string; isText?: boolean }) {
  const colorMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary border-primary/20",
    emerald: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    amber: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    blue: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    violet: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  };
  const iconColorMap: Record<string, string> = { primary: "text-primary", emerald: "text-emerald-400", amber: "text-amber-400", blue: "text-blue-400", violet: "text-violet-400" };

  return (
    <div className={`rounded-xl border p-4 ${colorMap[color]}`}>
      <div className={`mb-3 ${iconColorMap[color]}`}>{icon}</div>
      <p className="text-xs font-medium text-muted-foreground mb-1">{label}</p>
      <p className={`${isText ? "text-xl" : "text-2xl"} font-bold text-foreground`}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// QUOTE REQUESTS TAB
// ═══════════════════════════════════════════════════════════════
function QuoteRequestsTab() {
  const utils = trpc.useUtils();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [selectedQuote, setSelectedQuote] = useState<any>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [newStatus, setNewStatus] = useState("");

  const { data: quotes, isLoading } = trpc.directory.listQuoteRequests.useQuery(
    typeFilter !== "all" ? { companyType: typeFilter as any } : undefined
  );

  const updateStatusMutation = trpc.directory.updateQuoteRequestStatus.useMutation({
    onSuccess: () => {
      toast.success("Quote request updated");
      utils.directory.listQuoteRequests.invalidate();
      setSelectedQuote(null);
      setAdminNotes("");
      setNewStatus("");
    },
    onError: (err) => toast.error(err.message),
  });

  const filteredQuotes = (quotes || []).filter((q: any) => {
    if (statusFilter !== "all" && q.status !== statusFilter) return false;
    return true;
  });

  const statusCounts = (quotes || []).reduce(
    (acc: Record<string, number>, q: any) => {
      acc[q.status] = (acc[q.status] || 0) + 1;
      acc.total = (acc.total || 0) + 1;
      return acc;
    },
    { total: 0, pending: 0, sent: 0, responded: 0, closed: 0 }
  );

  const quoteStatusStyles: Record<string, string> = {
    pending: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    sent: "bg-blue-500/15 text-blue-400 border-blue-500/30",
    responded: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    closed: "bg-zinc-500/15 text-zinc-400 border-zinc-500/30",
  };

  const typeLabels: Record<string, string> = {
    shipping: "Shipping",
    insurance: "Insurance",
    parts: "Parts",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold">Quote Requests</h2>
          <p className="text-sm text-muted-foreground mt-1">Manage incoming quote requests from clients</p>
        </div>
      </div>

      {/* Status summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Total", count: statusCounts.total, color: "text-foreground" },
          { label: "Pending", count: statusCounts.pending, color: "text-amber-400" },
          { label: "Sent", count: statusCounts.sent, color: "text-blue-400" },
          { label: "Responded", count: statusCounts.responded, color: "text-emerald-400" },
          { label: "Closed", count: statusCounts.closed, color: "text-zinc-400" },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-border/50 bg-card p-3 text-center">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className={`text-xl font-bold ${s.color}`}>{s.count || 0}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="sent">Sent</SelectItem>
              <SelectItem value="responded">Responded</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[140px] h-9">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="shipping">Shipping</SelectItem>
            <SelectItem value="insurance">Insurance</SelectItem>
            <SelectItem value="parts">Parts</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Quote requests table */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : filteredQuotes.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>No quote requests found</p>
        </div>
      ) : (
        <div className="rounded-xl border border-border/50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50 bg-muted/30">
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Date</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Client</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Phone</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Type</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Company</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Vehicle</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredQuotes.map((q: any) => (
                  <tr key={q.id} className="border-b border-border/30 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(q.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{q.clientName || "—"}</div>
                      <div className="text-xs text-muted-foreground">{q.clientEmail || "—"}</div>
                    </td>
                    <td className="px-4 py-3 text-xs">{q.clientPhone || "—"}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
                        {typeLabels[q.companyType] || q.companyType}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium">{q.companyName}</td>
                    <td className="px-4 py-3 text-xs max-w-[200px] truncate">{q.vehicleInfo || "—"}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${quoteStatusStyles[q.status] || quoteStatusStyles.pending}`}>
                        {q.status.charAt(0).toUpperCase() + q.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() => {
                          setSelectedQuote(q);
                          setNewStatus(q.status);
                          setAdminNotes(q.adminNotes || "");
                        }}
                      >
                        <Edit2 className="w-3 h-3 mr-1" /> Manage
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Manage Quote Dialog */}
      <Dialog open={!!selectedQuote} onOpenChange={(open) => !open && setSelectedQuote(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Manage Quote Request</DialogTitle>
            <DialogDescription>Update status and add admin notes</DialogDescription>
          </DialogHeader>
          {selectedQuote && (
            <div className="space-y-4">
              {/* Quote details */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">Client</p>
                  <p className="font-medium">{selectedQuote.clientName || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Phone</p>
                  <p className="font-medium">{selectedQuote.clientPhone || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Email</p>
                  <p className="font-medium">{selectedQuote.clientEmail || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Company</p>
                  <p className="font-medium">{selectedQuote.companyName}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs">Vehicle Info</p>
                  <p className="font-medium">{selectedQuote.vehicleInfo || "—"}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs">Client Message</p>
                  <p className="font-medium">{selectedQuote.message || "—"}</p>
                </div>
              </div>

              {/* Update status */}
              <div>
                <label className="text-sm font-medium mb-1.5 block">Status</label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="responded">Responded</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Admin notes */}
              <div>
                <label className="text-sm font-medium mb-1.5 block">Admin Notes</label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add notes about this quote request..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSelectedQuote(null)}>Cancel</Button>
                <Button
                  onClick={() => {
                    updateStatusMutation.mutate({
                      id: selectedQuote.id,
                      status: newStatus as any,
                      adminNotes: adminNotes || undefined,
                    });
                  }}
                  disabled={updateStatusMutation.isPending}
                >
                  {updateStatusMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-1" />
                  ) : (
                    <Save className="w-4 h-4 mr-1" />
                  )}
                  Save Changes
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    approved: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    pending: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    rejected: "bg-red-500/15 text-red-400 border-red-500/30",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status] || styles.pending}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}


// ═══════════════════════════════════════════════════════════════
// SHIPPING RATES TAB
// ═══════════════════════════════════════════════════════════════
function ShippingRatesTab() {
  const utils = trpc.useUtils();
  const [searchQuery, setSearchQuery] = useState("");
  const [auctionFilter, setAuctionFilter] = useState<string>("all");
  const [stateFilter, setStateFilter] = useState<string>("all");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newRate, setNewRate] = useState({ auction: "Copart" as "Copart" | "IAAI", state: "", city: "", loadingPort: "", price: "" });
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 25;

  const { data: dbRates, isLoading } = trpc.siteConfig.getShippingRates.useQuery();

  const bulkImportMutation = trpc.siteConfig.bulkImportShippingRates.useMutation({
    onSuccess: (data) => {
      toast.success(`Imported ${data.count} shipping rates from defaults`);
      utils.siteConfig.getShippingRates.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const addMutation = trpc.siteConfig.addShippingRate.useMutation({
    onSuccess: () => {
      toast.success("Shipping rate added");
      utils.siteConfig.getShippingRates.invalidate();
      setShowAddDialog(false);
      setNewRate({ auction: "Copart", state: "", city: "", loadingPort: "", price: "" });
    },
    onError: (err) => toast.error(err.message),
  });

  const updateMutation = trpc.siteConfig.updateShippingRate.useMutation({
    onSuccess: () => {
      toast.success("Rate updated");
      utils.siteConfig.getShippingRates.invalidate();
      setEditingId(null);
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.siteConfig.deleteShippingRate.useMutation({
    onSuccess: () => {
      toast.success("Rate deleted");
      utils.siteConfig.getShippingRates.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSeedFromDefaults = () => {
    if (!confirm(`This will import ${SHIPPING_RATES.length} shipping rates from the default data. Continue?`)) return;
    const rates = SHIPPING_RATES.map((r) => ({
      auction: r.auction,
      state: r.state,
      city: r.city,
      loadingPort: r.loadingPort,
      price: r.price.toFixed(2),
    }));
    bulkImportMutation.mutate(rates);
  };

  const rates = dbRates ?? [];

  // Get unique states for filter
  const uniqueStates = Array.from(new Set(rates.map((r) => r.state))).sort();

  // Filter rates
  const filtered = rates.filter((r) => {
    const matchesSearch =
      !searchQuery ||
      r.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.loadingPort.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAuction = auctionFilter === "all" || r.auction === auctionFilter;
    const matchesState = stateFilter === "all" || r.state === stateFilter;
    return matchesSearch && matchesAuction && matchesState;
  });

  // Pagination
  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginatedRates = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  // Reset page when filters change
  const handleFilterChange = () => setCurrentPage(1);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-heading font-bold text-foreground">Shipping Rates</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {rates.length} rates total &middot; Manage shipping prices per auction/city/state
          </p>
        </div>
        <div className="flex gap-2">
          {rates.length === 0 && (
            <Button
              onClick={handleSeedFromDefaults}
              disabled={bulkImportMutation.isPending}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {bulkImportMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Upload className="w-4 h-4 mr-2" />
              )}
              Seed from Defaults ({SHIPPING_RATES.length})
            </Button>
          )}
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="w-4 h-4 mr-2" /> Add Rate
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle className="text-foreground">Add Shipping Rate</DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  Add a new shipping rate for a specific auction location.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Auction</label>
                    <Select value={newRate.auction} onValueChange={(v) => setNewRate({ ...newRate, auction: v as "Copart" | "IAAI" })}>
                      <SelectTrigger className="bg-secondary border-border"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Copart">Copart</SelectItem>
                        <SelectItem value="IAAI">IAAI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">State</label>
                    <Input
                      placeholder="e.g., FL"
                      value={newRate.state}
                      onChange={(e) => setNewRate({ ...newRate, state: e.target.value.toUpperCase() })}
                      className="bg-secondary border-border"
                      maxLength={10}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase">City</label>
                  <Input
                    placeholder="e.g., Miami South"
                    value={newRate.city}
                    onChange={(e) => setNewRate({ ...newRate, city: e.target.value })}
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Loading Port</label>
                    <Input
                      placeholder="e.g., GA"
                      value={newRate.loadingPort}
                      onChange={(e) => setNewRate({ ...newRate, loadingPort: e.target.value.toUpperCase() })}
                      className="bg-secondary border-border"
                      maxLength={10}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Price (USD)</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="1500.00"
                      value={newRate.price}
                      onChange={(e) => setNewRate({ ...newRate, price: e.target.value })}
                      className="bg-secondary border-border"
                    />
                  </div>
                </div>
                <Button
                  onClick={() => {
                    if (!newRate.state || !newRate.city || !newRate.loadingPort || !newRate.price) {
                      toast.error("Please fill in all fields");
                      return;
                    }
                    addMutation.mutate(newRate);
                  }}
                  disabled={addMutation.isPending}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {addMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                  Add Rate
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
          <Input
            placeholder="Search by city, state, or port..."
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); handleFilterChange(); }}
            className="bg-secondary border-border pl-10"
          />
        </div>
        <Select value={auctionFilter} onValueChange={(v) => { setAuctionFilter(v); handleFilterChange(); }}>
          <SelectTrigger className="w-[140px] bg-secondary border-border"><SelectValue placeholder="Auction" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Auctions</SelectItem>
            <SelectItem value="Copart">Copart</SelectItem>
            <SelectItem value="IAAI">IAAI</SelectItem>
          </SelectContent>
        </Select>
        <Select value={stateFilter} onValueChange={(v) => { setStateFilter(v); handleFilterChange(); }}>
          <SelectTrigger className="w-[140px] bg-secondary border-border"><SelectValue placeholder="State" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All States</SelectItem>
            {uniqueStates.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Results count */}
      <p className="text-sm text-muted-foreground">
        Showing {paginatedRates.length} of {filtered.length} rates
        {(searchQuery || auctionFilter !== "all" || stateFilter !== "all") && " (filtered)"}
      </p>

      {/* Table */}
      <div className="rounded-xl border border-border/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-secondary/50 border-b border-border/50">
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Auction</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">State</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">City</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Port</th>
                <th className="text-right px-4 py-3 font-semibold text-muted-foreground">Price (USD)</th>
                <th className="text-right px-4 py-3 font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedRates.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-muted-foreground">
                    {rates.length === 0 ? (
                      <div className="space-y-2">
                        <Ship className="w-10 h-10 mx-auto text-muted-foreground/30" />
                        <p>No shipping rates yet.</p>
                        <p className="text-xs">Click "Seed from Defaults" to import {SHIPPING_RATES.length} rates.</p>
                      </div>
                    ) : (
                      "No rates match your filters"
                    )}
                  </td>
                </tr>
              ) : (
                paginatedRates.map((rate) => (
                  <tr key={rate.id} className="border-b border-border/30 hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        rate.auction === "Copart"
                          ? "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                          : "bg-orange-500/10 text-orange-400 border border-orange-500/20"
                      }`}>
                        {rate.auction}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-foreground">{rate.state}</td>
                    <td className="px-4 py-3 text-foreground">{rate.city}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{rate.loadingPort}</td>
                    <td className="px-4 py-3 text-right">
                      {editingId === rate.id ? (
                        <div className="flex items-center justify-end gap-2">
                          <Input
                            type="number"
                            step="0.01"
                            value={editPrice}
                            onChange={(e) => setEditPrice(e.target.value)}
                            className="w-28 h-8 text-right bg-secondary border-border text-sm"
                          />
                          <button
                            onClick={() => updateMutation.mutate({ id: rate.id, price: editPrice })}
                            className="p-1 text-primary hover:text-primary/80"
                            title="Save"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="p-1 text-muted-foreground hover:text-foreground"
                            title="Cancel"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <span className="font-mono font-medium text-primary">
                          ${parseFloat(rate.price).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {editingId !== rate.id && (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => { setEditingId(rate.id); setEditPrice(rate.price); }}
                            className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                            title="Edit price"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete rate for ${rate.city}, ${rate.state}?`)) {
                                deleteMutation.mutate({ id: rate.id });
                              }
                            }}
                            className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {currentPage} of {totalPages}
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            {/* Show page numbers */}
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let page: number;
              if (totalPages <= 5) {
                page = i + 1;
              } else if (currentPage <= 3) {
                page = i + 1;
              } else if (currentPage >= totalPages - 2) {
                page = totalPages - 4 + i;
              } else {
                page = currentPage - 2 + i;
              }
              return (
                <Button
                  key={page}
                  variant={page === currentPage ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className="w-8"
                >
                  {page}
                </Button>
              );
            })}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
