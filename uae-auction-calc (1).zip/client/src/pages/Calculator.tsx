/**
 * US-to-UAE Import Calculator
 * Step-by-step: VIN → Auction fees → Shipping → Customs/VAT → Parts → Registration → Profit
 * Now with auto market price estimation and marketplace search links
 */
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  formatAED,
  formatUSD,
  getCopartTotalFees,
  getIAAITotalFees,
  calculateUAEImportTax,
  EMIRATES,
  SPARE_PARTS,
  USD_TO_AED,
} from "@/lib/auctionData";
import { useAdminPartsPrices } from "@/hooks/useAdminPartsPrices";
import { findShippingRate, getStateList, getCitiesForState } from "@shared/shippingData";
import {
  getUAEMarketPrice,
  getMarketplaceLinks,
  type PriceRange,
  type MarketplaceLink,
} from "@/lib/marketPrices";
import { motion, AnimatePresence } from "framer-motion";
import {
  Car,
  DollarSign,
  Ship,
  Shield,
  Wrench,
  MapPin,
  TrendingUp,
  Search,
  Loader2,
  CheckCircle2,
  XCircle,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Info,
  ExternalLink,
  Sparkles,
  ArrowRight,
  AlertTriangle,
  Zap,
} from "lucide-react";
import { useState, useMemo, useCallback, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Camera, ImageIcon, Brain, ShieldAlert, CircleDollarSign, Lightbulb, Save, FileText, BookmarkPlus, Clock, X, ZoomIn, MessageCircle, Target, Crosshair } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";

function InfoTip({ text }: { text: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Info className="w-3.5 h-3.5 text-muted-foreground ml-1 inline cursor-help" />
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs text-xs">
        {text}
      </TooltipContent>
    </Tooltip>
  );
}

function SectionIcon({ icon: Icon, label }: { icon: React.ElementType; label: string }) {
  return (
    <div className="flex items-center gap-2 mb-4">
      <div className="p-1.5 rounded-md bg-primary/10">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <h3 className="font-heading text-sm font-semibold">{label}</h3>
    </div>
  );
}

export default function CalculatorPage() {
  const { t, isRTL, lang } = useLanguage();

  // ─── Admin-editable spare parts prices (falls back to hardcoded) ───
  const { parts: adminParts } = useAdminPartsPrices();

  // ─── VIN State ───
  const [vin, setVin] = useState("");
  const [listingUrl, setListingUrl] = useState("");
  const [inputMode, setInputMode] = useState<"vin" | "url">("vin");
  const [vinLoading, setVinLoading] = useState(false);
  const [vinResult, setVinResult] = useState<any | null>(null);
  const [vinError, setVinError] = useState("");
  const [auctionLots, setAuctionLots] = useState<any[]>([]);
  const [selectedLot, setSelectedLot] = useState<any | null>(null);
  const [showLotPhotos, setShowLotPhotos] = useState(false);

  // ─── URL Vehicle Info State ───
  const [urlVehicleInfo, setUrlVehicleInfo] = useState<{ year?: string; make?: string; model?: string; trim?: string; source?: "copart" | "iaai"; lotId?: string } | null>(null);

  // ─── Parse vehicle info from Copart/IAAI URL slug ───
  const parseVehicleInfoFromUrl = useCallback((url: string): { year?: string; make?: string; model?: string; trim?: string; source?: "copart" | "iaai"; lotId?: string } | null => {
    try {
      // Copart: /lot/76407625/clean-title-2022-nissan-sentra-sr-nb-moncton
      const copartMatch = url.match(/copart\.com\/lot\/(\d+)(?:\/([^?#]+))?/i);
      if (copartMatch) {
        const lotId = copartMatch[1];
        const slug = copartMatch[2] || "";
        // Extract year-make-model from slug: "clean-title-2022-nissan-sentra-sr-nb-moncton"
        const yearMatch = slug.match(/(20\d{2})/);
        const year = yearMatch ? yearMatch[1] : undefined;
        // Get parts after the year
        if (year) {
          const afterYear = slug.substring(slug.indexOf(year) + 4).replace(/^-/, "");
          const parts = afterYear.split("-").filter(Boolean);
          // First part is usually make, second is model, rest could be trim or location
          const make = parts[0] ? parts[0].charAt(0).toUpperCase() + parts[0].slice(1) : undefined;
          const model = parts[1] ? parts[1].charAt(0).toUpperCase() + parts[1].slice(1) : undefined;
          const trim = parts[2] ? parts[2].toUpperCase() : undefined;
          return { year, make, model, trim, source: "copart", lotId };
        }
        return { source: "copart", lotId };
      }

      // IAAI: /VehicleDetail/44974742~US
      const iaaiMatch = url.match(/iaai\.com\/VehicleDetail\/(\d+)/i);
      if (iaaiMatch) {
        return { source: "iaai", lotId: iaaiMatch[1] };
      }

      return null;
    } catch {
      return null;
    }
  }, []);

  // ─── Extract VIN from Copart/IAAI listing URL ───
  const extractVinFromUrl = useCallback((url: string): string | null => {
    try {
      // Copart URLs with VIN in query: copart.com/lotSearchResults?query=VIN
      const copartVinMatch = url.match(/copart\.com.*[?&]query=([A-HJ-NPR-Z0-9]{17})/i);
      if (copartVinMatch) return copartVinMatch[1].toUpperCase();

      // IAAI URLs with full VIN visible
      const iaaiVinMatch = url.match(/iaai\.com.*\/([A-HJ-NPR-Z0-9]{17})/i);
      if (iaaiVinMatch) return iaaiVinMatch[1].toUpperCase();

      // Generic: look for 17-char VIN pattern anywhere in the URL
      const genericVin = url.match(/[A-HJ-NPR-Z0-9]{17}/i);
      if (genericVin) return genericVin[0].toUpperCase();

      return null;
    } catch {
      return null;
    }
  }, []);

  // ─── Handle smart paste (auto-detect VIN or URL) ───
  const handleSmartPaste = useCallback((text: string) => {
    const trimmed = text.trim();
    // Check if it's a URL
    if (trimmed.startsWith("http") || trimmed.includes("copart.com") || trimmed.includes("iaai.com")) {
      setInputMode("url");
      setListingUrl(trimmed);
      const extractedVin = extractVinFromUrl(trimmed);
      if (extractedVin) {
        setVin(extractedVin);
      }
      // Parse vehicle info from URL slug
      const vehicleInfo = parseVehicleInfoFromUrl(trimmed);
      setUrlVehicleInfo(vehicleInfo);
      // Auto-set auction house from URL
      if (vehicleInfo?.source) {
        setAuctionHouse(vehicleInfo.source === "iaai" ? "iaai" : "copart");
      }
    } else {
      // Treat as VIN
      setInputMode("vin");
      const cleaned = trimmed.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, "");
      setVin(cleaned.slice(0, 17));
    }
  }, [extractVinFromUrl, parseVehicleInfoFromUrl]);

  // ─── AI Damage Analysis State ───
  const [damageAnalysis, setDamageAnalysis] = useState<any | null>(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState("");
  const [showAnalysis, setShowAnalysis] = useState(true);
  const [selectedRepairAreas, setSelectedRepairAreas] = useState<Set<number>>(new Set());
  const [lightboxPhoto, setLightboxPhoto] = useState<{ url: string; description: string; damages: string[]; damageLocations?: { label: string; x: number; y: number; radius: number }[] } | null>(null);

  // ─── Auction State ───
  const [auctionHouse, setAuctionHouse] = useState<"copart" | "iaai">("copart");
  const [bidAmount, setBidAmount] = useState<number>(0);

  // ─── Shipping State ───
  const [shippingCost, setShippingCost] = useState<number>(0);
  const [shippingAutoFilled, setShippingAutoFilled] = useState(false);
  const [shippingMatch, setShippingMatch] = useState<{ city: string; state: string; port: string } | null>(null);
  const [manualShipState, setManualShipState] = useState("");
  const [manualShipCity, setManualShipCity] = useState("");
  const [manualShipAuction, setManualShipAuction] = useState<"copart" | "iaai">("copart");
  const [showManualShipping, setShowManualShipping] = useState(false);

  // ─── Shipping Companies (for WhatsApp quote) ───
  const { data: shippingCompanies } = trpc.directory.listActiveShippingCompanies.useQuery();

  const handleWhatsAppQuote = useCallback(() => {
    if (!shippingCompanies || shippingCompanies.length === 0) {
      toast.error("No shipping company available. Contact admin.");
      return;
    }
    const company = shippingCompanies[0];
    if (!company.phone) {
      toast.error("Shipping company phone number not configured.");
      return;
    }
    // Build pre-filled WhatsApp message with vehicle details
    const lines: string[] = [
      "\u{1F697} *Shipping Quote Request*",
      "",
    ];
    if (vin) lines.push(`VIN: ${vin}`);
    if (vinResult) {
      lines.push(`Vehicle: ${vinResult.year || ""} ${vinResult.make || ""} ${vinResult.model || ""}`.trim());
      if (vinResult.trim) lines.push(`Trim: ${vinResult.trim}`);
    }
    if (auctionHouse) lines.push(`Auction: ${auctionHouse.toUpperCase()}`);
    if (selectedLot?.location) lines.push(`Location: ${selectedLot.location}`);
    if (shippingMatch) lines.push(`Origin: ${shippingMatch.city}, ${shippingMatch.state} (Port: ${shippingMatch.port})`);
    if (shippingCost > 0) lines.push(`Estimated Rate: $${shippingCost}`);
    lines.push("", "Destination: UAE");
    lines.push("", "Please provide a shipping quote. Thank you!");

    // Normalize phone: remove spaces, dashes; ensure starts with country code
    let phone = company.phone.replace(/[\s\-\(\)]/g, "");
    if (phone.startsWith("0")) phone = "971" + phone.slice(1);
    if (!phone.startsWith("+")) phone = "+" + phone;
    phone = phone.replace("+", ""); // WhatsApp API uses number without +

    const encodedMsg = encodeURIComponent(lines.join("\n"));
    const waUrl = `https://wa.me/${phone}?text=${encodedMsg}`;
    window.open(waUrl, "_blank");
  }, [shippingCompanies, vin, vinResult, auctionHouse, selectedLot, shippingMatch, shippingCost]);

  const stateList = useMemo(() => getStateList(), []);
  const citiesForState = useMemo(() => {
    if (!manualShipState) return [];
    return getCitiesForState(manualShipState, manualShipAuction);
  }, [manualShipState, manualShipAuction]);

  // ─── Mileage State ───
  const [mileage, setMileage] = useState<number>(0);

  // ─── UAE Market Price ───
  const [uaeMarketPrice, setUaeMarketPrice] = useState<number>(0);
  const [marketPriceEstimate, setMarketPriceEstimate] = useState<PriceRange | null>(null);
  const [marketplaceLinks, setMarketplaceLinks] = useState<MarketplaceLink[]>([]);
  const [showMarketPanel, setShowMarketPanel] = useState(false);

  // ─── Registration (optional) ───
  const [includeRegistration, setIncludeRegistration] = useState(false);
  const [selectedEmirate, setSelectedEmirate] = useState("dubai");

  // ─── Damage Types (multi-select) ───
  const [selectedDamageTypes, setSelectedDamageTypes] = useState<string[]>([]);

  // ─── Spare Parts ───
  const [selectedParts, setSelectedParts] = useState<string[]>([]);
  const [showParts, setShowParts] = useState(false);
  
  // ─── Damage Types ───
  const DAMAGE_TYPES = [
    { id: "front-end", name: "Front End", icon: "🚗", autoSelectParts: ["front-bumper", "hood", "headlights", "radiator", "fender", "windshield", "ac-compressor"] },
    { id: "rear-end", name: "Rear End", icon: "🔙", autoSelectParts: ["rear-bumper", "trunk-lid", "taillights", "rear-window"] },
    { id: "side", name: "Side", icon: "↩️", autoSelectParts: ["door", "fender", "side-mirror", "side-window"] },
    { id: "rollover", name: "Rollover", icon: "🔄", autoSelectParts: ["windshield", "roof", "door", "side-window"] },
    { id: "water", name: "Water/Flood", icon: "🌊", autoSelectParts: ["engine", "transmission", "battery", "alternator", "starter"] },
    { id: "fire", name: "Fire/Burn", icon: "🔥", autoSelectParts: ["engine", "transmission", "interior-panels", "dashboard", "seats"] },
    { id: "hail", name: "Hail", icon: "❄️", autoSelectParts: ["hood", "roof", "fender", "door"] },
    { id: "vandalism", name: "Vandalism/Theft", icon: "🔒", autoSelectParts: ["windows", "mirrors", "lights"] },
    { id: "mechanical", name: "Mechanical", icon: "⚙️", autoSelectParts: ["engine", "transmission", "suspension"] },
    { id: "minor", name: "Minor Dents", icon: "📌", autoSelectParts: ["bumper", "fender"] },
    { id: "biohazard", name: "Biohazard", icon: "☣️", autoSelectParts: ["interior-panels", "seats", "dashboard"] },
    { id: "all-over", name: "All Over", icon: "💥", autoSelectParts: ["windshield", "roof", "door", "fender", "bumper"] },
  ];

  // ─── VIN Quota State ───
  const [vinQuota, setVinQuota] = useState<{ used: number; limit: number; remaining: number } | null>(null);
  const [quotaLoading, setQuotaLoading] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [upgradeBillingPeriod, setUpgradeBillingPeriod] = useState<"monthly" | "annual">("monthly");
  const [subscribingPlanId, setSubscribingPlanId] = useState<number | null>(null);

  // Fetch active pricing plans for upgrade prompt
  const { data: activePlans } = trpc.admin.getActivePlans.useQuery(undefined, {
    enabled: showUpgradeDialog,
  });

  // Stripe checkout mutation
  const createCheckout = trpc.stripe.createCheckoutSession.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        window.open(data.checkoutUrl, "_blank");
        toast.info("Redirecting to checkout...", { description: "Complete your payment in the new tab." });
      }
      setSubscribingPlanId(null);
    },
    onError: (err) => {
      toast.error("Payment error", { description: err.message });
      setSubscribingPlanId(null);
    },
  });

  const handleSubscribe = (planId: number) => {
    const clientSession = localStorage.getItem("clientSession");
    if (!clientSession) return;
    const session = JSON.parse(clientSession);
    setSubscribingPlanId(planId);
    createCheckout.mutate({
      planId,
      billingPeriod: upgradeBillingPeriod,
      accountId: session.id,
      origin: window.location.origin,
    });
  };

  // Load VIN quota on mount
  useEffect(() => {
    async function loadQuota() {
      try {
        setQuotaLoading(true);
        const clientSession = localStorage.getItem("clientSession");
        if (!clientSession) return;
        const session = JSON.parse(clientSession);
        const batchInput = encodeURIComponent(JSON.stringify({ "0": { json: { accountId: session.id } } }));
        const res = await fetch(`/api/trpc/siteConfig.getEnhancedVinQuota?batch=1&input=${batchInput}`, { credentials: "include" });
        const data = await res.json();
        const quota = data?.[0]?.result?.data?.json;
        if (quota) setVinQuota(quota);
      } catch (e) {
        console.error("Failed to load VIN quota", e);
      } finally {
        setQuotaLoading(false);
      }
    }
    loadQuota();
  }, []);

  // ─── VIN Decode Handler ───
  const handleVinDecode = useCallback(async () => {
    if (vin.length !== 17) {
      setVinError("VIN must be exactly 17 characters");
      return;
    }

    // Check VIN quota before proceeding
    if (vinQuota && vinQuota.limit !== -1 && vinQuota.remaining <= 0) {
      setVinError("You've used all your VIN lookups. Upgrade your plan for more.");
      setShowUpgradeDialog(true);
      return;
    }

    setVinLoading(true);
    setVinError("");
    setVinResult(null);
    setAuctionLots([]);
    setSelectedLot(null);
    setShowLotPhotos(false);
    setMarketPriceEstimate(null);
    setMarketplaceLinks([]);
    setShowMarketPanel(false);

    try {
      // Try server-side search (auction-api.app + NHTSA)
      const batchInput = encodeURIComponent(JSON.stringify({ "0": { json: { vin } } }));
      const serverResult = await fetch(`/api/trpc/auction.searchVin?batch=1&input=${batchInput}`, {
        credentials: "include",
      });
      const serverData = await serverResult.json();
      const searchResult = serverData?.[0]?.result?.data?.json;

      if (searchResult?.vehicleInfo) {
        const vi = searchResult.vehicleInfo;
        const result: any = {
          year: vi.year?.toString() || "",
          make: vi.make || "",
          model: vi.model || "",
          trim: vi.trim || "",
          bodyClass: vi.bodyStyle || "",
          engineCylinders: vi.cylinders || "",
          engineDisplacement: vi.engine?.match(/([\d.]+)L/)?.[1] || "",
          driveType: vi.driveType || "",
          fuelType: vi.fuelType || "",
        };
        setVinResult(result);

        // If auction lots found, set them
        if (searchResult.lots?.length > 0) {
          setAuctionLots(searchResult.lots);
          const lot = searchResult.lots[0];
          setSelectedLot(lot);
          
          // Auto-fill from auction lot data
          if (lot.odometer) setMileage(lot.odometer);
          if (lot.source) setAuctionHouse(lot.source === "iaai" ? "iaai" : "copart");

          // Auto-fill shipping cost from location data
          if (lot.location && lot.source) {
            // Parse location: could be "City, ST" or "YARD NAME" or "City, State"
            const locParts = lot.location.split(",").map((s: string) => s.trim());
            let city = locParts[0] || "";
            let state = locParts[1] || "";
            // If state is full name, try to match; if 2-letter code, use directly
            if (state.length > 2) {
              // Try extracting 2-letter state code from the string
              const stateMatch = state.match(/\b([A-Z]{2})\b/);
              if (stateMatch) state = stateMatch[1];
            }
            const auctionName = lot.source === "iaai" ? "IAAI" : "Copart";
            const rate = findShippingRate(auctionName, state, city);
            if (rate) {
              setShippingCost(rate.price);
              setShippingAutoFilled(true);
              setShippingMatch({ city: rate.city, state: rate.state, port: rate.loadingPort });
            }
          }
          
          // Auto-select damage types from lot
          if (lot.primaryDamage) {
            const dmgMap: Record<string, string> = {
              "front end": "front-end", "rear end": "rear-end", "side": "side",
              "rollover": "rollover", "water": "water", "flood": "water",
              "fire": "fire", "burn": "fire", "hail": "hail",
              "vandalism": "vandalism", "theft": "vandalism", "mechanical": "mechanical",
              "minor": "minor", "all over": "all-over", "biohazard": "biohazard",
            };
            const damages: string[] = [];
            const primary = lot.primaryDamage.toLowerCase();
            for (const [key, val] of Object.entries(dmgMap)) {
              if (primary.includes(key)) { damages.push(val); break; }
            }
            if (lot.secondaryDamage) {
              const secondary = lot.secondaryDamage.toLowerCase();
              for (const [key, val] of Object.entries(dmgMap)) {
                if (secondary.includes(key) && !damages.includes(val)) { damages.push(val); break; }
              }
            }
            if (damages.length > 0) {
              setSelectedDamageTypes(damages);
              // Auto-select parts from damage types
              const allParts = new Set<string>();
              damages.forEach(dmgId => {
                const dt = DAMAGE_TYPES.find(d => d.id === dmgId);
                dt?.autoSelectParts.forEach(p => allParts.add(p));
              });
              setSelectedParts(Array.from(allParts));
              setShowParts(true);
            }
          }
        }

        // Auto-lookup market price — try database first, then static fallback
        if (result.make && result.model && result.year) {
          const year = parseInt(result.year);
          let estimate: PriceRange | null = null;

          // 1) Try vehicle models database (admin-managed prices)
          try {
            const dbInput = encodeURIComponent(JSON.stringify({ "0": { json: { make: result.make, model: result.model, year } } }));
            const dbRes = await fetch(`/api/trpc/vehicleModels.matchVinToModel?batch=1&input=${dbInput}`, { credentials: "include" });
            const dbData = await dbRes.json();
            const dbMatch = dbData?.[0]?.result?.data?.json;
            if (dbMatch?.match && dbMatch.match.uaeMarketPriceMid) {
              estimate = {
                low: dbMatch.match.uaeMarketPriceLow || Math.round(dbMatch.match.uaeMarketPriceMid * 0.85),
                mid: dbMatch.match.uaeMarketPriceMid,
                high: dbMatch.match.uaeMarketPriceHigh || Math.round(dbMatch.match.uaeMarketPriceMid * 1.15),
              };
            }
          } catch (dbErr) {
            console.warn("DB price lookup failed, using static fallback", dbErr);
          }

          // 2) Fallback to static PRICE_DB
          if (!estimate) {
            estimate = getUAEMarketPrice(result.make, result.model, year);
          }

          if (estimate) {
            setMarketPriceEstimate(estimate);
            setUaeMarketPrice(estimate.mid);
            setShowMarketPanel(true);
          }
          const links = getMarketplaceLinks(result.make, result.model, year);
          setMarketplaceLinks(links);
        }
      } else {
        // Fallback: direct NHTSA call from client
        const result: any = { year: "", make: "", model: "", trim: "", bodyClass: "", engineCylinders: "", engineDisplacement: "", driveType: "", fuelType: "" };
        const response = await fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/${vin}?format=json`);
        const data = await response.json();
        if (data.Results) {
          const get = (variable: string) => {
            const found = data.Results.find((r: any) => r.Variable === variable);
            return found?.Value && found.Value !== "Not Applicable" && found.Value.trim() !== "" ? found.Value.trim() : "";
          };
          result.make = get("Make");
          result.model = get("Model");
          result.year = get("Model Year");
          result.trim = get("Trim");
          result.bodyClass = get("Body Class");
          result.engineCylinders = get("Engine Number of Cylinders");
          result.engineDisplacement = get("Displacement (L)");
          result.driveType = get("Drive Type");
          result.fuelType = get("Fuel Type - Primary");
        }
        if (result.make) {
          setVinResult(result);
          if (result.make && result.model && result.year) {
            const year = parseInt(result.year);
            let estimate: PriceRange | null = null;

            // 1) Try vehicle models database (admin-managed prices)
            try {
              const dbInput = encodeURIComponent(JSON.stringify({ "0": { json: { make: result.make, model: result.model, year } } }));
              const dbRes = await fetch(`/api/trpc/vehicleModels.matchVinToModel?batch=1&input=${dbInput}`, { credentials: "include" });
              const dbData = await dbRes.json();
              const dbMatch = dbData?.[0]?.result?.data?.json;
              if (dbMatch?.match && dbMatch.match.uaeMarketPriceMid) {
                estimate = {
                  low: dbMatch.match.uaeMarketPriceLow || Math.round(dbMatch.match.uaeMarketPriceMid * 0.85),
                  mid: dbMatch.match.uaeMarketPriceMid,
                  high: dbMatch.match.uaeMarketPriceHigh || Math.round(dbMatch.match.uaeMarketPriceMid * 1.15),
                };
              }
            } catch (dbErr) {
              console.warn("DB price lookup failed, using static fallback", dbErr);
            }

            // 2) Fallback to static PRICE_DB
            if (!estimate) {
              estimate = getUAEMarketPrice(result.make, result.model, year);
            }

            if (estimate) {
              setMarketPriceEstimate(estimate);
              setUaeMarketPrice(estimate.mid);
              setShowMarketPanel(true);
            }
            const links = getMarketplaceLinks(result.make, result.model, year);
            setMarketplaceLinks(links);
          }
        } else {
          setVinError("Could not decode VIN. Please check and try again.");
        }
      }
    } catch (error) {
      console.error("VIN decode error:", error);
      setVinError("Network error. Please try again.");
    }
    
    // Track VIN usage after successful decode
    try {
      const clientSession = localStorage.getItem("clientSession");
      if (clientSession) {
        const session = JSON.parse(clientSession);
        const trackInput = encodeURIComponent(JSON.stringify({ "0": { json: { accountId: session.id, vin } } }));
        await fetch(`/api/trpc/admin.trackVinUsage?batch=1`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ "0": { json: { accountId: session.id, vin } } }),
        });
        // Refresh quota
        const quotaInput = encodeURIComponent(JSON.stringify({ "0": { json: { accountId: session.id } } }));
        const quotaRes = await fetch(`/api/trpc/siteConfig.getEnhancedVinQuota?batch=1&input=${quotaInput}`, { credentials: "include" });
        const quotaData = await quotaRes.json();
        const newQuota = quotaData?.[0]?.result?.data?.json;
        if (newQuota) setVinQuota(newQuota);
      }
    } catch (e) {
      console.error("Failed to track VIN usage", e);
    }

    setVinLoading(false);
  }, [vin, vinQuota]);

  // ─── Calculations ───
  const auctionFees = useMemo(() => {
    if (bidAmount <= 0) return null;
    if (auctionHouse === "copart") return getCopartTotalFees(bidAmount);
    return getIAAITotalFees(bidAmount);
  }, [bidAmount, auctionHouse]);

  const totalAuctionCostUSD = useMemo(() => {
    if (!auctionFees) return 0;
    return bidAmount + auctionFees.total;
  }, [bidAmount, auctionFees]);

  const totalAuctionCostAED = totalAuctionCostUSD * USD_TO_AED;
  const shippingCostAED = shippingCost * USD_TO_AED;

  const cifValueAED = totalAuctionCostAED + shippingCostAED;

  // Customs & VAT are calculated on car price + auction fees only (NOT including shipping)
  const importTax = useMemo(() => {
    return calculateUAEImportTax(totalAuctionCostAED);
  }, [totalAuctionCostAED]);

  const emirateReg = useMemo(() => {
    return EMIRATES.find((e) => e.id === selectedEmirate) || EMIRATES[0];
  }, [selectedEmirate]);

  const partsTotal = useMemo(() => {
    return selectedParts.reduce((sum, partId) => {
      const part = adminParts.find((p) => p.id === partId);
      return sum + (part?.priceAED || 0);
    }, 0);
  }, [selectedParts, adminParts]);

  const registrationTotal = includeRegistration ? emirateReg.total : 0;

  // ─── Selected Repair Cost from AI Damage Analysis ───
  const selectedRepairCostAED = useMemo(() => {
    if (!damageAnalysis?.damages?.length || selectedRepairAreas.size === 0) return 0;
    let total = 0;
    damageAnalysis.damages.forEach((dmg: any, i: number) => {
      if (selectedRepairAreas.has(i)) {
        const cost = dmg.estimatedRepairCostAED || dmg.estimatedRepairCostUSD;
        if (cost) {
          // Use the average of low and high
          total += Math.round((cost.low + cost.high) / 2);
        }
      }
    });
    return total;
  }, [damageAnalysis, selectedRepairAreas]);

  const grandTotalAED = cifValueAED + importTax.total + registrationTotal + partsTotal + selectedRepairCostAED;
  const profitAED = uaeMarketPrice - grandTotalAED;
  const profitPercent = grandTotalAED > 0 ? (profitAED / grandTotalAED) * 100 : 0;

  // ─── Smart Bid Advisor State ───
  const [selectedProfitTarget, setSelectedProfitTarget] = useState<number>(5000);
  const [customProfitTarget, setCustomProfitTarget] = useState<string>("");
  const [showBidAdvisor, setShowBidAdvisor] = useState(false);

  const PROFIT_TARGETS = [5000, 7000, 10000, 15000];

  // ─── Smart Bid Advisor: Reverse-calculate max bid for a given profit target ───
  const calculateMaxBid = useCallback((targetProfitAED: number): { maxBidUSD: number; maxBidAED: number; totalCostAED: number; feasible: boolean } => {
    if (uaeMarketPrice <= 0) return { maxBidUSD: 0, maxBidAED: 0, totalCostAED: 0, feasible: false };

    // Non-bid costs in AED: shipping + customs/VAT on bid portion + parts + repair + registration
    // The tricky part: customs/VAT are calculated on (bid + auction fees) * USD_TO_AED
    // And auction fees are a non-linear function of bid amount
    // So we use binary search to find the max bid

    const fixedCostsAED = shippingCostAED + partsTotal + selectedRepairCostAED + registrationTotal;
    const availableForBidAED = uaeMarketPrice - fixedCostsAED - targetProfitAED;

    if (availableForBidAED <= 0) return { maxBidUSD: 0, maxBidAED: 0, totalCostAED: 0, feasible: false };

    // Binary search for max bid in USD
    let lo = 0;
    let hi = availableForBidAED / USD_TO_AED; // Upper bound: all available budget as bid
    let bestBid = 0;

    for (let i = 0; i < 50; i++) {
      const mid = (lo + hi) / 2;
      const fees = auctionHouse === "copart" ? getCopartTotalFees(mid) : getIAAITotalFees(mid);
      const bidPlusFees = mid + fees.total;
      const bidPlusFeesAED = bidPlusFees * USD_TO_AED;
      const tax = calculateUAEImportTax(bidPlusFeesAED);
      const totalCost = bidPlusFeesAED + shippingCostAED + tax.total + partsTotal + selectedRepairCostAED + registrationTotal;
      const profit = uaeMarketPrice - totalCost;

      if (profit >= targetProfitAED) {
        bestBid = mid;
        lo = mid;
      } else {
        hi = mid;
      }
    }

    const finalFees = auctionHouse === "copart" ? getCopartTotalFees(bestBid) : getIAAITotalFees(bestBid);
    const finalBidPlusFeesAED = (bestBid + finalFees.total) * USD_TO_AED;
    const finalTax = calculateUAEImportTax(finalBidPlusFeesAED);
    const finalTotalCost = finalBidPlusFeesAED + shippingCostAED + finalTax.total + partsTotal + selectedRepairCostAED + registrationTotal;

    return {
      maxBidUSD: Math.floor(bestBid),
      maxBidAED: Math.floor(bestBid * USD_TO_AED),
      totalCostAED: Math.round(finalTotalCost),
      feasible: bestBid > 0,
    };
  }, [uaeMarketPrice, shippingCostAED, partsTotal, selectedRepairCostAED, registrationTotal, auctionHouse]);

  // Calculate all profit target results for comparison
  const bidAdvisorResults = useMemo(() => {
    const activeProfitTarget = customProfitTarget ? Number(customProfitTarget) : selectedProfitTarget;
    return PROFIT_TARGETS.map(target => ({
      target,
      ...calculateMaxBid(target),
      isSelected: target === activeProfitTarget,
    }));
  }, [calculateMaxBid, selectedProfitTarget, customProfitTarget]);

  const activeBidResult = useMemo(() => {
    const activeProfitTarget = customProfitTarget ? Number(customProfitTarget) : selectedProfitTarget;
    return calculateMaxBid(activeProfitTarget);
  }, [calculateMaxBid, selectedProfitTarget, customProfitTarget]);

  const handleReset = () => {
    setVin("");
    setListingUrl("");
    setInputMode("vin");
    setVinResult(null);
    setVinError("");
    setBidAmount(0);
    setShippingCost(0);
    setShippingAutoFilled(false);
    setShippingMatch(null);
    setManualShipState("");
    setManualShipCity("");
    setManualShipAuction("copart");
    setShowManualShipping(false);
    setUaeMarketPrice(0);
    setIncludeRegistration(false);
    setSelectedEmirate("dubai");
    setSelectedParts([]);
    setAuctionHouse("copart");
    setMarketPriceEstimate(null);
    setMarketplaceLinks([]);
    setShowMarketPanel(false);
    setSelectedDamageTypes([]);
    setAuctionLots([]);
    setSelectedLot(null);
    setShowLotPhotos(false);
    setMileage(0);
    setDamageAnalysis(null);
    setAnalysisLoading(false);
    setAnalysisError("");
    setShowAnalysis(true);
    setSelectedRepairAreas(new Set());
    setShowBidAdvisor(false);
    setSelectedProfitTarget(5000);
    setCustomProfitTarget("");
  };

  // ─── Save Deal State ───
  const [savingDeal, setSavingDeal] = useState(false);
  const { user, isAuthenticated } = useAuth();

  // ─── Save to Deal Queue Handler ───
  const handleSaveDeal = useCallback(async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    if (!vinResult || bidAmount <= 0) {
      toast.error("Please complete the calculation first");
      return;
    }
    setSavingDeal(true);
    try {
      const dealData = {
        vin,
        vehicleInfo: JSON.stringify(vinResult),
        auctionHouse,
        bidAmountUSD: Math.round(bidAmount),
        shippingCostUSD: Math.round(shippingCost),
        mileage: Math.round(mileage),
        uaeMarketPriceAED: Math.round(uaeMarketPrice),
        emirate: selectedEmirate,
        includeRegistration,
        damageTypes: JSON.stringify(selectedDamageTypes),
        spareParts: JSON.stringify(selectedParts),
        costBreakdown: JSON.stringify({
          auctionFeesUSD: auctionFees?.total || 0,
          shippingUSD: shippingCost,
          totalLandedUSD: totalAuctionCostUSD + shippingCost,
          totalLandedAED: cifValueAED,
          customsDutyAED: importTax.customsDuty,
          vatAED: importTax.vat,
          partsAED: partsTotal,
          registrationAED: registrationTotal,
          totalCostAED: Math.round(grandTotalAED),
          estimatedProfitAED: Math.round(profitAED),
          profitMarginPercent: Math.round(profitPercent),
        }),
        totalCostAED: Math.round(grandTotalAED),
        estimatedProfitAED: Math.round(profitAED),
        profitMarginPercent: Math.round(profitPercent),
        auctionLotData: selectedLot ? JSON.stringify(selectedLot) : undefined,
        damageAnalysis: damageAnalysis ? JSON.stringify(damageAnalysis) : undefined,
        photoUrl: selectedLot?.images?.[0] || undefined,
        notes: "",
      };

      const res = await fetch(`/api/trpc/dealQueue.save?batch=1`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ "0": { json: dealData } }),
      });
      const data = await res.json();
      if (data?.[0]?.result?.data?.json?.success) {
        toast.success("Deal saved to queue!", {
          action: { label: "View Queue", onClick: () => (window.location.href = "/deal-queue") },
        });
      } else {
        throw new Error("Failed to save");
      }
    } catch (err: any) {
      toast.error(err?.message?.includes("login") || err?.message?.includes("10001") ? "Please sign in to save deals" : "Failed to save deal");
    } finally {
      setSavingDeal(false);
    }
  }, [vin, vinResult, auctionHouse, bidAmount, shippingCost, mileage, uaeMarketPrice, selectedEmirate, includeRegistration, selectedDamageTypes, selectedParts, auctionFees, totalAuctionCostUSD, cifValueAED, importTax, partsTotal, registrationTotal, grandTotalAED, profitAED, profitPercent, selectedLot, damageAnalysis, isAuthenticated]);

  // ─── PDF Export Handler ───
  const handlePdfExport = useCallback(async () => {
    if (!vinResult || bidAmount <= 0) {
      toast.error("Please complete the calculation first");
      return;
    }
    try {
      const reportData = {
        vin,
        vehicleInfo: vinResult,
        auctionHouse,
        bidAmountUSD: bidAmount,
        shippingCostUSD: shippingCost,
        mileage,
        uaeMarketPriceAED: uaeMarketPrice,
        emirate: selectedEmirate,
        includeRegistration,
        costBreakdown: {
          auctionFeesUSD: auctionFees?.total || 0,
          shippingUSD: shippingCost,
          totalLandedUSD: totalAuctionCostUSD + shippingCost,
          totalLandedAED: Math.round(cifValueAED),
          customsDutyAED: Math.round(importTax.customsDuty),
          vatAED: Math.round(importTax.vat),
          partsAED: Math.round(partsTotal),
          registrationAED: Math.round(registrationTotal),
          totalCostAED: Math.round(grandTotalAED),
          estimatedProfitAED: Math.round(profitAED),
          profitMarginPercent: Math.round(profitPercent),
        },
        damageAnalysis: damageAnalysis || undefined,
        photoUrl: selectedLot?.images?.[0] || undefined,
      };

      const res = await fetch(`/api/trpc/pdfExport.generateReport?batch=1`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ "0": { json: reportData } }),
      });
      const data = await res.json();
      const html = data?.[0]?.result?.data?.json?.html;
      if (!html) throw new Error("Failed to generate report");

      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(html);
        printWindow.document.close();
        setTimeout(() => printWindow.print(), 500);
      }
    } catch (err) {
      toast.error("Failed to generate PDF report");
    }
  }, [vin, vinResult, auctionHouse, bidAmount, shippingCost, mileage, uaeMarketPrice, selectedEmirate, includeRegistration, auctionFees, totalAuctionCostUSD, cifValueAED, importTax, partsTotal, registrationTotal, grandTotalAED, profitAED, profitPercent, damageAnalysis, selectedLot]);

  // ─── AI Damage Analysis Handler ───
  const handleAnalyzeDamage = useCallback(async () => {
    if (!selectedLot?.images?.length) return;
    setAnalysisLoading(true);
    setAnalysisError("");
    setDamageAnalysis(null);
    setShowAnalysis(true);

    try {
      const resp = await fetch(
        `/api/trpc/damageAnalysis.analyze?batch=1`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            "0": {
              json: {
                imageUrls: selectedLot.images.slice(0, 6),
                vehicleInfo: {
                  year: vinResult?.year || "",
                  make: vinResult?.make || "",
                  model: vinResult?.model || "",
                  primaryDamage: selectedLot.primaryDamage || "",
                  secondaryDamage: selectedLot.secondaryDamage || "",
                },
              },
            },
          }),
        }
      );
      const data = await resp.json();
      const result = data?.[0]?.result?.data?.json;
      if (result?.success) {
        setDamageAnalysis(result.analysis);
      } else {
        setAnalysisError("Analysis failed. Please try again.");
      }
    } catch (err: any) {
      setAnalysisError(err?.message || "Failed to analyze damage");
    } finally {
      setAnalysisLoading(false);
    }
  }, [selectedLot, vinResult]);

  // ─── Damage Type Handler (multi-select) ───
  const handleDamageTypeToggle = useCallback((damageId: string) => {
    setSelectedDamageTypes((prev) => {
      const isAlreadySelected = prev.includes(damageId);
      const next = isAlreadySelected
        ? prev.filter((id) => id !== damageId)
        : [...prev, damageId];

      // Merge auto-select parts from all selected damage types (deduplicated)
      const mergedParts = new Set<string>();
      next.forEach((id) => {
        const damage = DAMAGE_TYPES.find((d) => d.id === id);
        if (damage) {
          damage.autoSelectParts.forEach((partId) => mergedParts.add(partId));
        }
      });
      setSelectedParts(Array.from(mergedParts));
      if (mergedParts.size > 0) {
        setShowParts(true);
      } else {
        setShowParts(false);
      }
      return next;
    });
  }, []);

  const togglePart = (partId: string) => {
    setSelectedParts((prev) =>
      prev.includes(partId) ? prev.filter((p) => p !== partId) : [...prev, partId]
    );
  };

  const partsByCategory = useMemo(() => {
    const map: Record<string, any[]> = {};
    adminParts.forEach((p) => {
      if (!map[p.category]) map[p.category] = [];
      map[p.category].push(p);
    });
    return map;
  }, [adminParts]);

  // Type-safe fee breakdown helpers
  const copartFees = auctionHouse === "copart" && auctionFees
    ? (auctionFees as ReturnType<typeof getCopartTotalFees>)
    : null;
  const iaaiFees = auctionHouse === "iaai" && auctionFees
    ? (auctionFees as ReturnType<typeof getIAAITotalFees>)
    : null;

  return (
    <div className="min-h-screen bg-background">
      <main className="container py-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="font-heading text-2xl sm:text-3xl font-bold">
                {t("calc.title")} <span className="text-gradient">{t("calc.titleAccent")}</span>
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                {t("calc.subtitle")}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={handleReset} className="gap-1.5">
              <RotateCcw className="w-3.5 h-3.5" /> {t("calc.reset")}
            </Button>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-[1fr_380px] gap-6">
          {/* ─── LEFT: Input Sections ─── */}
          <div className="space-y-5">
            {/* STEP 1: VIN Decoder */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-1">
                  <SectionIcon icon={Car} label={t("calc.step1")} />
                  {vinQuota && (
                    <button
                      onClick={vinQuota.limit !== -1 && vinQuota.remaining <= 0 ? () => setShowUpgradeDialog(true) : undefined}
                      className={`text-xs px-3 py-1 rounded-full font-medium transition-all ${
                      vinQuota.limit === -1
                        ? "bg-primary/10 text-primary"
                        : vinQuota.remaining <= 0
                        ? "bg-red-500/10 text-red-500 cursor-pointer hover:bg-red-500/20"
                        : vinQuota.remaining <= 3
                        ? "bg-yellow-500/10 text-yellow-500"
                        : "bg-primary/10 text-primary"
                    }`}>
                      {vinQuota.limit === -1
                        ? "Unlimited VIN lookups"
                        : vinQuota.remaining <= 0
                        ? `${vinQuota.remaining}/${vinQuota.limit} — Upgrade Plan ↑`
                        : `${vinQuota.remaining}/${vinQuota.limit} VIN lookups remaining`}
                    </button>
                  )}
                </div>

                {/* Input Mode Tabs */}
                <div className="flex gap-1 mb-3 p-1 rounded-lg bg-secondary/30 w-fit">
                  <button
                    onClick={() => setInputMode("vin")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                      inputMode === "vin"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    VIN Code
                  </button>
                  <button
                    onClick={() => setInputMode("url")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                      inputMode === "url"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    Listing URL
                  </button>
                </div>

                {inputMode === "vin" ? (
                  /* VIN Input Mode */
                  <>
                    <div className="flex gap-2">
                      <Input
                        placeholder={t("calc.vinPlaceholder") || "Paste VIN or listing URL..."}
                        value={vin}
                        onChange={(e) => {
                          const val = e.target.value;
                          // Auto-detect if user pastes a URL
                          if (val.includes("copart.com") || val.includes("iaai.com") || val.startsWith("http")) {
                            handleSmartPaste(val);
                          } else {
                            setVin(val.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, ""));
                          }
                        }}
                        onPaste={(e) => {
                          const pasted = e.clipboardData.getData("text");
                          if (pasted.includes("copart.com") || pasted.includes("iaai.com") || pasted.startsWith("http")) {
                            e.preventDefault();
                            handleSmartPaste(pasted);
                          }
                        }}
                        maxLength={17}
                        className="font-mono tracking-wider text-sm"
                      />
                      <Button
                        onClick={handleVinDecode}
                        disabled={vinLoading || vin.length !== 17}
                        className="gap-1.5 shrink-0"
                      >
                        {vinLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                        {t("calc.decode")}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1.5">
                      {vin.length}/17 {t("calc.chars")} — {t("calc.searchDesc")}
                    </p>
                  </>
                ) : (
                  /* Listing URL Mode */
                  <>
                    {/* Step 1: Paste URL */}
                    <div className="space-y-3">
                      <div>
                        <Label className="text-xs text-muted-foreground mb-1.5 block">Step 1: Paste auction listing URL</Label>
                        <Input
                          placeholder="Paste Copart or IAAI listing URL..."
                          value={listingUrl}
                          onChange={(e) => {
                            const val = e.target.value;
                            setListingUrl(val);
                            const extracted = extractVinFromUrl(val);
                            if (extracted) setVin(extracted);
                            const info = parseVehicleInfoFromUrl(val);
                            setUrlVehicleInfo(info);
                            if (info?.source) setAuctionHouse(info.source === "iaai" ? "iaai" : "copart");
                          }}
                          onPaste={(e) => {
                            const pasted = e.clipboardData.getData("text").trim();
                            e.preventDefault();
                            setListingUrl(pasted);
                            const extracted = extractVinFromUrl(pasted);
                            if (extracted) setVin(extracted);
                            const info = parseVehicleInfoFromUrl(pasted);
                            setUrlVehicleInfo(info);
                            if (info?.source) setAuctionHouse(info.source === "iaai" ? "iaai" : "copart");
                          }}
                          className="text-sm"
                        />
                      </div>

                      {/* Show extracted vehicle info from URL */}
                      {urlVehicleInfo && (urlVehicleInfo.make || urlVehicleInfo.source) && (
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                          <div className="flex items-center gap-2 mb-1.5">
                            <Car className="w-3.5 h-3.5 text-primary" />
                            <span className="text-xs font-medium text-primary">Detected from URL</span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {urlVehicleInfo.source && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                                {urlVehicleInfo.source === "copart" ? "Copart" : "IAAI"}
                              </span>
                            )}
                            {urlVehicleInfo.lotId && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                                Lot #{urlVehicleInfo.lotId}
                              </span>
                            )}
                            {urlVehicleInfo.year && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                                {urlVehicleInfo.year}
                              </span>
                            )}
                            {urlVehicleInfo.make && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                                {urlVehicleInfo.make}
                              </span>
                            )}
                            {urlVehicleInfo.model && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                                {urlVehicleInfo.model}
                              </span>
                            )}
                            {urlVehicleInfo.trim && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                                {urlVehicleInfo.trim}
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Step 2: Enter VIN */}
                      {listingUrl && !vin && (
                        <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
                          <div className="flex items-center gap-2 mb-2">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                            <span className="text-xs font-medium text-amber-500">VIN required for full decode</span>
                          </div>
                          <p className="text-xs text-amber-500/80 mb-2">
                            Auction sites hide the VIN in their URLs. Copy the VIN from the listing page and paste it below.
                          </p>
                          <div className="flex gap-2">
                            <Input
                              placeholder="Paste VIN here (17 characters)..."
                              value={vin}
                              onChange={(e) => setVin(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, "").slice(0, 17))}
                              maxLength={17}
                              className="font-mono tracking-wider text-sm bg-background"
                            />
                          </div>
                          <p className="text-xs text-amber-500/60 mt-1.5">
                            {vin.length}/17 characters
                          </p>
                        </div>
                      )}

                      {/* VIN extracted successfully */}
                      {vin && vin.length === 17 && (
                        <div className="p-2 rounded-md bg-primary/5 border border-primary/20 flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="text-xs text-primary font-mono">
                            VIN: {vin}
                          </span>
                        </div>
                      )}

                      {/* Decode button */}
                      {(vin.length === 17 || (listingUrl && vin.length > 0)) && (
                        <Button
                          onClick={handleVinDecode}
                          disabled={vinLoading || vin.length !== 17}
                          className="gap-1.5 w-full"
                        >
                          {vinLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                          {t("calc.decode")}
                        </Button>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1.5">
                      Supports Copart and IAAI listing URLs • VIN can be found on the auction listing page
                    </p>
                  </>
                )}

                {vinError && (
                  <div className="mt-3 p-3 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-destructive shrink-0" />
                    <span className="text-xs text-destructive">{vinError}</span>
                  </div>
                )}

                {vinResult && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-3 p-3 rounded-lg bg-primary/5 border border-primary/20"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      <span className="text-sm font-semibold text-primary">{t("calc.vehicleFound")}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 text-xs">
                      <div><span className="text-muted-foreground">{t("calc.year")}:</span> <span className="font-medium">{vinResult.year}</span></div>
                      <div><span className="text-muted-foreground">{t("calc.make")}:</span> <span className="font-medium">{vinResult.make}</span></div>
                      <div><span className="text-muted-foreground">{t("calc.model")}:</span> <span className="font-medium">{vinResult.model}</span></div>
                      {vinResult.trim && <div><span className="text-muted-foreground">{t("calc.trim")}:</span> <span className="font-medium">{vinResult.trim}</span></div>}
                      {vinResult.bodyClass && <div><span className="text-muted-foreground">{t("calc.body")}:</span> <span className="font-medium">{vinResult.bodyClass}</span></div>}
                      {vinResult.engineCylinders && <div><span className="text-muted-foreground">Engine:</span> <span className="font-medium">{vinResult.engineDisplacement}L {vinResult.engineCylinders}cyl</span></div>}
                      {vinResult.driveType && <div><span className="text-muted-foreground">{t("calc.drive")}:</span> <span className="font-medium">{vinResult.driveType}</span></div>}
                      {vinResult.fuelType && <div><span className="text-muted-foreground">{t("calc.fuel")}:</span> <span className="font-medium">{vinResult.fuelType}</span></div>}
                    </div>
                  </motion.div>
                )}

                {/* ─── AUCTION LOT DATA (from auction-api.app) ─── */}
                {selectedLot && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Camera className="w-4 h-4 text-amber-400" />
                        <span className="text-sm font-semibold text-amber-400">{t("calc.auctionListingFound")}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">
                          {selectedLot.source}
                        </span>
                      </div>
                      {selectedLot.url && (
                        <a href={selectedLot.url} target="_blank" rel="noopener noreferrer" className="text-xs text-amber-400 hover:underline flex items-center gap-1">
                          {t("calc.viewOn")} {selectedLot.source === "iaai" ? "IAAI" : "Copart"} <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 text-xs mb-2">
                      {selectedLot.primaryDamage && (
                        <div><span className="text-muted-foreground">{t("calc.primaryDamage")}:</span> <span className="font-medium text-red-400">{selectedLot.primaryDamage}</span></div>
                      )}
                      {selectedLot.secondaryDamage && (
                        <div><span className="text-muted-foreground">Secondary Damage:</span> <span className="font-medium text-orange-400">{selectedLot.secondaryDamage}</span></div>
                      )}
                      {selectedLot.lossType && (
                        <div><span className="text-muted-foreground">Loss:</span> <span className="font-medium">{selectedLot.lossType}</span></div>
                      )}
                      {selectedLot.titleType && (
                        <div><span className="text-muted-foreground">Title:</span> <span className="font-medium">{selectedLot.titleType}</span></div>
                      )}
                      {selectedLot.color && (
                        <div><span className="text-muted-foreground">{t("calc.color")}:</span> <span className="font-medium">{selectedLot.color}</span></div>
                      )}
                      {selectedLot.location && (
                        <div><span className="text-muted-foreground">{t("calc.location")}:</span> <span className="font-medium">{selectedLot.location}</span></div>
                      )}
                      {selectedLot.saleDate && (
                        <div><span className="text-muted-foreground">{t("calc.saleDate")}:</span> <span className="font-medium">{selectedLot.saleDate}</span></div>
                      )}
                      {selectedLot.currentBid > 0 && (
                        <div><span className="text-muted-foreground">Current Bid:</span> <span className="font-medium text-emerald-400">${selectedLot.currentBid.toLocaleString()}</span></div>
                      )}
                    </div>

                    {/* Photo Gallery */}
                    {selectedLot.images?.length > 0 && (
                      <div>
                        <button
                          onClick={() => setShowLotPhotos(!showLotPhotos)}
                          className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 transition-colors mb-2"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          {showLotPhotos ? t("calc.hidePhotos") : t("calc.showPhotos")}
                          {showLotPhotos ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                        <AnimatePresence>
                          {showLotPhotos && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="grid grid-cols-3 sm:grid-cols-4 gap-2"
                            >
                              {selectedLot.images.map((img: string, i: number) => (
                                <div
                                  key={i}
                                  className="block rounded-md overflow-hidden border border-border/30 hover:border-amber-500/50 transition-colors cursor-pointer group relative"
                                  onClick={() => setLightboxPhoto({ url: img, description: `Photo ${i + 1}`, damages: [] })}
                                >
                                  <img src={img} alt={`Lot photo ${i + 1}`} className="w-full h-20 object-cover" loading="lazy" />
                                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                                    <ZoomIn className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                                  </div>
                                </div>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )}

                    {!selectedLot.images?.length && (
                      <p className="text-[10px] text-muted-foreground">No photos available for this lot</p>
                    )}

                    {/* AI Damage Analysis Button */}
                    {selectedLot.images?.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-amber-500/10">
                        {!damageAnalysis && !analysisLoading && (
                          <Button
                            onClick={handleAnalyzeDamage}
                            variant="outline"
                            size="sm"
                            className="w-full bg-gradient-to-r from-violet-600/20 to-blue-600/20 border-violet-500/30 hover:border-violet-500/50 text-violet-300 hover:text-violet-200 transition-all"
                          >
                            <Brain className="w-4 h-4 mr-2" />
                            {t("calc.aiDamage")}
                            <Sparkles className="w-3 h-3 ml-2 text-violet-400" />
                          </Button>
                        )}

                        {analysisLoading && (
                          <div className="flex flex-col items-center gap-2 py-4">
                            <div className="relative">
                              <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
                              <Brain className="w-4 h-4 text-violet-300 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                            </div>
                            <p className="text-xs text-violet-300 animate-pulse">AI is analyzing {Math.min(selectedLot.images.length, 6)} photos for damage...</p>
                            <p className="text-[10px] text-muted-foreground">This may take 10-20 seconds</p>
                          </div>
                        )}

                        {analysisError && (
                          <div className="flex items-center gap-2 p-2 rounded bg-red-500/10 border border-red-500/20">
                            <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                            <p className="text-xs text-red-400">{analysisError}</p>
                            <Button onClick={handleAnalyzeDamage} variant="ghost" size="sm" className="ml-auto text-xs h-6 px-2">
                              Retry
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                )}

                {/* ─── AI DAMAGE ANALYSIS RESULTS ─── */}
                {damageAnalysis && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-3 rounded-lg border border-violet-500/20 overflow-hidden"
                  >
                    {/* Header */}
                    <button
                      onClick={() => setShowAnalysis(!showAnalysis)}
                      className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-violet-600/10 to-blue-600/10 hover:from-violet-600/15 hover:to-blue-600/15 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Brain className="w-4 h-4 text-violet-400" />
                        <span className="text-sm font-semibold text-violet-300">AI Damage Analysis</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium uppercase ${
                          damageAnalysis.overallSeverity === "minor" ? "bg-green-500/10 text-green-400 border border-green-500/20" :
                          damageAnalysis.overallSeverity === "moderate" ? "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20" :
                          damageAnalysis.overallSeverity === "severe" ? "bg-orange-500/10 text-orange-400 border border-orange-500/20" :
                          "bg-red-500/10 text-red-400 border border-red-500/20"
                        }`}>
                          {damageAnalysis.overallSeverity.replace("_", " ")}
                        </span>
                        <span className="text-[10px] text-muted-foreground">{damageAnalysis.overallSeverityScore}/10</span>
                      </div>
                      {showAnalysis ? <ChevronUp className="w-4 h-4 text-violet-400" /> : <ChevronDown className="w-4 h-4 text-violet-400" />}
                    </button>

                    <AnimatePresence>
                      {showAnalysis && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="p-3 space-y-3"
                        >
                          {/* Summary */}
                          <div className="p-2.5 rounded-md bg-violet-500/5 border border-violet-500/10">
                            <p className="text-xs leading-relaxed">{damageAnalysis.summary}</p>
                          </div>

                          {/* Severity Bar */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] text-muted-foreground">
                              <span>Minor</span>
                              <span>Total Loss</span>
                            </div>
                            <div className="h-2 rounded-full bg-secondary/50 overflow-hidden">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${damageAnalysis.overallSeverityScore * 10}%` }}
                                transition={{ duration: 1, ease: "easeOut" }}
                                className={`h-full rounded-full ${
                                  damageAnalysis.overallSeverityScore <= 3 ? "bg-green-500" :
                                  damageAnalysis.overallSeverityScore <= 5 ? "bg-yellow-500" :
                                  damageAnalysis.overallSeverityScore <= 7 ? "bg-orange-500" :
                                  "bg-red-500"
                                }`}
                              />
                            </div>
                          </div>

                          {/* Damage List with Repair Checkboxes */}
                          {damageAnalysis.damages?.length > 0 && (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5 text-xs font-semibold text-violet-300">
                                  <ShieldAlert className="w-3.5 h-3.5" />
                                  Identified Damages ({damageAnalysis.damages.length})
                                </div>
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => {
                                      const allIndices = new Set<number>(damageAnalysis.damages.map((_: any, i: number) => i));
                                      setSelectedRepairAreas(allIndices);
                                    }}
                                    className="text-[10px] text-emerald-400 hover:text-emerald-300 underline"
                                  >
                                    Select All
                                  </button>
                                  <span className="text-[10px] text-muted-foreground">|</span>
                                  <button
                                    onClick={() => setSelectedRepairAreas(new Set())}
                                    className="text-[10px] text-muted-foreground hover:text-foreground underline"
                                  >
                                    Clear
                                  </button>
                                </div>
                              </div>
                              <p className="text-[10px] text-muted-foreground -mt-1">
                                Check the parts you plan to repair — selected costs are added to your Total Cost Breakdown
                              </p>
                              <div className="space-y-1.5">
                                {damageAnalysis.damages.map((dmg: any, i: number) => {
                                  const isSelected = selectedRepairAreas.has(i);
                                  const cost = dmg.estimatedRepairCostAED || dmg.estimatedRepairCostUSD;
                                  const avgCost = cost ? Math.round((cost.low + cost.high) / 2) : 0;
                                  return (
                                    <div
                                      key={i}
                                      className={`p-2.5 rounded-md border cursor-pointer transition-all ${
                                        isSelected
                                          ? "bg-emerald-500/10 border-emerald-500/30"
                                          : "bg-secondary/20 border-border/20 hover:border-border/40"
                                      }`}
                                      onClick={() => {
                                        setSelectedRepairAreas(prev => {
                                          const next = new Set(prev);
                                          if (next.has(i)) next.delete(i);
                                          else next.add(i);
                                          return next;
                                        });
                                      }}
                                    >
                                      <div className="flex items-start gap-2">
                                        <Checkbox
                                          checked={isSelected}
                                          className="mt-0.5 shrink-0 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                                          onCheckedChange={() => {
                                            setSelectedRepairAreas(prev => {
                                              const next = new Set(prev);
                                              if (next.has(i)) next.delete(i);
                                              else next.add(i);
                                              return next;
                                            });
                                          }}
                                        />
                                        <div className="flex-1">
                                          <div className="flex items-center gap-2 mb-1">
                                            <span className="text-xs font-medium">{dmg.area}</span>
                                            {dmg.partCategory && (
                                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-violet-500/10 text-violet-400 border border-violet-500/20">
                                                {dmg.partCategory}
                                              </span>
                                            )}
                                            <span className={`text-[9px] px-1 py-0.5 rounded uppercase font-medium ${
                                              dmg.severity === "minor" ? "bg-green-500/10 text-green-400" :
                                              dmg.severity === "moderate" ? "bg-yellow-500/10 text-yellow-400" :
                                              "bg-red-500/10 text-red-400"
                                            }`}>
                                              {dmg.severity}
                                            </span>
                                            {isSelected && (
                                              <span className="text-[9px] px-1 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                                ✓ In Cost
                                              </span>
                                            )}
                                          </div>
                                          <p className="text-[11px] text-muted-foreground leading-relaxed mb-1.5">{dmg.description}</p>
                                          <div className="flex flex-wrap gap-x-3 gap-y-1">
                                            {dmg.repairMethod && (
                                              <span className="text-[10px] text-blue-400">
                                                <span className="text-muted-foreground">Repair:</span> {dmg.repairMethod}
                                              </span>
                                            )}
                                            {dmg.paintRequired !== undefined && (
                                              <span className="text-[10px]">
                                                <span className="text-muted-foreground">Paint:</span>{" "}
                                                <span className={dmg.paintRequired ? "text-amber-400" : "text-green-400"}>
                                                  {dmg.paintRequired ? "Required" : "Not needed"}
                                                </span>
                                              </span>
                                            )}
                                            {dmg.oem_vs_aftermarket && (
                                              <span className="text-[10px] text-cyan-400">
                                                <span className="text-muted-foreground">Parts:</span> {dmg.oem_vs_aftermarket}
                                              </span>
                                            )}
                                          </div>
                                        </div>
                                        <div className="text-right shrink-0">
                                          <p className="text-[10px] text-muted-foreground">Est. Repair</p>
                                          <p className={`text-xs font-semibold ${isSelected ? "text-emerald-400" : "text-muted-foreground"}`}>
                                            AED {cost?.low?.toLocaleString()} - {cost?.high?.toLocaleString()}
                                          </p>
                                          {isSelected && (
                                            <p className="text-[9px] text-emerald-400/70 mt-0.5">Avg: AED {avgCost.toLocaleString()}</p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* Selected Repair Cost Summary */}
                          <div className="p-2.5 rounded-md bg-emerald-500/5 border border-emerald-500/20">
                            <div className="flex items-center justify-between mb-1">
                              <div className="flex items-center gap-1.5">
                                <CircleDollarSign className="w-4 h-4 text-emerald-400" />
                                <span className="text-xs font-semibold text-emerald-300">Repair Cost (Selected)</span>
                              </div>
                              <span className="text-sm font-bold text-emerald-400">
                                {selectedRepairAreas.size > 0 ? formatAED(selectedRepairCostAED) : "AED 0"}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] text-muted-foreground">
                                {selectedRepairAreas.size} of {damageAnalysis.damages?.length || 0} areas selected
                              </span>
                              <span className="text-[10px] text-muted-foreground">
                                Full range: AED {(damageAnalysis.estimatedTotalRepairAED || damageAnalysis.estimatedTotalRepairUSD)?.low?.toLocaleString()} - {(damageAnalysis.estimatedTotalRepairAED || damageAnalysis.estimatedTotalRepairUSD)?.high?.toLocaleString()}
                              </span>
                            </div>
                          </div>

                          {/* Structural Damage Alert */}
                          {damageAnalysis.structuralDamage?.detected && (
                            <div className="p-2.5 rounded-md bg-red-500/10 border border-red-500/30">
                              <div className="flex items-center gap-1.5 mb-1">
                                <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                                <span className="text-xs font-semibold text-red-400">⚠ Structural Damage Detected</span>
                              </div>
                              <p className="text-[11px] text-red-300/80 leading-relaxed mb-1">{damageAnalysis.structuralDamage.details}</p>
                              {damageAnalysis.structuralDamage.affectedAreas?.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {damageAnalysis.structuralDamage.affectedAreas.map((area: string, i: number) => (
                                    <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30">
                                      {area}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Estimated Repair Time */}
                          {damageAnalysis.estimatedRepairDays && (
                            <div className="p-2.5 rounded-md bg-indigo-500/5 border border-indigo-500/20">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                                  <span className="text-xs font-semibold text-indigo-300">Estimated Repair Time</span>
                                </div>
                                <span className="text-sm font-bold text-indigo-400">
                                  {damageAnalysis.estimatedRepairDays.low} - {damageAnalysis.estimatedRepairDays.high} days
                                </span>
                              </div>
                            </div>
                          )}

                          {/* Repairable Assessment */}
                          <div className="p-2.5 rounded-md bg-blue-500/5 border border-blue-500/20">
                            <p className="text-xs leading-relaxed">
                              <span className="font-semibold text-blue-300">UAE Import Assessment: </span>
                              {damageAnalysis.repairableAssessment}
                            </p>
                          </div>

                          {/* Recommendations */}
                          {damageAnalysis.recommendations?.length > 0 && (
                            <div className="space-y-1.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300">
                                <Lightbulb className="w-3.5 h-3.5" />
                                Recommendations
                              </div>
                              <ul className="space-y-1">
                                {damageAnalysis.recommendations.map((rec: string, i: number) => (
                                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
                                    <span className="text-amber-400 mt-0.5">•</span>
                                    {rec}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Photo-by-Photo Analysis */}
                          {damageAnalysis.photoAnalysis?.length > 0 && (
                            <div className="space-y-1.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-violet-300">
                                <Camera className="w-3.5 h-3.5" />
                                Photo-by-Photo Analysis
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {damageAnalysis.photoAnalysis.map((pa: any, i: number) => (
                                  <div
                                    key={i}
                                    className="rounded-md overflow-hidden border border-border/20 cursor-pointer group hover:border-primary/40 transition-colors"
                                    onClick={() => {
                                      if (selectedLot.images?.[pa.photoIndex]) {
                                        setLightboxPhoto({
                                          url: selectedLot.images[pa.photoIndex],
                                          description: pa.description,
                                          damages: pa.visibleDamages || [],
                                          damageLocations: pa.damageLocations || [],
                                        });
                                      }
                                    }}
                                  >
                                    {selectedLot.images?.[pa.photoIndex] && (
                                      <div className="relative">
                                        <img
                                          src={selectedLot.images[pa.photoIndex]}
                                          alt={`Analysis photo ${pa.photoIndex + 1}`}
                                          className="w-full h-28 object-cover"
                                          loading="lazy"
                                        />
                                        {/* Damage count badge */}
                                        {pa.visibleDamages?.length > 0 && (
                                          <div className="absolute top-1.5 left-1.5 flex items-center gap-1 bg-red-600/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                                            {pa.visibleDamages.length} {lang === "ar" ? "ضرر" : "damages"}
                                          </div>
                                        )}
                                        {/* Zoom icon on hover */}
                                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                                          <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                      </div>
                                    )}
                                    <div className="p-2 bg-secondary/20">
                                      <p className="text-[11px] text-muted-foreground mb-1 line-clamp-2">{pa.description}</p>
                                      {pa.visibleDamages?.length > 0 && (
                                        <div className="flex flex-wrap gap-1">
                                          {pa.visibleDamages.slice(0, 3).map((d: string, j: number) => (
                                            <span key={j} className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                                              {d}
                                            </span>
                                          ))}
                                          {pa.visibleDamages.length > 3 && (
                                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                                              +{pa.visibleDamages.length - 3} more
                                            </span>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Re-analyze button */}
                          <Button
                            onClick={handleAnalyzeDamage}
                            variant="ghost"
                            size="sm"
                            className="w-full text-xs text-violet-400 hover:text-violet-300"
                          >
                            <RotateCcw className="w-3 h-3 mr-1.5" />
                            Re-analyze Photos
                          </Button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}

                {/* ─── MILEAGE INPUT ─── */}
                {vinResult && (
                  <div className="mt-3 p-3 rounded-lg bg-secondary/30 border border-border/30">
                    <Label className="text-xs font-semibold mb-2 block">Odometer (Miles)</Label>
                    <div className="flex items-center gap-3">
                      <Input
                        type="number"
                        placeholder="e.g. 45000"
                        value={mileage || ""}
                        onChange={(e) => setMileage(Number(e.target.value))}
                        className="h-9 text-sm max-w-[180px]"
                      />
                      {mileage > 0 && (
                        <div className="flex items-center gap-1.5 text-xs">
                          <ArrowRight className="w-3 h-3 text-muted-foreground" />
                          <span className="font-semibold text-primary tabular-nums">
                            {Math.round(mileage * 1.60934).toLocaleString()} km
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* ─── AUTO MARKET PRICE ESTIMATION ─── */}
                {vinResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="mt-3"
                  >
                    {marketPriceEstimate ? (
                      <div className="p-4 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                        <div className="flex items-center gap-2 mb-3">
                          <Sparkles className="w-4 h-4 text-emerald-400" />
                          <span className="text-sm font-semibold text-emerald-400">UAE Market Price Estimate</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            American Spec
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mb-3">
                          Based on UAE market data for {vinResult.year} {vinResult.make} {vinResult.model} (US/American spec)
                        </p>

                        {/* Selected Price Display */}
                        <div className="text-center mb-4">
                          <span className="text-2xl font-bold text-emerald-400 tabular-nums">
                            {formatAED(uaeMarketPrice)}
                          </span>
                          <p className="text-[10px] text-muted-foreground mt-0.5">Selected Selling Price</p>
                        </div>

                        {/* Interactive Price Slider */}
                        <div className="relative mb-3 px-1">
                          <Slider
                            min={marketPriceEstimate.low}
                            max={marketPriceEstimate.high}
                            step={500}
                            value={[uaeMarketPrice]}
                            onValueChange={(values) => setUaeMarketPrice(values[0])}
                            className="[&_[data-slot=slider-track]]:h-2.5 [&_[data-slot=slider-track]]:bg-gradient-to-r [&_[data-slot=slider-track]]:from-red-500/30 [&_[data-slot=slider-track]]:via-emerald-500/40 [&_[data-slot=slider-track]]:to-emerald-400/30 [&_[data-slot=slider-range]]:bg-emerald-500/60 [&_[data-slot=slider-thumb]]:h-5 [&_[data-slot=slider-thumb]]:w-5 [&_[data-slot=slider-thumb]]:border-2 [&_[data-slot=slider-thumb]]:border-emerald-500 [&_[data-slot=slider-thumb]]:bg-emerald-400 [&_[data-slot=slider-thumb]]:shadow-lg [&_[data-slot=slider-thumb]]:shadow-emerald-500/30 cursor-pointer"
                          />
                          <div className="flex justify-between mt-2">
                            <span className="text-[10px] font-semibold text-red-400">Low: {formatAED(marketPriceEstimate.low)}</span>
                            <span className="text-[10px] font-semibold text-emerald-300">High: {formatAED(marketPriceEstimate.high)}</span>
                          </div>
                        </div>

                        {/* Quick Preset Buttons */}
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={uaeMarketPrice === marketPriceEstimate.low ? "default" : "outline"}
                            className={`text-xs h-7 flex-1 ${
                              uaeMarketPrice === marketPriceEstimate.low
                                ? "bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30"
                                : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                            }`}
                            onClick={() => setUaeMarketPrice(marketPriceEstimate.low)}
                          >
                            Low
                          </Button>
                          <Button
                            size="sm"
                            variant={uaeMarketPrice === marketPriceEstimate.mid ? "default" : "outline"}
                            className={`text-xs h-7 flex-1 ${
                              uaeMarketPrice === marketPriceEstimate.mid
                                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30"
                                : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                            }`}
                            onClick={() => setUaeMarketPrice(marketPriceEstimate.mid)}
                          >
                            Average
                          </Button>
                          <Button
                            size="sm"
                            variant={uaeMarketPrice === marketPriceEstimate.high ? "default" : "outline"}
                            className={`text-xs h-7 flex-1 ${
                              uaeMarketPrice === marketPriceEstimate.high
                                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30"
                                : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                            }`}
                            onClick={() => setUaeMarketPrice(marketPriceEstimate.high)}
                          >
                            High
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
                        <div className="flex items-center gap-2 mb-1">
                          <Search className="w-3.5 h-3.5 text-amber-400" />
                          <span className="text-xs font-semibold text-amber-400">No Price Data Available</span>
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          We don't have price data for this model yet. Use the marketplace links below to check manually.
                        </p>
                      </div>
                    )}

                    {/* Marketplace Search Links */}
                    {marketplaceLinks.length > 0 && (
                      <div className="mt-3 p-3 rounded-lg bg-secondary/20 border border-border/30">
                        <p className="text-xs font-semibold mb-2 flex items-center gap-1.5">
                          <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
                          Verify on UAE Marketplaces
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {marketplaceLinks.map((link) => (
                            <a
                              key={link.name}
                              href={link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-secondary/40 hover:bg-secondary/70 border border-border/30 text-xs font-medium transition-colors"
                            >
                              <span>{link.icon}</span>
                              <span>{link.name}</span>
                              <ArrowRight className="w-3 h-3 text-muted-foreground" />
                            </a>
                          ))}
                        </div>
                        <p className="text-[10px] text-muted-foreground mt-2">
                          Tip: Filter for "American Specs" on Dubizzle to see prices for US-imported cars specifically
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}
              </CardContent>
            </Card>

            {/* STEP 2: Auction & Bid */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <SectionIcon icon={DollarSign} label={t("calc.step2")} />
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs">{t("calc.auctionHouse")}</Label>
                    <Select value={auctionHouse} onValueChange={(v) => setAuctionHouse(v as "copart" | "iaai")}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="copart">Copart</SelectItem>
                        <SelectItem value="iaai">IAAI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">
                      {t("calc.bidAmount")}
                      <InfoTip text="Enter your bid price in US dollars. Auction fees will be calculated automatically based on the selected auction house fee schedule." />
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">$</span>
                      <Input
                        type="number"
                        placeholder="0"
                        value={bidAmount || ""}
                        onChange={(e) => setBidAmount(Number(e.target.value))}
                        className="pl-7 tabular-nums"
                      />
                    </div>
                  </div>
                </div>

                {auctionFees && bidAmount > 0 && (
                  <div className="mt-3 p-3 rounded-lg bg-secondary/30 text-xs space-y-1">
                    <div className="flex justify-between"><span className="text-muted-foreground">Buyer Fee</span><span className="tabular-nums">{formatUSD(auctionFees.buyerFee)}</span></div>
                    {copartFees && (
                      <>
                        <div className="flex justify-between"><span className="text-muted-foreground">Gate Fee</span><span className="tabular-nums">{formatUSD(copartFees.gateFee)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Environmental Fee</span><span className="tabular-nums">{formatUSD(copartFees.envFee)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Virtual Bid Fee</span><span className="tabular-nums">{formatUSD(copartFees.virtualFee)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Title Handling</span><span className="tabular-nums">{formatUSD(copartFees.titleFee)}</span></div>
                      </>
                    )}

                    <Separator className="my-1 opacity-30" />
                    <div className="flex justify-between font-semibold"><span>Total Auction Fees</span><span className="tabular-nums text-primary">{formatUSD(auctionFees.total)}</span></div>
                    <div className="flex justify-between font-semibold"><span>Car + Fees (USD)</span><span className="tabular-nums">{formatUSD(totalAuctionCostUSD)}</span></div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* STEP 3: Shipping */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <SectionIcon icon={Ship} label={t("calc.step3")} />
                {shippingAutoFilled && shippingMatch && (
                  <div className="mb-3 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium mb-1">
                      <MapPin className="w-3 h-3" />
                      Auto-filled from auction location
                    </div>
                    <div className="text-[10px] text-muted-foreground space-y-0.5">
                      <div className="flex justify-between"><span>Location:</span><span className="font-medium text-foreground">{shippingMatch.city}, {shippingMatch.state}</span></div>
                      <div className="flex justify-between"><span>Loading Port:</span><span className="font-medium text-foreground">{shippingMatch.port}</span></div>
                      <div className="flex justify-between"><span>Rate:</span><span className="font-medium text-emerald-400">{formatUSD(shippingCost)}</span></div>
                    </div>
                  </div>
                )}

                {/* Manual Shipping Location Selector */}
                {!shippingAutoFilled && (
                  <div className="mb-3">
                    <button
                      type="button"
                      onClick={() => setShowManualShipping(!showManualShipping)}
                      className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors mb-2"
                    >
                      <MapPin className="w-3 h-3" />
                      {showManualShipping ? "Hide" : "Look up"} shipping rate by location
                      {showManualShipping ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                    <AnimatePresence>
                      {showManualShipping && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/20 space-y-2.5">
                            <p className="text-[10px] text-muted-foreground">Select auction location to auto-fill shipping cost from our 382-route database.</p>
                            {/* Auction House Toggle */}
                            <div>
                              <Label className="text-[10px] text-muted-foreground mb-1 block">Auction House</Label>
                              <div className="flex gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => { setManualShipAuction("copart"); setManualShipCity(""); }}
                                  className={`px-3 py-1 text-[10px] font-medium rounded-md transition-colors ${
                                    manualShipAuction === "copart"
                                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                                      : "bg-muted/30 text-muted-foreground border border-border/30 hover:bg-muted/50"
                                  }`}
                                >
                                  Copart
                                </button>
                                <button
                                  type="button"
                                  onClick={() => { setManualShipAuction("iaai"); setManualShipCity(""); }}
                                  className={`px-3 py-1 text-[10px] font-medium rounded-md transition-colors ${
                                    manualShipAuction === "iaai"
                                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                                      : "bg-muted/30 text-muted-foreground border border-border/30 hover:bg-muted/50"
                                  }`}
                                >
                                  IAAI
                                </button>
                              </div>
                            </div>
                            {/* State Dropdown */}
                            <div>
                              <Label className="text-[10px] text-muted-foreground mb-1 block">State</Label>
                              <Select
                                value={manualShipState}
                                onValueChange={(val) => {
                                  setManualShipState(val);
                                  setManualShipCity("");
                                }}
                              >
                                <SelectTrigger className="h-8 text-xs">
                                  <SelectValue placeholder="Select state..." />
                                </SelectTrigger>
                                <SelectContent className="max-h-60">
                                  {stateList.map((s) => (
                                    <SelectItem key={s.state} value={s.state}>
                                      {s.state} — avg {formatUSD(s.avgPrice)} ({s.count} routes)
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            {/* City Dropdown */}
                            {manualShipState && (
                              <div>
                                <Label className="text-[10px] text-muted-foreground mb-1 block">City / Yard</Label>
                                <Select
                                  value={manualShipCity}
                                  onValueChange={(val) => {
                                    setManualShipCity(val);
                                    // Find the rate and auto-fill
                                    const rate = citiesForState.find(r => r.city === val);
                                    if (rate) {
                                      setShippingCost(rate.price);
                                      setShippingAutoFilled(true);
                                      setShippingMatch({ city: rate.city, state: rate.state, port: rate.loadingPort });
                                      setShowManualShipping(false);
                                    }
                                  }}
                                >
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue placeholder="Select city..." />
                                  </SelectTrigger>
                                  <SelectContent className="max-h-60">
                                    {citiesForState.length === 0 ? (
                                      <SelectItem value="_none" disabled>No {manualShipAuction === "copart" ? "Copart" : "IAAI"} locations in {manualShipState}</SelectItem>
                                    ) : (
                                      citiesForState.map((r, i) => (
                                        <SelectItem key={`${r.city}-${i}`} value={r.city}>
                                          {r.city} — {formatUSD(r.price)}
                                        </SelectItem>
                                      ))
                                    )}
                                  </SelectContent>
                                </Select>
                                {citiesForState.length === 0 && manualShipState && (
                                  <p className="text-[10px] text-amber-400/70 mt-1">Try switching to {manualShipAuction === "copart" ? "IAAI" : "Copart"} for this state.</p>
                                )}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                <div>
                  <Label className="text-xs">
                    Shipping Cost (USD)
                    <InfoTip text="Auto-filled based on auction location from 382 Copart/IAAI shipping routes. You can override this value manually." />
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">$</span>
                    <Input
                      type="number"
                      placeholder="0"
                      value={shippingCost || ""}
                      onChange={(e) => {
                        setShippingCost(Number(e.target.value));
                        if (shippingAutoFilled) setShippingAutoFilled(false);
                      }}
                      className={`pl-7 tabular-nums ${shippingAutoFilled ? "border-emerald-500/30" : ""}`}
                    />
                  </div>
                  {!shippingAutoFilled && !showManualShipping && (
                    <p className="text-[10px] text-muted-foreground mt-1">Typical range: $800 (RoRo) — $2,500 (Container)</p>
                  )}
                  {shippingAutoFilled && (
                    <p className="text-[10px] text-emerald-400/70 mt-1">Rate from shipping database — edit to override</p>
                  )}
                </div>

                {/* WhatsApp Shipping Quote Request */}
                {shippingCompanies && shippingCompanies.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border/30">
                    <button
                      type="button"
                      onClick={handleWhatsAppQuote}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#25D366] text-xs font-medium transition-all hover:scale-[1.01] active:scale-[0.99]"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Request Shipping Quote via WhatsApp
                    </button>
                    <p className="text-[10px] text-muted-foreground mt-1.5 text-center">
                      Get an exact quote from {shippingCompanies[0].name.trim()} — opens WhatsApp with vehicle details
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* STEP 4: Customs & VAT (auto-calculated) */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <SectionIcon icon={Shield} label={t("calc.step4")} />
                <p className="text-xs text-muted-foreground mb-3">
                  {lang === "ar" ? `محسوبة على سعر السيارة + رسوم المزاد (بدون الشحن) بسعر صرف ${USD_TO_AED}` : `Calculated on Car Price + Auction Fees (excluding shipping) at rate ${USD_TO_AED}`}
                </p>
                <div className="p-3 rounded-lg bg-secondary/30 text-xs space-y-1">
                  <div className="flex justify-between"><span className="text-muted-foreground">{lang === "ar" ? "السيارة + رسوم المزاد" : "Car + Auction Fees"}</span><span className="tabular-nums">{formatAED(totalAuctionCostAED)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{lang === "ar" ? "الرسوم الجمركية (5%)" : "Customs Duty (5%)"}</span><span className="tabular-nums">{formatAED(importTax.customsDuty)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{lang === "ar" ? "ضريبة القيمة المضافة (5%)" : "VAT (5% on Car + Fees + Duty)"}</span><span className="tabular-nums">{formatAED(importTax.vat)}</span></div>
                  <Separator className="my-1 opacity-30" />
                  <div className="flex justify-between font-semibold"><span>Total Import Tax</span><span className="tabular-nums text-primary">{formatAED(importTax.total)}</span></div>
                </div>
              </CardContent>
            </Card>

            {/* STEP 5: Spare Parts Calculation */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <SectionIcon icon={Wrench} label={t("calc.step5")} />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowParts(!showParts)}
                    className="gap-1 text-xs"
                  >
                    {selectedParts.length > 0 && (
                      <span className="bg-primary text-primary-foreground rounded-full px-1.5 py-0.5 text-[10px] font-bold">
                        {selectedParts.length}
                      </span>
                    )}
                    {showParts ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mb-3">
                  Select parts you need to replace. Prices are approximate UAE spare parts market averages.
                </p>

                {showParts && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-4"
                  >
                    {Object.entries(partsByCategory).map(([category, parts]) => (
                      <div key={category}>
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">{category}</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          {parts.map((part) => (
                            <label
                              key={part.id}
                              className={`flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors text-xs ${
                                selectedParts.includes(part.id)
                                  ? "bg-primary/10 border border-primary/30"
                                  : "bg-secondary/20 border border-transparent hover:bg-secondary/40"
                              }`}
                            >
                              <Checkbox
                                checked={selectedParts.includes(part.id)}
                                onCheckedChange={() => togglePart(part.id)}
                              />
                              <span className="flex-1">{part.name}</span>
                              <span className="text-muted-foreground tabular-nums">~{formatAED(part.priceAED)}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}

                {selectedParts.length > 0 && (
                  <div className="mt-3 p-3 rounded-lg bg-secondary/30 text-xs">
                    <div className="flex justify-between font-semibold">
                      <span>Parts Total ({selectedParts.length} items)</span>
                      <span className="tabular-nums text-primary">{formatAED(partsTotal)}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* STEP 6: Damage Type Selection */}
            <Card className="glass-card border-border/40">
              <CardContent className="p-5">
                <SectionIcon icon={AlertTriangle} label={t("calc.step6")} />
                <p className="text-xs text-muted-foreground mb-3">
                  Select all damage types from the Copart/IAAI listing (primary + secondary). Parts will be auto-selected and merged.
                </p>
                {selectedDamageTypes.length > 0 && (
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <span className="text-[10px] text-muted-foreground">Selected:</span>
                    {selectedDamageTypes.map((id: string) => {
                      const d = DAMAGE_TYPES.find((dt: any) => (dt as any).id === id);
                      return d ? (
                        <span
                          key={id}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/15 border border-primary/30 text-[10px] font-medium text-primary"
                        >
                          {d.icon} {d.name}
                          <button
                            onClick={() => handleDamageTypeToggle(id)}
                            className="ml-0.5 hover:text-red-400 transition-colors"
                          >
                            ×
                          </button>
                        </span>
                      ) : null;
                    })}
                    <button
                      onClick={() => {
                        setSelectedDamageTypes([]);
                        setSelectedParts([]);
                        setShowParts(false);
                      }}
                      className="text-[10px] text-muted-foreground hover:text-red-400 transition-colors underline"
                    >
                      Clear all
                    </button>
                  </div>
                )}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(DAMAGE_TYPES as any[]).map((damage: any) => {
                    const isSelected = selectedDamageTypes.includes(damage.id);
                    const orderIndex = selectedDamageTypes.indexOf(damage.id);
                    return (
                      <button
                        key={damage.id}
                        onClick={() => handleDamageTypeToggle(damage.id)}
                        className={`flex flex-col items-start gap-1 p-3 rounded-lg text-left transition-all text-xs border relative ${
                          isSelected
                            ? "bg-primary/15 border-primary/40 ring-1 ring-primary/30"
                            : "bg-secondary/20 border-border/20 hover:bg-secondary/40 hover:border-border/40"
                        }`}
                      >
                        {isSelected && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[9px] font-bold">
                            {orderIndex === 0 ? "P" : "S"}
                          </span>
                        )}
                        <div className="flex items-center gap-2 w-full">
                          <span className="text-base">{damage.icon}</span>
                          <span className="font-semibold text-xs">{damage.name}</span>
                        </div>
                        <span className="text-[10px] text-muted-foreground leading-tight">{damage.description}</span>
                        {isSelected && damage.autoSelectParts.length > 0 && (
                          <div className="flex items-center gap-1 mt-1 text-[10px] text-emerald-400">
                            <Zap className="w-3 h-3" />
                            {damage.autoSelectParts.length} parts
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
                {selectedDamageTypes.length > 0 && (
                  <div className="mt-3 p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/15">
                    <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      {selectedParts.length} parts auto-selected from {selectedDamageTypes.length} damage type{selectedDamageTypes.length > 1 ? "s" : ""}. You can still add or remove parts manually below.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* STEP 7: Registration Emirate (Optional) */}
            <Card className={`glass-card border-border/40 transition-opacity ${!includeRegistration ? "opacity-60" : ""}`}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <SectionIcon icon={MapPin} label={t("calc.step7")} />
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground">{includeRegistration ? "Included" : "Skipped"}</span>
                    <button
                      onClick={() => setIncludeRegistration(!includeRegistration)}
                      className={`relative w-10 h-5 rounded-full transition-colors ${
                        includeRegistration ? "bg-primary" : "bg-secondary/50 border border-border/40"
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                          includeRegistration ? "translate-x-5" : "translate-x-0.5"
                        }`}
                      />
                    </button>
                  </div>
                </div>
                {!includeRegistration && (
                  <p className="text-xs text-muted-foreground">Registration fees are not included in the total. Toggle on to add them.</p>
                )}
                {includeRegistration && (
                  <>
                    <Select value={selectedEmirate} onValueChange={setSelectedEmirate}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {EMIRATES.map((e) => (
                          <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="mt-3 p-3 rounded-lg bg-secondary/30 text-xs space-y-1">
                      <div className="flex justify-between"><span className="text-muted-foreground">Registration</span><span className="tabular-nums">{formatAED(emirateReg.registrationFee)}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Inspection</span><span className="tabular-nums">{formatAED(emirateReg.inspectionFee)}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Plate</span><span className="tabular-nums">{formatAED(emirateReg.plateFee)}</span></div>
                      {emirateReg.otherFees > 0 && (
                        <div className="flex justify-between"><span className="text-muted-foreground">Other Fees</span><span className="tabular-nums">{formatAED(emirateReg.otherFees)}</span></div>
                      )}
                      <Separator className="my-1 opacity-30" />
                      <div className="flex justify-between font-semibold"><span>Registration Total</span><span className="tabular-nums text-primary">{formatAED(emirateReg.total)}</span></div>
                      <p className="text-[10px] text-muted-foreground mt-1">{emirateReg.notes}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ─── RIGHT: Summary Panel ─── */}
          <div className="space-y-5">
            <Card className="glass-card border-border/40 lg:sticky lg:top-20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  {t("calc.marketProfit")}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label className="text-xs">
                    {t("calc.expectedPrice")}
                    <InfoTip text="This is auto-filled from our price database when available. You can adjust it based on your own market research." />
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">AED</span>
                    <Input
                      type="number"
                      placeholder="0"
                      value={uaeMarketPrice || ""}
                      onChange={(e) => setUaeMarketPrice(Number(e.target.value))}
                      className="pl-12 tabular-nums"
                    />
                  </div>
                  {marketPriceEstimate && (
                    <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Auto-estimated from our database. Adjust as needed.
                    </p>
                  )}
                  {!marketPriceEstimate && vinResult && (
                    <p className="text-[10px] text-muted-foreground mt-1">
                      Search "{vinResult.year} {vinResult.make} {vinResult.model}" on DubiCars or Dubizzle
                    </p>
                  )}
                </div>

                <Separator />

                {/* Cost Breakdown */}
                <div className="space-y-2 text-xs">
                  <h4 className="font-semibold text-sm">{t("calc.costBreakdown")}</h4>

                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("calc.carFees")}</span>
                    <span className="tabular-nums">{formatAED(totalAuctionCostAED)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("calc.shipping")}</span>
                    <span className="tabular-nums">{formatAED(shippingCostAED)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("calc.customsVat")}</span>
                    <span className="tabular-nums">{formatAED(importTax.total)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("calc.spareParts")}</span>
                    <span className="tabular-nums">{formatAED(partsTotal)}</span>
                  </div>
                  {selectedRepairCostAED > 0 && (
                    <div className="flex justify-between">
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Wrench className="w-3 h-3" /> AI Repair Cost ({selectedRepairAreas.size} areas)
                      </span>
                      <span className="tabular-nums text-emerald-400 font-medium">{formatAED(selectedRepairCostAED)}</span>
                    </div>
                  )}
                  {!selectedRepairCostAED && damageAnalysis?.damages?.length > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground opacity-50">AI Repair Cost</span>
                      <span className="tabular-nums text-muted-foreground opacity-50 text-[10px]">No areas selected</span>
                    </div>
                  )}
                  {includeRegistration && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Registration ({emirateReg.name})</span>
                      <span className="tabular-nums">{formatAED(emirateReg.total)}</span>
                    </div>
                  )}
                  {!includeRegistration && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground line-through opacity-50">Registration</span>
                      <span className="tabular-nums text-muted-foreground opacity-50 text-[10px]">Not included</span>
                    </div>
                  )}

                  <Separator className="opacity-30" />

                  <div className="flex justify-between text-sm font-bold">
                    <span>{t("calc.totalInvestment")}</span>
                    <span className="tabular-nums">{formatAED(grandTotalAED)}</span>
                  </div>

                  {uaeMarketPrice > 0 && (
                    <>
                      <Separator className="opacity-30" />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">{t("calc.uaeMarketPrice")}</span>
                        <span className="tabular-nums">{formatAED(uaeMarketPrice)}</span>
                      </div>
                      <div
                        className={`flex justify-between text-sm font-bold ${
                          profitAED >= 0 ? "text-emerald-400" : "text-red-400"
                        }`}
                      >
                        <span>{profitAED >= 0 ? t("calc.profit") : t("calc.loss")}</span>
                        <span className="tabular-nums">
                          {profitAED >= 0 ? "+" : ""}
                          {formatAED(profitAED)}
                        </span>
                      </div>
                      <div
                        className={`text-center py-3 rounded-lg font-bold text-lg ${
                          profitAED >= 0
                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                            : "bg-red-500/10 text-red-400 border border-red-500/20"
                        }`}
                      >
                        {profitPercent >= 0 ? "+" : ""}
                        {profitPercent.toFixed(1)}% ROI
                      </div>
                    </>
                  )}
                </div>

                {/* ─── Smart Bid Advisor ─── */}
                {uaeMarketPrice > 0 && vinResult && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <button
                        onClick={() => setShowBidAdvisor(!showBidAdvisor)}
                        className="flex items-center justify-between w-full group"
                      >
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-md bg-amber-500/10">
                            <Target className="w-4 h-4 text-amber-400" />
                          </div>
                          <span className="font-heading text-sm font-semibold text-amber-400">Smart Bid Advisor</span>
                        </div>
                        {showBidAdvisor ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </button>

                      <AnimatePresence>
                        {showBidAdvisor && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="space-y-3">
                              {/* Profit Target Selection */}
                              <div className="space-y-2">
                                <Label className="text-xs text-muted-foreground">Desired Profit (AED)</Label>
                                <div className="grid grid-cols-2 gap-1.5">
                                  {PROFIT_TARGETS.map((target) => (
                                    <button
                                      key={target}
                                      onClick={() => {
                                        setSelectedProfitTarget(target);
                                        setCustomProfitTarget("");
                                      }}
                                      className={`px-2 py-1.5 rounded-md text-xs font-medium transition-all ${
                                        !customProfitTarget && selectedProfitTarget === target
                                          ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                          : "bg-muted/50 text-muted-foreground hover:bg-muted border border-transparent"
                                      }`}
                                    >
                                      {formatAED(target)}
                                    </button>
                                  ))}
                                </div>
                                <div className="relative">
                                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">AED</span>
                                  <Input
                                    type="number"
                                    placeholder="Custom profit target..."
                                    value={customProfitTarget}
                                    onChange={(e) => setCustomProfitTarget(e.target.value)}
                                    className="pl-12 text-xs h-8"
                                  />
                                </div>
                              </div>

                              {/* Main Recommendation */}
                              {activeBidResult.feasible ? (
                                <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 space-y-2">
                                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                                    <Crosshair className="w-3.5 h-3.5" />
                                    Maximum Bid
                                  </div>
                                  <div className="text-center">
                                    <div className="text-2xl font-bold text-amber-400 tabular-nums">
                                      {formatUSD(activeBidResult.maxBidUSD)}
                                    </div>
                                    <div className="text-xs text-muted-foreground mt-0.5">
                                      {formatAED(activeBidResult.maxBidAED)}
                                    </div>
                                  </div>
                                  <Separator className="opacity-20" />
                                  <div className="text-[10px] text-muted-foreground space-y-1">
                                    <div className="flex justify-between">
                                      <span>Total Investment</span>
                                      <span className="tabular-nums">{formatAED(activeBidResult.totalCostAED)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>UAE Market Price</span>
                                      <span className="tabular-nums">{formatAED(uaeMarketPrice)}</span>
                                    </div>
                                    <div className="flex justify-between font-medium text-emerald-400">
                                      <span>Target Profit</span>
                                      <span className="tabular-nums">+{formatAED(customProfitTarget ? Number(customProfitTarget) : selectedProfitTarget)}</span>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="rounded-lg border border-red-500/20 bg-red-500/5 p-3 text-center">
                                  <XCircle className="w-5 h-5 text-red-400 mx-auto mb-1" />
                                  <p className="text-xs text-red-400 font-medium">Not Feasible</p>
                                  <p className="text-[10px] text-muted-foreground mt-1">
                                    The costs exceed the market price minus your profit target. Try reducing repair costs or shipping, or lower your profit target.
                                  </p>
                                </div>
                              )}

                              {/* Comparison Table */}
                              <div className="space-y-1">
                                <p className="text-[10px] text-muted-foreground font-medium">Quick Comparison</p>
                                <div className="rounded-md border border-border/50 overflow-hidden">
                                  <table className="w-full text-[10px]">
                                    <thead>
                                      <tr className="bg-muted/30">
                                        <th className="text-left px-2 py-1 font-medium text-muted-foreground">Profit</th>
                                        <th className="text-right px-2 py-1 font-medium text-muted-foreground">Max Bid</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {bidAdvisorResults.map((r) => (
                                        <tr
                                          key={r.target}
                                          className={`border-t border-border/30 cursor-pointer hover:bg-muted/20 transition-colors ${
                                            r.isSelected ? "bg-amber-500/5" : ""
                                          }`}
                                          onClick={() => {
                                            setSelectedProfitTarget(r.target);
                                            setCustomProfitTarget("");
                                          }}
                                        >
                                          <td className={`px-2 py-1 ${r.isSelected ? "text-amber-400 font-medium" : "text-muted-foreground"}`}>
                                            {formatAED(r.target)}
                                          </td>
                                          <td className={`px-2 py-1 text-right tabular-nums ${
                                            r.feasible
                                              ? r.isSelected ? "text-amber-400 font-medium" : "text-foreground"
                                              : "text-red-400 line-through"
                                          }`}>
                                            {r.feasible ? formatUSD(r.maxBidUSD) : "N/A"}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>

                              {/* Apply Bid Button */}
                              {activeBidResult.feasible && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="w-full border-amber-500/30 text-amber-400 hover:bg-amber-500/10 text-xs"
                                  onClick={() => {
                                    setBidAmount(activeBidResult.maxBidUSD);
                                    toast.success(`Bid set to ${formatUSD(activeBidResult.maxBidUSD)}`, {
                                      description: `Target profit: ${formatAED(customProfitTarget ? Number(customProfitTarget) : selectedProfitTarget)}`,
                                    });
                                  }}
                                >
                                  <Target className="w-3.5 h-3.5 mr-1.5" />
                                  Apply This Bid Amount
                                </Button>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </>
                )}

                {/* Save & Export Buttons */}
                {bidAmount > 0 && vinResult && (
                  <>
                    <Separator />
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full border-primary/30 text-primary hover:bg-primary/10"
                        onClick={handleSaveDeal}
                        disabled={savingDeal}
                      >
                        {savingDeal ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <BookmarkPlus className="w-4 h-4 mr-2" />
                        )}
                        {t("calc.saveDeal")}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={handlePdfExport}
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        {t("calc.exportPdf")}
                      </Button>
                    </div>
                  </>
                )}

                {/* Quick USD to AED reference */}
                {bidAmount > 0 && (
                  <>
                    <Separator />
                    <div className="text-[10px] text-muted-foreground space-y-0.5">
                      <p className="font-semibold text-foreground text-xs mb-1">Quick Reference</p>
                      <p>Bid: {formatUSD(bidAmount)} = {formatAED(bidAmount * USD_TO_AED)}</p>
                      <p>Auction Fees: {formatUSD(auctionFees?.total || 0)} = {formatAED((auctionFees?.total || 0) * USD_TO_AED)}</p>
                      <p>Shipping: {formatUSD(shippingCost)} = {formatAED(shippingCostAED)}</p>
                      <p>Exchange Rate: 1 USD = {USD_TO_AED} AED</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* ─── Photo Lightbox Modal ─── */}
      <AnimatePresence>
        {lightboxPhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
            onClick={() => setLightboxPhoto(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative max-w-4xl w-full max-h-[90vh] flex flex-col bg-card rounded-xl overflow-hidden border border-border/30 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={() => setLightboxPhoto(null)}
                className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-black/60 hover:bg-black/80 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Image — clean, no overlays */}
              <div className="relative flex-1 min-h-0">
                <img
                  src={lightboxPhoto.url}
                  alt="Damage analysis"
                  className="w-full max-h-[60vh] object-contain bg-black"
                />
              </div>

              {/* Description panel */}
              <div className="p-4 bg-card border-t border-border/30">
                <p className="text-sm text-foreground mb-2">{lightboxPhoto.description}</p>
                {lightboxPhoto.damages.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {lightboxPhoto.damages.map((d, j) => (
                      <span
                        key={j}
                        className="text-xs px-2 py-1 rounded-full bg-red-500/15 text-red-400 border border-red-500/25 font-medium"
                      >
                        ⚠ {d}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ VIN Limit Upgrade Dialog ═══ */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-foreground text-xl font-heading">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-red-500/10">
                  <Zap className="w-6 h-6 text-red-500" />
                </div>
                VIN Lookups Exhausted
              </div>
            </DialogTitle>
          </DialogHeader>
          <div className="mt-2">
            <p className="text-muted-foreground text-sm mb-4">
              You've used all <span className="font-semibold text-foreground">{vinQuota?.used}/{vinQuota?.limit}</span> VIN lookups for this month. 
              Upgrade your plan to get more lookups and unlock premium features.
            </p>

            {/* Billing Period Toggle */}
            <div className="flex items-center justify-center gap-2 mb-4">
              <button
                onClick={() => setUpgradeBillingPeriod("monthly")}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
                  upgradeBillingPeriod === "monthly"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setUpgradeBillingPeriod("annual")}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
                  upgradeBillingPeriod === "annual"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
              >
                Annual <span className="text-emerald-400 ml-1">Save 20%</span>
              </button>
            </div>

            {/* Plans */}
            <div className="space-y-3">
              {activePlans && activePlans.length > 0 ? (
                activePlans.map((plan: any) => {
                  const features = (() => { try { return JSON.parse(plan.features); } catch { return []; } })();
                  return (
                    <div
                      key={plan.id}
                      className={`relative rounded-xl border p-4 transition-all hover:border-primary/50 ${
                        plan.isPopular ? "border-primary bg-primary/5" : "border-border/50 bg-secondary/30"
                      }`}
                    >
                      {plan.isPopular === 1 && (
                        <span className="absolute -top-2.5 right-4 px-2 py-0.5 bg-primary text-primary-foreground text-[10px] font-bold uppercase rounded-full">
                          Popular
                        </span>
                      )}
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-heading font-bold text-foreground">{plan.name}</h4>
                          <p className="text-xs text-muted-foreground mt-0.5">{plan.description}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-primary">
                            {plan.priceMonthlyAED === 0 ? "Free" : `${plan.priceMonthlyAED} AED`}
                          </div>
                          {plan.priceMonthlyAED > 0 && (
                            <div className="text-[10px] text-muted-foreground">/month</div>
                          )}
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-xs">
                        <span className="flex items-center gap-1 text-primary font-medium">
                          <Search className="w-3 h-3" />
                          {plan.vinLimitPerMonth === -1 ? "Unlimited" : plan.vinLimitPerMonth} VIN lookups
                        </span>
                        {features.slice(0, 2).map((f: string, i: number) => (
                          <span key={i} className="flex items-center gap-1 text-muted-foreground">
                            <CheckCircle2 className="w-3 h-3 text-primary/60" />
                            {f}
                          </span>
                        ))}
                      </div>
                      {plan.priceMonthlyAED > 0 && (
                        <Button
                          onClick={() => handleSubscribe(plan.id)}
                          disabled={subscribingPlanId === plan.id}
                          className="w-full mt-3 bg-emerald-600 hover:bg-emerald-700 text-white"
                          size="sm"
                        >
                          {subscribingPlanId === plan.id ? (
                            <><Loader2 className="w-3 h-3 animate-spin mr-1" /> Processing...</>
                          ) : (
                            <>Subscribe — {upgradeBillingPeriod === "annual" ? plan.priceAnnualAED : plan.priceMonthlyAED} AED/{upgradeBillingPeriod === "annual" ? "year" : "month"}</>
                          )}
                        </Button>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2" />
                  Loading plans...
                </div>
              )}
            </div>

            <p className="text-xs text-muted-foreground text-center mt-4">
              Secure payment powered by Stripe. Test with card: 4242 4242 4242 4242
            </p>
            <Button
              onClick={() => setShowUpgradeDialog(false)}
              variant="outline"
              className="w-full mt-3"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
