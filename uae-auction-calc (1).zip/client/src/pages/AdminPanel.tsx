import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import {
  Plus,
  Trash2,
  Edit2,
  AlertCircle,
  CheckCircle,
  Clock,
  XCircle,
  ShieldCheck,
  UserCheck,
  UserX,
  BarChart3,
  Settings,
} from "lucide-react";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";

export default function AdminPanel() {
  const { user, loading, isAuthenticated } = useAuth({ redirectOnUnauthenticated: true });
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newDisplayName, setNewDisplayName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [message, setMessage] = useState("");

  // Use listAllAccounts instead of listAccounts to see all accounts including pending
  const { data: accounts = [], refetch } = trpc.accounts.listAllAccounts.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const createMutation = trpc.accounts.createAccount.useMutation({
    onSuccess: () => {
      setMessage("Account created successfully!");
      setNewUsername("");
      setNewPassword("");
      setNewDisplayName("");
      setNewEmail("");
      setShowCreateDialog(false);
      refetch();
      setTimeout(() => setMessage(""), 3000);
    },
    onError: (err) => {
      setMessage(`Error: ${err.message}`);
    },
  });

  const deleteMutation = trpc.accounts.deleteAccount.useMutation({
    onSuccess: () => {
      setMessage("Account deleted successfully!");
      refetch();
      setTimeout(() => setMessage(""), 3000);
    },
    onError: (err) => {
      setMessage(`Error: ${err.message}`);
    },
  });

  const statusMutation = trpc.accounts.updateAccountStatus.useMutation({
    onSuccess: (data) => {
      setMessage(`Account ${data.status === "approved" ? "approved" : "rejected"} successfully!`);
      refetch();
      setTimeout(() => setMessage(""), 3000);
    },
    onError: (err) => {
      setMessage(`Error: ${err.message}`);
    },
  });

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newPassword) {
      setMessage("Username and password are required");
      return;
    }
    createMutation.mutate({
      username: newUsername,
      password: newPassword,
      displayName: newDisplayName || undefined,
      email: newEmail || undefined,
    });
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="mb-4">Please login to access the admin panel</p>
          <Button onClick={() => (window.location.href = getLoginUrl())}>Login with Manus</Button>
        </div>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>You do not have permission to access the admin panel</AlertDescription>
        </Alert>
      </div>
    );
  }

  const pendingAccounts = accounts.filter((a) => a.status === "pending");
  const approvedAccounts = accounts.filter((a) => a.status === "approved");
  const rejectedAccounts = accounts.filter((a) => a.status === "rejected");

  const StatusBadge = ({ status }: { status: string }) => {
    const config = {
      pending: {
        icon: Clock,
        text: "Pending",
        className: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
      },
      approved: {
        icon: ShieldCheck,
        text: "Approved",
        className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
      },
      rejected: {
        icon: XCircle,
        text: "Rejected",
        className: "bg-red-500/10 text-red-400 border-red-500/30",
      },
    }[status] || { icon: Clock, text: status, className: "bg-gray-500/10 text-gray-400" };

    const Icon = config.icon;
    return (
      <span
        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${config.className}`}
      >
        <Icon className="w-3 h-3" />
        {config.text}
      </span>
    );
  };

  const AccountCard = ({
    account,
    showApproval,
  }: {
    account: (typeof accounts)[0];
    showApproval?: boolean;
  }) => (
    <Card key={account.id} className="glass-card border-border/40">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h3 className="font-semibold">{account.displayName || account.username}</h3>
              <StatusBadge status={account.status} />
            </div>
            <p className="text-sm text-muted-foreground">@{account.username}</p>
            {account.email && (
              <p className="text-sm text-muted-foreground">{account.email}</p>
            )}
            <p className="text-xs text-muted-foreground mt-2">
              {account.createdByUserId === 0 ? "Self-registered" : "Admin-created"}
              {" • "}
              {new Date(account.createdAt).toLocaleDateString()}
              {account.lastLoginAt && (
                <>
                  {" • Last login: "}
                  {new Date(account.lastLoginAt).toLocaleDateString()}
                </>
              )}
            </p>
          </div>
          <div className="flex gap-2">
            {showApproval && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/10"
                  onClick={() => statusMutation.mutate({ id: account.id, status: "approved" })}
                  disabled={statusMutation.isPending}
                >
                  <UserCheck className="w-4 h-4 mr-1" />
                  Approve
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-400 border-red-500/30 hover:bg-red-500/10"
                  onClick={() => statusMutation.mutate({ id: account.id, status: "rejected" })}
                  disabled={statusMutation.isPending}
                >
                  <UserX className="w-4 h-4 mr-1" />
                  Reject
                </Button>
              </>
            )}
            {!showApproval && account.status === "rejected" && (
              <Button
                variant="outline"
                size="sm"
                className="text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/10"
                onClick={() => statusMutation.mutate({ id: account.id, status: "approved" })}
                disabled={statusMutation.isPending}
              >
                <UserCheck className="w-4 h-4 mr-1" />
                Approve
              </Button>
            )}
            <Button
              variant="destructive"
              size="sm"
              onClick={() => deleteMutation.mutate({ id: account.id })}
              disabled={deleteMutation.isPending}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 pt-24 pb-12">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
            <p className="text-muted-foreground">Manage client accounts and access</p>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="outline" className="border-border/50">
                <BarChart3 className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/admin/settings">
              <Button variant="outline" className="border-border/50">
                <Settings className="w-4 h-4 mr-2" />
                Pricing Plans
              </Button>
            </Link>
          </div>
        </div>

        {message && (
          <Alert className={`mb-6 ${message.includes("Error") ? "variant-destructive" : ""}`}>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{message}</AlertDescription>
          </Alert>
        )}

        {/* Pending Approvals Section */}
        {pendingAccounts.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-yellow-400" />
              <h2 className="text-xl font-semibold">
                Pending Approvals ({pendingAccounts.length})
              </h2>
            </div>
            <div className="grid gap-3">
              {pendingAccounts.map((account) => (
                <AccountCard key={account.id} account={account} showApproval />
              ))}
            </div>
          </div>
        )}

        {/* Create Account Button */}
        <div className="mb-6 flex items-center gap-4">
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Create New Account
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-card border-border/40">
              <DialogHeader>
                <DialogTitle>Create Client Account</DialogTitle>
                <DialogDescription>
                  Create a new username/password account for a client
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleCreateAccount} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="username" className="text-sm font-medium">
                    Username *
                  </label>
                  <Input
                    id="username"
                    placeholder="client_username"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    disabled={createMutation.isPending}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="password" className="text-sm font-medium">
                    Password *
                  </label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="At least 6 characters"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={createMutation.isPending}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="displayName" className="text-sm font-medium">
                    Display Name
                  </label>
                  <Input
                    id="displayName"
                    placeholder="Optional display name"
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                    disabled={createMutation.isPending}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Optional email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    disabled={createMutation.isPending}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="submit"
                    className="flex-1 bg-primary hover:bg-primary/90"
                    disabled={createMutation.isPending}
                  >
                    {createMutation.isPending ? "Creating..." : "Create Account"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => setShowCreateDialog(false)}
                    disabled={createMutation.isPending}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          <div className="text-sm text-muted-foreground">
            {approvedAccounts.length} approved • {pendingAccounts.length} pending •{" "}
            {rejectedAccounts.length} rejected
          </div>
        </div>

        {/* Approved Accounts */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-semibold">Active Accounts ({approvedAccounts.length})</h2>
          </div>
          <div className="grid gap-3">
            {approvedAccounts.length === 0 ? (
              <Card className="glass-card border-border/40">
                <CardContent className="pt-6 text-center text-muted-foreground">
                  No approved accounts yet. Create one or approve a pending registration.
                </CardContent>
              </Card>
            ) : (
              approvedAccounts.map((account) => (
                <AccountCard key={account.id} account={account} />
              ))
            )}
          </div>
        </div>

        {/* Rejected Accounts */}
        {rejectedAccounts.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <XCircle className="w-5 h-5 text-red-400" />
              <h2 className="text-xl font-semibold">
                Rejected Accounts ({rejectedAccounts.length})
              </h2>
            </div>
            <div className="grid gap-3">
              {rejectedAccounts.map((account) => (
                <AccountCard key={account.id} account={account} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
