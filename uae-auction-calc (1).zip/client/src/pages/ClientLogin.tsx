import { useState, useEffect, useCallback } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { trpc } from "@/lib/trpc";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Calculator,
  Eye,
  EyeOff,
  Sparkles,
  Phone,
  KeyRound,
  ShieldCheck,
  Timer,
  ArrowRight,
} from "lucide-react";

type Tab = "login" | "register" | "forgot";
type RegisterStep = "phone" | "otp" | "details";
type ForgotStep = "phone" | "otp" | "done";

export default function ClientLogin() {
  const [tab, setTab] = useState<Tab>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Registration fields
  const [regStep, setRegStep] = useState<RegisterStep>("phone");
  const [regPhone, setRegPhone] = useState("");
  const [regOtp, setRegOtp] = useState("");
  const [regDevOtp, setRegDevOtp] = useState("");
  const [regName, setRegName] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);

  // OTP cooldown timer
  const [otpCooldown, setOtpCooldown] = useState(0);

  // Forgot password fields
  const [forgotPhone, setForgotPhone] = useState("");
  const [forgotOtp, setForgotOtp] = useState("");
  const [forgotNewPassword, setForgotNewPassword] = useState("");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotStep, setForgotStep] = useState<ForgotStep>("phone");
  const [devOtp, setDevOtp] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [, setLocation] = useLocation();

  // Cooldown timer effect
  useEffect(() => {
    if (otpCooldown <= 0) return;
    const timer = setInterval(() => {
      setOtpCooldown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [otpCooldown]);

  const loginMutation = trpc.accounts.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("clientSession", JSON.stringify(data));
      const params = new URLSearchParams(window.location.search);
      const redirectParam = params.get("redirect");
      const redirectTo = data.role === "admin" ? "/admin" : (redirectParam || "/calculator");
      setLocation(redirectTo);
    },
    onError: (err) => {
      setError(err.message || "Login failed");
    },
  });

  const sendOtpMutation = trpc.accounts.sendRegistrationOtp.useMutation({
    onSuccess: (data) => {
      setSuccess(data.message);
      setError("");
      setRegStep("otp");
      setOtpCooldown(60);
      if (data._devOtp) {
        setRegDevOtp(data._devOtp);
      }
    },
    onError: (err) => {
      setError(err.message || "Failed to send verification code");
      setSuccess("");
    },
  });

  const verifyOtpMutation = trpc.accounts.verifyRegistrationOtp.useMutation({
    onSuccess: (data) => {
      setSuccess(data.message);
      setError("");
      setPhoneVerified(true);
      setRegStep("details");
      setRegDevOtp("");
    },
    onError: (err) => {
      setError(err.message || "Verification failed");
      setSuccess("");
    },
  });

  const registerMutation = trpc.accounts.register.useMutation({
    onSuccess: (data) => {
      setSuccess(data.message || "Account created successfully! You can now log in.");
      setError("");
      // Auto-switch to login after 2 seconds
      setTimeout(() => {
        switchTab("login");
        setSuccess("Account created! Please log in.");
      }, 2000);
    },
    onError: (err) => {
      setError(err.message || "Registration failed");
      setSuccess("");
    },
  });

  const requestResetMutation = trpc.accounts.requestPasswordReset.useMutation({
    onSuccess: (data) => {
      setSuccess("Reset code generated! Enter it below.");
      setError("");
      setForgotStep("otp");
      if (data._devOtp) {
        setDevOtp(data._devOtp);
      }
    },
    onError: (err) => {
      setError(err.message || "Failed to request reset");
      setSuccess("");
    },
  });

  const resetPasswordMutation = trpc.accounts.resetPassword.useMutation({
    onSuccess: () => {
      setSuccess("Password reset successfully! You can now log in with your new password.");
      setError("");
      setForgotStep("done");
    },
    onError: (err) => {
      setError(err.message || "Failed to reset password");
      setSuccess("");
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!username || !password) {
      setError("Please enter phone number/username and password");
      return;
    }
    loginMutation.mutate({ username, password });
  };

  const handleSendOtp = useCallback(
    (e?: React.FormEvent) => {
      e?.preventDefault();
      setError("");
      setSuccess("");
      if (!regPhone) {
        setError("Please enter your phone number");
        return;
      }
      const cleaned = regPhone.replace(/[\s\-\(\)]/g, "");
      const isValid = /^(\+?971|0)5[0-9]\d{7}$/.test(cleaned);
      if (!isValid) {
        setError("Please enter a valid UAE phone number (e.g., 0501234567 or +971501234567)");
        return;
      }
      sendOtpMutation.mutate({ phoneNumber: regPhone });
    },
    [regPhone, sendOtpMutation]
  );

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!regOtp || regOtp.length !== 6) {
      setError("Please enter the 6-digit verification code");
      return;
    }
    verifyOtpMutation.mutate({ phoneNumber: regPhone, otp: regOtp });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!regName || !regPassword) {
      setError("Please fill in all fields");
      return;
    }
    if (regPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    registerMutation.mutate({ phoneNumber: regPhone, displayName: regName, password: regPassword });
  };

  const handleRequestReset = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!forgotPhone) {
      setError("Please enter your phone number");
      return;
    }
    const cleaned = forgotPhone.replace(/[\s\-\(\)]/g, "");
    const isValid = /^(\+?971|0)5[0-9]\d{7}$/.test(cleaned);
    if (!isValid) {
      setError("Please enter a valid UAE phone number");
      return;
    }
    requestResetMutation.mutate({ phoneNumber: forgotPhone });
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!forgotOtp || !forgotNewPassword) {
      setError("Please enter the reset code and new password");
      return;
    }
    if (forgotOtp.length !== 6) {
      setError("Reset code must be 6 digits");
      return;
    }
    if (forgotNewPassword.length < 6) {
      setError("New password must be at least 6 characters");
      return;
    }
    resetPasswordMutation.mutate({
      phoneNumber: forgotPhone,
      otp: forgotOtp,
      newPassword: forgotNewPassword,
    });
  };

  const switchTab = (newTab: Tab) => {
    setTab(newTab);
    setError("");
    setSuccess("");
    if (newTab === "register") {
      setRegStep("phone");
      setRegPhone("");
      setRegOtp("");
      setRegDevOtp("");
      setRegName("");
      setRegPassword("");
      setPhoneVerified(false);
      setOtpCooldown(0);
    }
    if (newTab === "forgot") {
      setForgotStep("phone");
      setForgotPhone("");
      setForgotOtp("");
      setForgotNewPassword("");
      setDevOtp("");
    }
  };

  // Step indicator for registration
  const RegStepIndicator = () => {
    const steps = [
      { key: "phone", label: "Phone", num: 1 },
      { key: "otp", label: "Verify", num: 2 },
      { key: "details", label: "Details", num: 3 },
    ];
    const currentIdx = steps.findIndex((s) => s.key === regStep);

    return (
      <div className="flex items-center justify-center gap-2 mb-6">
        {steps.map((step, idx) => (
          <div key={step.key} className="flex items-center gap-2">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                idx < currentIdx
                  ? "bg-primary text-primary-foreground"
                  : idx === currentIdx
                    ? "bg-primary text-primary-foreground ring-2 ring-primary/30 ring-offset-2 ring-offset-card"
                    : "bg-secondary text-muted-foreground"
              }`}
            >
              {idx < currentIdx ? <Check className="w-3.5 h-3.5" /> : step.num}
            </div>
            <span
              className={`text-xs font-medium hidden sm:inline ${
                idx <= currentIdx ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {step.label}
            </span>
            {idx < steps.length - 1 && (
              <div
                className={`w-8 h-0.5 rounded-full transition-colors ${
                  idx < currentIdx ? "bg-primary" : "bg-secondary"
                }`}
              />
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/3 rounded-full blur-3xl" />
      </div>

      {/* Logo + Back */}
      <div className="relative z-10 mb-8">
        <Link href="/" className="inline-flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center group-hover:bg-primary/25 transition-colors">
            <Calculator className="w-5 h-5 text-primary" />
          </div>
          <div>
            <span className="font-heading font-bold text-xl text-foreground">
              <span className="text-primary">Smart Calculator</span>
            </span>
            <p className="text-xs text-muted-foreground -mt-0.5">USA AUCTION → UAE IMPORT</p>
          </div>
        </Link>
      </div>

      {/* Card */}
      <div className="relative z-10 w-full max-w-md">
        <div className="rounded-2xl border border-border/50 bg-card shadow-2xl shadow-black/20 overflow-hidden">
          {/* Tab toggle — only show login/register when not in forgot mode */}
          {tab !== "forgot" ? (
            <div className="px-8 pt-8 pb-2">
              <div className="flex rounded-xl bg-secondary p-1">
                <button
                  onClick={() => switchTab("login")}
                  className={`flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all duration-200 ${
                    tab === "login"
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Login
                </button>
                <button
                  onClick={() => switchTab("register")}
                  className={`flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all duration-200 ${
                    tab === "register"
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Create Account
                </button>
              </div>
            </div>
          ) : (
            <div className="px-8 pt-8 pb-2">
              <button
                onClick={() => switchTab("login")}
                className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Login
              </button>
            </div>
          )}

          <div className="px-8 pb-8 pt-4">
            {/* Login Tab */}
            {tab === "login" && (
              <>
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-heading font-bold text-foreground">Welcome Back</h2>
                  <p className="text-muted-foreground text-sm mt-1">
                    Enter your phone number and password to continue
                  </p>
                </div>

                {error && (
                  <Alert variant="destructive" className="mb-4 bg-destructive/10 border-destructive/30">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleLogin} className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Phone Number / Username
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                      <Input
                        type="text"
                        placeholder="+971501234567"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        disabled={loginMutation.isPending}
                        className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Password
                    </label>
                    <div className="relative">
                      <Input
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        disabled={loginMutation.isPending}
                        className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Logging in..." : "Login"}
                  </Button>
                </form>

                {/* Forgot password link */}
                <div className="mt-4 text-center">
                  <button
                    onClick={() => switchTab("forgot")}
                    className="text-sm text-primary hover:text-primary/80 transition-colors font-medium"
                  >
                    Forgot Password?
                  </button>
                </div>
              </>
            )}

            {/* Register Tab — Multi-Step with OTP */}
            {tab === "register" && (
              <>
                <RegStepIndicator />

                {error && (
                  <Alert variant="destructive" className="mb-4 bg-destructive/10 border-destructive/30">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="mb-4 bg-primary/10 border-primary/30 text-primary">
                    <Check className="h-4 w-4" />
                    <AlertDescription>{success}</AlertDescription>
                  </Alert>
                )}

                {/* Step 1: Enter Phone Number */}
                {regStep === "phone" && (
                  <>
                    <div className="text-center mb-6">
                      <h2 className="text-2xl font-heading font-bold text-foreground">Verify Your Phone</h2>
                      <p className="text-muted-foreground text-sm mt-1">
                        We'll send a verification code to your UAE number
                      </p>
                    </div>

                    <form onSubmit={handleSendOtp} className="space-y-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          UAE Phone Number *
                        </label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                          <Input
                            type="tel"
                            placeholder="0501234567 or +971501234567"
                            value={regPhone}
                            onChange={(e) => setRegPhone(e.target.value)}
                            disabled={sendOtpMutation.isPending}
                            className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pl-10"
                            autoFocus
                          />
                        </div>
                        <p className="text-xs text-muted-foreground/60">
                          Valid UAE mobile number required. Each number can register once.
                        </p>
                      </div>

                      <Button
                        type="submit"
                        className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                        disabled={sendOtpMutation.isPending}
                      >
                        {sendOtpMutation.isPending ? (
                          "Sending Code..."
                        ) : (
                          <span className="inline-flex items-center gap-2">
                            Send Verification Code <ArrowRight className="w-4 h-4" />
                          </span>
                        )}
                      </Button>
                    </form>
                  </>
                )}

                {/* Step 2: Enter OTP Code */}
                {regStep === "otp" && (
                  <>
                    <div className="text-center mb-6">
                      <div className="w-14 h-14 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto mb-4">
                        <ShieldCheck className="w-7 h-7 text-primary" />
                      </div>
                      <h2 className="text-2xl font-heading font-bold text-foreground">Enter Code</h2>
                      <p className="text-muted-foreground text-sm mt-1">
                        A 6-digit code was sent to <span className="text-foreground font-medium">{regPhone}</span>
                      </p>
                    </div>

                    {/* Dev mode OTP display */}
                    {regDevOtp && (
                      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-3 text-center mb-4">
                        <p className="text-xs text-amber-400 font-medium mb-1">Development Mode — Your Code:</p>
                        <p className="text-2xl font-mono font-bold text-amber-300 tracking-[0.3em]">{regDevOtp}</p>
                        <p className="text-xs text-amber-400/70 mt-1">In production, this code is sent via SMS</p>
                      </div>
                    )}

                    <form onSubmit={handleVerifyOtp} className="space-y-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          6-Digit Verification Code
                        </label>
                        <div className="relative">
                          <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                          <Input
                            type="text"
                            placeholder="000000"
                            maxLength={6}
                            value={regOtp}
                            onChange={(e) => setRegOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                            disabled={verifyOtpMutation.isPending}
                            className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pl-10 text-center text-lg tracking-[0.3em] font-mono"
                            autoFocus
                          />
                        </div>
                      </div>

                      <Button
                        type="submit"
                        className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                        disabled={verifyOtpMutation.isPending}
                      >
                        {verifyOtpMutation.isPending ? (
                          "Verifying..."
                        ) : (
                          <span className="inline-flex items-center gap-2">
                            Verify Code <ArrowRight className="w-4 h-4" />
                          </span>
                        )}
                      </Button>

                      {/* Resend / Change number */}
                      <div className="flex items-center justify-between text-sm">
                        <button
                          type="button"
                          onClick={() => {
                            setRegStep("phone");
                            setRegOtp("");
                            setRegDevOtp("");
                            setError("");
                            setSuccess("");
                          }}
                          className="text-muted-foreground hover:text-foreground transition-colors"
                        >
                          Change number
                        </button>

                        {otpCooldown > 0 ? (
                          <span className="text-muted-foreground inline-flex items-center gap-1.5">
                            <Timer className="w-3.5 h-3.5" />
                            Resend in {otpCooldown}s
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSendOtp()}
                            disabled={sendOtpMutation.isPending}
                            className="text-primary hover:text-primary/80 transition-colors font-medium"
                          >
                            Resend Code
                          </button>
                        )}
                      </div>
                    </form>
                  </>
                )}

                {/* Step 3: Complete Registration Details */}
                {regStep === "details" && (
                  <>
                    <div className="text-center mb-6">
                      <h2 className="text-2xl font-heading font-bold text-foreground">Complete Registration</h2>
                      <p className="text-muted-foreground text-sm mt-1">
                        Phone verified! Enter your name and password.
                      </p>
                    </div>

                    {/* Verified phone badge */}
                    <div className="rounded-xl bg-primary/10 border border-primary/30 p-3 flex items-center gap-3 mb-5">
                      <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                        <Check className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-primary font-medium">Phone Verified</p>
                        <p className="text-sm text-foreground font-mono">{regPhone}</p>
                      </div>
                    </div>

                    <form onSubmit={handleRegister} className="space-y-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          Full Name *
                        </label>
                        <Input
                          type="text"
                          placeholder="e.g., Ahmed Al Mansouri"
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          disabled={registerMutation.isPending}
                          className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20"
                          autoFocus
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          Password *
                        </label>
                        <div className="relative">
                          <Input
                            type={showRegPassword ? "text" : "password"}
                            placeholder="Min 6 characters"
                            value={regPassword}
                            onChange={(e) => setRegPassword(e.target.value)}
                            disabled={registerMutation.isPending}
                            className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pr-12"
                          />
                          <button
                            type="button"
                            onClick={() => setShowRegPassword(!showRegPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {showRegPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </div>

                      <Button
                        type="submit"
                        className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                      </Button>
                    </form>

                    <div className="mt-5 pt-4 border-t border-border/50 space-y-3">
                      <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                        <Sparkles className="w-3.5 h-3.5 text-primary" />
                        <span>New accounts include 3 free VIN evaluations. Subscribe to unlock more.</span>
                      </div>
                      <p className="text-xs text-muted-foreground/70 text-center">
                        By creating an account, you agree to our{" "}
                        <a href="#" className="text-primary hover:text-primary/80 transition-colors">
                          Terms of Service
                        </a>{" "}
                        and{" "}
                        <a href="#" className="text-primary hover:text-primary/80 transition-colors">
                          Refund Policy
                        </a>
                        .
                      </p>
                    </div>
                  </>
                )}
              </>
            )}

            {/* Forgot Password Tab */}
            {tab === "forgot" && (
              <>
                <div className="text-center mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto mb-4">
                    <KeyRound className="w-7 h-7 text-primary" />
                  </div>
                  <h2 className="text-2xl font-heading font-bold text-foreground">Reset Password</h2>
                  <p className="text-muted-foreground text-sm mt-1">
                    {forgotStep === "phone" && "Enter your registered UAE phone number"}
                    {forgotStep === "otp" && "Enter the 6-digit reset code and your new password"}
                    {forgotStep === "done" && "Your password has been reset"}
                  </p>
                </div>

                {error && (
                  <Alert variant="destructive" className="mb-4 bg-destructive/10 border-destructive/30">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="mb-4 bg-primary/10 border-primary/30 text-primary">
                    <Check className="h-4 w-4" />
                    <AlertDescription>{success}</AlertDescription>
                  </Alert>
                )}

                {/* Step 1: Enter phone number */}
                {forgotStep === "phone" && (
                  <form onSubmit={handleRequestReset} className="space-y-5">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        UAE Phone Number
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                        <Input
                          type="tel"
                          placeholder="0501234567 or +971501234567"
                          value={forgotPhone}
                          onChange={(e) => setForgotPhone(e.target.value)}
                          disabled={requestResetMutation.isPending}
                          className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pl-10"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground/60">
                        Enter the phone number you used to register your account.
                      </p>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                      disabled={requestResetMutation.isPending}
                    >
                      {requestResetMutation.isPending ? "Sending..." : "Send Reset Code"}
                    </Button>
                  </form>
                )}

                {/* Step 2: Enter OTP + new password */}
                {forgotStep === "otp" && (
                  <form onSubmit={handleResetPassword} className="space-y-5">
                    {/* Dev mode OTP display */}
                    {devOtp && (
                      <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-3 text-center">
                        <p className="text-xs text-amber-400 font-medium mb-1">Development Mode — Reset Code:</p>
                        <p className="text-2xl font-mono font-bold text-amber-300 tracking-[0.3em]">{devOtp}</p>
                        <p className="text-xs text-amber-400/70 mt-1">In production, this code would be sent via SMS</p>
                      </div>
                    )}

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        6-Digit Reset Code
                      </label>
                      <div className="relative">
                        <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                        <Input
                          type="text"
                          placeholder="123456"
                          maxLength={6}
                          value={forgotOtp}
                          onChange={(e) => setForgotOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                          disabled={resetPasswordMutation.isPending}
                          className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pl-10 text-center text-lg tracking-[0.3em] font-mono"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        New Password
                      </label>
                      <div className="relative">
                        <Input
                          type={showForgotPassword ? "text" : "password"}
                          placeholder="Min 6 characters"
                          value={forgotNewPassword}
                          onChange={(e) => setForgotNewPassword(e.target.value)}
                          disabled={resetPasswordMutation.isPending}
                          className="bg-secondary border-border text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl focus:border-primary focus:ring-primary/20 pr-12"
                        />
                        <button
                          type="button"
                          onClick={() => setShowForgotPassword(!showForgotPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showForgotPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                      disabled={resetPasswordMutation.isPending}
                    >
                      {resetPasswordMutation.isPending ? "Resetting..." : "Reset Password"}
                    </Button>

                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => {
                          setForgotStep("phone");
                          setError("");
                          setSuccess("");
                          setDevOtp("");
                        }}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Didn't receive a code? Try again
                      </button>
                    </div>
                  </form>
                )}

                {/* Step 3: Done */}
                {forgotStep === "done" && (
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto">
                      <Check className="w-8 h-8 text-primary" />
                    </div>
                    <Button
                      onClick={() => switchTab("login")}
                      className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all duration-200"
                    >
                      Go to Login
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Back to home link */}
        <div className="mt-6 text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
