import { useLanguage } from "@/contexts/LanguageContext";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight, Loader2, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import PublicNavbar from "@/components/PublicNavbar";

export default function Pricing() {
  const { t, isRTL } = useLanguage();
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly");

  const { data: plans, isLoading } = trpc.admin.getActivePlans.useQuery();

  return (
    <div className="min-h-screen bg-background">
      <PublicNavbar />
      {/* Header */}
      <div className="pt-32 pb-16 border-b border-border/50 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6">
              {t("pricing.title") || "Simple, Transparent Pricing"}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              {t("pricing.subtitle") ||
                "Choose the plan that fits your needs. Cancel anytime, no hidden fees."}
            </p>

            {/* Billing Toggle */}
            <div className="inline-flex items-center gap-4 p-1 rounded-lg bg-card border border-border/50">
              <button
                onClick={() => setBillingCycle("monthly")}
                className={`px-6 py-2 rounded-md font-medium transition-all ${
                  billingCycle === "monthly"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t("pricing.monthly") || "Monthly"}
              </button>
              <button
                onClick={() => setBillingCycle("annual")}
                className={`px-6 py-2 rounded-md font-medium transition-all ${
                  billingCycle === "annual"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t("pricing.annual") || "Annual"}
                <span className="ml-2 text-xs bg-green-500/20 text-green-500 px-2 py-1 rounded">
                  {t("pricing.save") || "Save 17%"}
                </span>
              </button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="container py-20">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !plans || plans.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <p>No pricing plans available yet. Check back soon!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => {
              const features = typeof plan.features === "string"
                ? JSON.parse(plan.features)
                : plan.features;
              const featureList = Array.isArray(features) ? features : [];
              const isPopular = plan.isPopular === 1;
              const isCustom = plan.priceMonthlyAED === 0 && plan.name.toLowerCase().includes("enterprise");
              const price = billingCycle === "monthly"
                ? plan.priceMonthlyAED
                : plan.priceAnnualAED;

              return (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`relative rounded-lg border transition-all ${
                    isPopular
                      ? "border-primary/50 bg-primary/5 shadow-lg"
                      : "border-border/50 bg-card/50 hover:border-primary/30"
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-primary text-primary-foreground text-sm font-semibold flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5" />
                      {t("pricing.popular") || "Most Popular"}
                    </div>
                  )}

                  <div className="p-8">
                    {/* Plan Name */}
                    <h3 className="text-2xl font-heading font-bold mb-2">
                      {plan.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-6">
                      {plan.description || ""}
                    </p>

                    {/* Price */}
                    <div className="mb-6">
                      {isCustom ? (
                        <>
                          <div className="text-4xl font-heading font-bold">
                            Custom
                          </div>
                          <div className="text-muted-foreground text-sm">
                            Contact us
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-4xl font-heading font-bold">
                            {price.toLocaleString()} AED
                          </div>
                          <div className="text-muted-foreground text-sm">
                            /{billingCycle === "monthly" ? "month" : "year"}
                            {plan.vinLimitPerMonth > 0 && (
                              <span className="ml-2 text-primary">
                                • {plan.vinLimitPerMonth} VIN lookups/mo
                              </span>
                            )}
                            {plan.vinLimitPerMonth === -1 && (
                              <span className="ml-2 text-primary">
                                • Unlimited VIN lookups
                              </span>
                            )}
                          </div>
                        </>
                      )}
                    </div>

                    {/* CTA Button */}
                    <Link href="/login" className="block mb-8">
                      <Button
                        className="w-full gap-2"
                        variant={isPopular ? "default" : "outline"}
                      >
                        {isCustom
                          ? (t("pricing.contact") || "Contact Sales")
                          : (t("pricing.cta") || "Get Started")}
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </Link>

                    {/* Features */}
                    <div className="space-y-4">
                      {featureList.map((feature: string, i: number) => (
                        <div key={i} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAQ Section */}
      <section className="py-20 bg-primary/5 border-y border-border/50">
        <div className="container">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-heading font-bold mb-4">
              {t("pricing.faq.title") || "Frequently Asked Questions"}
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                q: t("pricing.faq.q1") || "Can I change my plan anytime?",
                a: t("pricing.faq.a1") ||
                  "Yes! Upgrade or downgrade your plan at any time. Changes take effect immediately.",
              },
              {
                q: t("pricing.faq.q2") || "Do you offer refunds?",
                a: t("pricing.faq.a2") ||
                  "We offer a 14-day money-back guarantee if you're not satisfied.",
              },
              {
                q: t("pricing.faq.q3") || "What payment methods do you accept?",
                a: t("pricing.faq.a3") ||
                  "We accept all major credit cards, bank transfers, and digital wallets.",
              },
              {
                q: t("pricing.faq.q4") || "Is there a free trial?",
                a: t("pricing.faq.a4") ||
                  "Yes! New users get 1 free VIN evaluation to try the calculator.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <h4 className="font-semibold mb-2 text-foreground">
                  {item.q}
                </h4>
                <p className="text-muted-foreground text-sm">{item.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-heading font-bold mb-6">
              {t("pricing.cta.title") || "Start Calculating Today"}
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              {t("pricing.cta.subtitle") ||
                "Join hundreds of successful importers using AuctionCalc to make smarter bidding decisions."}
            </p>
            <Link href="/login">
              <Button size="lg" className="gap-2">
                {t("pricing.cta.button") || "Get Started Free"}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
