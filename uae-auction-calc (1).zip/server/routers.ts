import { COOKIE_NAME, CLIENT_COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { clientRouter } from "./clientRouter";
import { auctionRouter } from "./auctionRouter";
import { damageAnalysisRouter } from "./damageAnalysisRouter";
import { dealQueueRouter } from "./dealQueueRouter";
import { pdfExportRouter } from "./pdfExportRouter";
import { adminRouter } from "./adminRouter";
import { directoryRouter } from "./directoryRouter";
import { siteConfigRouter } from "./siteConfigRouter";
import { stripeRouter } from "./stripe/stripeRouter";
import { vehicleModelsRouter } from "./vehicleModelsRouter";

export const appRouter = router({
  system: systemRouter,
  accounts: clientRouter,
  auction: auctionRouter,
  damageAnalysis: damageAnalysisRouter,
  dealQueue: dealQueueRouter,
  pdfExport: pdfExportRouter,
  admin: adminRouter,
  directory: directoryRouter,
  siteConfig: siteConfigRouter,
  stripe: stripeRouter,
  vehicleModels: vehicleModelsRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      // Clear both Manus OAuth and client session cookies
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(CLIENT_COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
