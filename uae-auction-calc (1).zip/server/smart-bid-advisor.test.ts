/**
 * Smart Bid Advisor — Reverse Calculation Tests
 * Tests the logic that calculates maximum bid amount for a given profit target
 */
import { describe, it, expect } from "vitest";

// Import the fee calculation functions used by the bid advisor
import {
  getCopartTotalFees,
  getIAAITotalFees,
  calculateUAEImportTax,
  USD_TO_AED,
} from "../client/src/lib/auctionData";

/**
 * Replicate the binary search logic from Calculator.tsx
 * This is the same algorithm used in the frontend
 */
function calculateMaxBid(params: {
  uaeMarketPrice: number;
  shippingCostAED: number;
  partsTotal: number;
  selectedRepairCostAED: number;
  registrationTotal: number;
  auctionHouse: "copart" | "iaai";
  targetProfitAED: number;
}): { maxBidUSD: number; maxBidAED: number; totalCostAED: number; feasible: boolean } {
  const {
    uaeMarketPrice,
    shippingCostAED,
    partsTotal,
    selectedRepairCostAED,
    registrationTotal,
    auctionHouse,
    targetProfitAED,
  } = params;

  if (uaeMarketPrice <= 0) return { maxBidUSD: 0, maxBidAED: 0, totalCostAED: 0, feasible: false };

  const fixedCostsAED = shippingCostAED + partsTotal + selectedRepairCostAED + registrationTotal;
  const availableForBidAED = uaeMarketPrice - fixedCostsAED - targetProfitAED;

  if (availableForBidAED <= 0) return { maxBidUSD: 0, maxBidAED: 0, totalCostAED: 0, feasible: false };

  let lo = 0;
  let hi = availableForBidAED / USD_TO_AED;
  let bestBid = 0;

  for (let i = 0; i < 50; i++) {
    const mid = (lo + hi) / 2;
    const fees = auctionHouse === "copart" ? getCopartTotalFees(mid) : getIAAITotalFees(mid);
    const bidPlusFees = mid + fees.total;
    const bidPlusFeesAED = bidPlusFees * USD_TO_AED;
    const tax = calculateUAEImportTax(bidPlusFeesAED);
    const totalCost = bidPlusFeesAED + shippingCostAED + tax.total + partsTotal + selectedRepairCostAED + registrationTotal;
    const profit = uaeMarketPrice - totalCost;

    if (profit >= targetProfitAED) {
      bestBid = mid;
      lo = mid;
    } else {
      hi = mid;
    }
  }

  const finalFees = auctionHouse === "copart" ? getCopartTotalFees(bestBid) : getIAAITotalFees(bestBid);
  const finalBidPlusFeesAED = (bestBid + finalFees.total) * USD_TO_AED;
  const finalTax = calculateUAEImportTax(finalBidPlusFeesAED);
  const finalTotalCost = finalBidPlusFeesAED + shippingCostAED + finalTax.total + partsTotal + selectedRepairCostAED + registrationTotal;

  return {
    maxBidUSD: Math.floor(bestBid),
    maxBidAED: Math.floor(bestBid * USD_TO_AED),
    totalCostAED: Math.round(finalTotalCost),
    feasible: bestBid > 0,
  };
}

/** Helper: forward-calculate total cost from a bid */
function forwardCalculate(bidUSD: number, shippingCostAED: number, partsTotal: number, repairCost: number, regTotal: number, auctionHouse: "copart" | "iaai") {
  const fees = auctionHouse === "copart" ? getCopartTotalFees(bidUSD) : getIAAITotalFees(bidUSD);
  const bidPlusFeesAED = (bidUSD + fees.total) * USD_TO_AED;
  const tax = calculateUAEImportTax(bidPlusFeesAED);
  return bidPlusFeesAED + shippingCostAED + tax.total + partsTotal + repairCost + regTotal;
}

describe("Smart Bid Advisor — Reverse Calculation", () => {
  const baseParams = {
    uaeMarketPrice: 85000,
    shippingCostAED: 5500,
    partsTotal: 3000,
    selectedRepairCostAED: 2000,
    registrationTotal: 950,
    auctionHouse: "copart" as const,
  };

  it("should return feasible result for reasonable profit target", () => {
    const result = calculateMaxBid({ ...baseParams, targetProfitAED: 5000 });
    expect(result.feasible).toBe(true);
    expect(result.maxBidUSD).toBeGreaterThan(0);
    expect(result.maxBidAED).toBeGreaterThan(0);
    expect(result.totalCostAED).toBeGreaterThan(0);
  });

  it("should return higher max bid for lower profit target", () => {
    const low = calculateMaxBid({ ...baseParams, targetProfitAED: 5000 });
    const high = calculateMaxBid({ ...baseParams, targetProfitAED: 15000 });
    expect(low.maxBidUSD).toBeGreaterThan(high.maxBidUSD);
  });

  it("should return not feasible when profit target exceeds available budget", () => {
    const result = calculateMaxBid({ ...baseParams, targetProfitAED: 80000 });
    expect(result.feasible).toBe(false);
    expect(result.maxBidUSD).toBe(0);
  });

  it("should return not feasible when market price is 0", () => {
    const result = calculateMaxBid({ ...baseParams, uaeMarketPrice: 0, targetProfitAED: 5000 });
    expect(result.feasible).toBe(false);
  });

  it("should produce correct profit when forward-calculated", () => {
    const target = 5000;
    const result = calculateMaxBid({ ...baseParams, targetProfitAED: target });
    expect(result.feasible).toBe(true);

    // Forward-calculate with the recommended bid
    const totalCost = forwardCalculate(
      result.maxBidUSD,
      baseParams.shippingCostAED,
      baseParams.partsTotal,
      baseParams.selectedRepairCostAED,
      baseParams.registrationTotal,
      baseParams.auctionHouse,
    );
    const actualProfit = baseParams.uaeMarketPrice - totalCost;

    // Profit should be >= target (binary search finds the max bid, so profit should be close to target)
    expect(actualProfit).toBeGreaterThanOrEqual(target - 100); // Allow small rounding tolerance
  });

  it("should work with IAAI auction house", () => {
    const result = calculateMaxBid({
      ...baseParams,
      auctionHouse: "iaai",
      targetProfitAED: 7000,
    });
    expect(result.feasible).toBe(true);
    expect(result.maxBidUSD).toBeGreaterThan(0);
  });

  it("should handle zero fixed costs", () => {
    const result = calculateMaxBid({
      uaeMarketPrice: 50000,
      shippingCostAED: 0,
      partsTotal: 0,
      selectedRepairCostAED: 0,
      registrationTotal: 0,
      auctionHouse: "copart",
      targetProfitAED: 5000,
    });
    expect(result.feasible).toBe(true);
    expect(result.maxBidUSD).toBeGreaterThan(0);
  });

  it("should decrease max bid when shipping cost increases", () => {
    const lowShipping = calculateMaxBid({
      ...baseParams,
      shippingCostAED: 3000,
      targetProfitAED: 5000,
    });
    const highShipping = calculateMaxBid({
      ...baseParams,
      shippingCostAED: 10000,
      targetProfitAED: 5000,
    });
    expect(lowShipping.maxBidUSD).toBeGreaterThan(highShipping.maxBidUSD);
  });

  it("should decrease max bid when repair costs increase", () => {
    const lowRepair = calculateMaxBid({
      ...baseParams,
      selectedRepairCostAED: 1000,
      targetProfitAED: 5000,
    });
    const highRepair = calculateMaxBid({
      ...baseParams,
      selectedRepairCostAED: 15000,
      targetProfitAED: 5000,
    });
    expect(lowRepair.maxBidUSD).toBeGreaterThan(highRepair.maxBidUSD);
  });

  it("should increase max bid when market price increases", () => {
    const lowMarket = calculateMaxBid({
      ...baseParams,
      uaeMarketPrice: 60000,
      targetProfitAED: 5000,
    });
    const highMarket = calculateMaxBid({
      ...baseParams,
      uaeMarketPrice: 120000,
      targetProfitAED: 5000,
    });
    expect(highMarket.maxBidUSD).toBeGreaterThan(lowMarket.maxBidUSD);
  });

  it("should handle all 4 preset profit targets", () => {
    const targets = [5000, 7000, 10000, 15000];
    const results = targets.map((t) => calculateMaxBid({ ...baseParams, targetProfitAED: t }));

    // All should be feasible for an 85k market price car
    results.forEach((r) => expect(r.feasible).toBe(true));

    // Max bid should decrease as profit target increases
    for (let i = 1; i < results.length; i++) {
      expect(results[i - 1].maxBidUSD).toBeGreaterThan(results[i].maxBidUSD);
    }
  });

  it("should handle custom profit target", () => {
    const result = calculateMaxBid({ ...baseParams, targetProfitAED: 8500 });
    expect(result.feasible).toBe(true);

    // Should be between 7000 and 10000 target results
    const r7k = calculateMaxBid({ ...baseParams, targetProfitAED: 7000 });
    const r10k = calculateMaxBid({ ...baseParams, targetProfitAED: 10000 });
    expect(result.maxBidUSD).toBeLessThan(r7k.maxBidUSD);
    expect(result.maxBidUSD).toBeGreaterThan(r10k.maxBidUSD);
  });

  it("maxBidAED should equal maxBidUSD * USD_TO_AED (floored)", () => {
    const result = calculateMaxBid({ ...baseParams, targetProfitAED: 5000 });
    expect(result.maxBidAED).toBe(Math.floor(result.maxBidUSD * USD_TO_AED));
  });
});
