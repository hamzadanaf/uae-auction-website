import { eq } from "drizzle-orm";
import { ClientAccount, InsertClientAccount, clientAccounts } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Create a new client account with hashed password
 */
export async function createClientAccount(
  data: Omit<InsertClientAccount, "id" | "createdAt" | "updatedAt">
): Promise<ClientAccount> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(clientAccounts).values(data);
  const accountId = result[0].insertId;

  const account = await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.id, accountId as number))
    .limit(1);

  if (!account.length) throw new Error("Failed to create client account");
  return account[0];
}

/**
 * Get client account by username
 */
export async function getClientAccountByUsername(
  username: string
): Promise<ClientAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.username, username))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get client account by ID
 */
export async function getClientAccountById(
  id: number
): Promise<ClientAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * List all client accounts created by an admin
 */
export async function listClientAccountsByAdmin(
  adminUserId: number
): Promise<ClientAccount[]> {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.createdByUserId, adminUserId));
}

/**
 * Get client account by phone number
 */
export async function getClientAccountByPhone(
  phoneNumber: string
): Promise<ClientAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.phoneNumber, phoneNumber))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get client account by email
 */
export async function getClientAccountByEmail(
  email: string
): Promise<ClientAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(clientAccounts)
    .where(eq(clientAccounts.email, email))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * List all client accounts (for admin approval view)
 */
export async function listAllClientAccounts(): Promise<ClientAccount[]> {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(clientAccounts);
}

/**
 * Update client account
 */
export async function updateClientAccount(
  id: number,
  data: Partial<Omit<InsertClientAccount, "id" | "createdAt" | "createdByUserId">>
): Promise<ClientAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(clientAccounts).set(data).where(eq(clientAccounts.id, id));

  return await getClientAccountById(id);
}

/**
 * Delete client account
 */
export async function deleteClientAccount(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  await db.delete(clientAccounts).where(eq(clientAccounts.id, id));
  return true;
}

/**
 * Update last login timestamp
 */
export async function updateLastLogin(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db
    .update(clientAccounts)
    .set({ lastLoginAt: new Date() })
    .where(eq(clientAccounts.id, id));
}
