import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";

// ─── PDF Export Router ───
// Generates HTML-based PDF content that the frontend can print/download
export const pdfExportRouter = router({
  // Generate a PDF report as HTML string (frontend uses window.print or html2canvas)
  generateReport: publicProcedure
    .input(
      z.object({
        vin: z.string(),
        vehicleInfo: z.object({
          year: z.string().optional(),
          make: z.string().optional(),
          model: z.string().optional(),
          trim: z.string().optional(),
          bodyClass: z.string().optional(),
          engineCylinders: z.string().optional(),
          engineDisplacement: z.string().optional(),
          driveType: z.string().optional(),
          fuelType: z.string().optional(),
        }),
        auctionHouse: z.string(),
        bidAmountUSD: z.number(),
        shippingCostUSD: z.number(),
        mileage: z.number(),
        uaeMarketPriceAED: z.number(),
        emirate: z.string(),
        includeRegistration: z.boolean(),
        costBreakdown: z.object({
          auctionFeesUSD: z.number(),
          shippingUSD: z.number(),
          totalLandedUSD: z.number(),
          totalLandedAED: z.number(),
          customsDutyAED: z.number(),
          vatAED: z.number(),
          partsAED: z.number(),
          registrationAED: z.number(),
          totalCostAED: z.number(),
          estimatedProfitAED: z.number(),
          profitMarginPercent: z.number(),
        }),
        damageAnalysis: z
          .object({
            overallSeverity: z.string(),
            overallSeverityScore: z.number(),
            summary: z.string(),
            damages: z.array(
              z.object({
                area: z.string(),
                description: z.string(),
                severity: z.string(),
                estimatedRepairCostAED: z.object({
                  low: z.number(),
                  high: z.number(),
                }).optional(),
                estimatedRepairCostUSD: z.object({
                  low: z.number(),
                  high: z.number(),
                }).optional(),
              })
            ),
            repairableAssessment: z.string(),
            estimatedTotalRepairAED: z.object({
              low: z.number(),
              high: z.number(),
            }).optional(),
            estimatedTotalRepairUSD: z.object({
              low: z.number(),
              high: z.number(),
            }).optional(),
            recommendations: z.array(z.string()),
          })
          .optional(),
        photoUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const vi = input.vehicleInfo;
      const cb = input.costBreakdown;
      const da = input.damageAnalysis;
      const vehicleName = [vi.year, vi.make, vi.model, vi.trim].filter(Boolean).join(" ");
      const date = new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });

      const formatUSD = (n: number) => `$${n.toLocaleString("en-US")}`;
      const formatAED = (n: number) => `AED ${n.toLocaleString("en-US")}`;

      const severityColor = (s: string) => {
        if (s === "minor") return "#22c55e";
        if (s === "moderate") return "#f59e0b";
        return "#ef4444";
      };

      let damageSection = "";
      if (da) {
        const damageRows = da.damages
          .map(
            (d) => `
          <tr>
            <td style="padding:8px 12px;border-bottom:1px solid #1e293b;">${d.area}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #1e293b;">${d.description}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:center;">
              <span style="color:${severityColor(d.severity)};font-weight:600;text-transform:uppercase;">${d.severity}</span>
            </td>
            <td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED((d.estimatedRepairCostAED || d.estimatedRepairCostUSD)?.low || 0)} - ${formatAED((d.estimatedRepairCostAED || d.estimatedRepairCostUSD)?.high || 0)}</td>
          </tr>`
          )
          .join("");

        const recItems = da.recommendations
          .map((r) => `<li style="margin-bottom:6px;">${r}</li>`)
          .join("");

        damageSection = `
        <div style="page-break-before:always;"></div>
        <h2 style="color:#10b981;font-size:20px;margin:32px 0 16px;border-bottom:2px solid #10b981;padding-bottom:8px;">AI Damage Analysis</h2>
        
        <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;margin-bottom:20px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <span style="font-size:16px;font-weight:600;">Overall Severity</span>
            <span style="color:${severityColor(da.overallSeverity)};font-size:24px;font-weight:700;">${da.overallSeverityScore}/10 — ${da.overallSeverity.toUpperCase()}</span>
          </div>
          <p style="color:#94a3b8;line-height:1.6;">${da.summary}</p>
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
          <thead>
            <tr style="background:#1e293b;">
              <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;color:#94a3b8;">Area</th>
              <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;color:#94a3b8;">Description</th>
              <th style="padding:10px 12px;text-align:center;font-size:12px;text-transform:uppercase;color:#94a3b8;">Severity</th>
              <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;color:#94a3b8;">Est. Repair</th>
            </tr>
          </thead>
          <tbody>${damageRows}</tbody>
          <tfoot>
            <tr style="background:#1e293b;font-weight:700;">
              <td colspan="3" style="padding:10px 12px;">Estimated Total Repair Cost (UAE)</td>
              <td style="padding:10px 12px;text-align:right;color:#10b981;">${formatAED((da.estimatedTotalRepairAED || da.estimatedTotalRepairUSD)?.low || 0)} - ${formatAED((da.estimatedTotalRepairAED || da.estimatedTotalRepairUSD)?.high || 0)}</td>
            </tr>
          </tfoot>
        </table>

        <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;margin-bottom:20px;">
          <h3 style="font-size:14px;color:#10b981;margin-bottom:8px;">UAE Import Assessment</h3>
          <p style="color:#94a3b8;line-height:1.6;">${da.repairableAssessment}</p>
        </div>

        <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;">
          <h3 style="font-size:14px;color:#10b981;margin-bottom:8px;">Recommendations</h3>
          <ul style="color:#94a3b8;padding-left:20px;line-height:1.8;">${recItems}</ul>
        </div>`;
      }

      const profitColor = cb.estimatedProfitAED >= 0 ? "#10b981" : "#ef4444";

      const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>UAE AuctionCalc Report — ${vehicleName}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap');
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'DM Sans',sans-serif; background:#0a0e1a; color:#e2e8f0; padding:40px; line-height:1.5; }
    h1,h2,h3 { font-family:'Outfit',sans-serif; }
    @media print {
      body { padding:20px; background:#0a0e1a !important; color:#e2e8f0 !important; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;padding-bottom:20px;border-bottom:2px solid #10b981;">
    <div>
      <h1 style="font-size:28px;font-weight:700;">UAE <span style="color:#10b981;">AuctionCalc</span></h1>
      <p style="color:#64748b;font-size:13px;margin-top:4px;">US Auction → UAE Import Cost Analysis</p>
    </div>
    <div style="text-align:right;">
      <p style="color:#94a3b8;font-size:13px;">${date}</p>
      <p style="color:#64748b;font-size:12px;">VIN: ${input.vin}</p>
    </div>
  </div>

  <!-- Vehicle Info -->
  <h2 style="color:#10b981;font-size:20px;margin-bottom:16px;border-bottom:2px solid #10b981;padding-bottom:8px;">Vehicle Information</h2>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:28px;">
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:12px;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Vehicle</span>
      <p style="font-size:16px;font-weight:600;margin-top:4px;">${vehicleName}</p>
    </div>
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:12px;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Mileage</span>
      <p style="font-size:16px;font-weight:600;margin-top:4px;">${input.mileage.toLocaleString()} mi</p>
    </div>
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:12px;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Auction House</span>
      <p style="font-size:16px;font-weight:600;margin-top:4px;">${input.auctionHouse.toUpperCase()}</p>
    </div>
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:12px;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Destination</span>
      <p style="font-size:16px;font-weight:600;margin-top:4px;">${input.emirate.charAt(0).toUpperCase() + input.emirate.slice(1)}, UAE</p>
    </div>
  </div>

  <!-- Cost Breakdown -->
  <h2 style="color:#10b981;font-size:20px;margin-bottom:16px;border-bottom:2px solid #10b981;padding-bottom:8px;">Cost Breakdown</h2>
  <table style="width:100%;border-collapse:collapse;margin-bottom:28px;">
    <thead>
      <tr style="background:#1e293b;">
        <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;color:#94a3b8;">Item</th>
        <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;color:#94a3b8;">USD</th>
        <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;color:#94a3b8;">AED</th>
      </tr>
    </thead>
    <tbody>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Winning Bid</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatUSD(input.bidAmountUSD)}</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(Math.round(input.bidAmountUSD * 3.6725))}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Auction Fees (${input.auctionHouse.toUpperCase()})</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatUSD(cb.auctionFeesUSD)}</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(Math.round(cb.auctionFeesUSD * 3.6725))}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Shipping to UAE</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatUSD(cb.shippingUSD)}</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(Math.round(cb.shippingUSD * 3.6725))}</td></tr>
      <tr style="background:#1e293b;font-weight:600;"><td style="padding:10px 12px;">Total Landed Cost</td><td style="padding:10px 12px;text-align:right;">${formatUSD(cb.totalLandedUSD)}</td><td style="padding:10px 12px;text-align:right;">${formatAED(cb.totalLandedAED)}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Customs Duty (5%)</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">—</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(cb.customsDutyAED)}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">VAT (5%)</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">—</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(cb.vatAED)}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Spare Parts & Repairs</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">—</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(cb.partsAED)}</td></tr>
      ${input.includeRegistration ? `<tr><td style="padding:8px 12px;border-bottom:1px solid #1e293b;">Registration (${input.emirate})</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">—</td><td style="padding:8px 12px;border-bottom:1px solid #1e293b;text-align:right;">${formatAED(cb.registrationAED)}</td></tr>` : ""}
    </tbody>
    <tfoot>
      <tr style="background:#1e293b;font-weight:700;font-size:16px;">
        <td style="padding:12px;">TOTAL INVESTMENT</td>
        <td style="padding:12px;text-align:right;">—</td>
        <td style="padding:12px;text-align:right;color:#10b981;">${formatAED(cb.totalCostAED)}</td>
      </tr>
    </tfoot>
  </table>

  <!-- Profit Analysis -->
  <h2 style="color:#10b981;font-size:20px;margin-bottom:16px;border-bottom:2px solid #10b981;padding-bottom:8px;">Profit Analysis</h2>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:28px;">
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;text-align:center;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">UAE Market Price</span>
      <p style="font-size:20px;font-weight:700;color:#10b981;margin-top:8px;">${formatAED(input.uaeMarketPriceAED)}</p>
    </div>
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;text-align:center;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Estimated Profit</span>
      <p style="font-size:20px;font-weight:700;color:${profitColor};margin-top:8px;">${formatAED(cb.estimatedProfitAED)}</p>
    </div>
    <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:16px;text-align:center;">
      <span style="color:#64748b;font-size:12px;text-transform:uppercase;">Profit Margin</span>
      <p style="font-size:20px;font-weight:700;color:${profitColor};margin-top:8px;">${cb.profitMarginPercent}%</p>
    </div>
  </div>

  ${damageSection}

  <!-- Footer -->
  <div style="margin-top:40px;padding-top:16px;border-top:1px solid #1e293b;text-align:center;">
    <p style="color:#64748b;font-size:12px;">Generated by UAE AuctionCalc — US Auction → UAE Import Calculator</p>
    <p style="color:#475569;font-size:11px;margin-top:4px;">This report is for informational purposes only. Actual costs may vary.</p>
  </div>
</body>
</html>`;

      return { html, vehicleName, date };
    }),
});
