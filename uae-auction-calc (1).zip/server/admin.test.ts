import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

function createPublicContext(): { ctx: TrpcContext } {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

function createUserContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("Admin Router - Pricing Plans", () => {
  it("should allow public access to get active plans", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const plans = await caller.admin.getActivePlans();
    expect(Array.isArray(plans)).toBe(true);
    // Should have seeded plans
    expect(plans.length).toBeGreaterThanOrEqual(0);
    // Each plan should have required fields
    for (const plan of plans) {
      expect(plan).toHaveProperty("name");
      expect(plan).toHaveProperty("priceMonthlyAED");
      expect(plan).toHaveProperty("priceAnnualAED");
      expect(plan).toHaveProperty("vinLimitPerMonth");
      expect(plan).toHaveProperty("features");
      expect(Array.isArray(plan.features)).toBe(true);
    }
  });

  it("should allow public access to get all plans", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const plans = await caller.admin.getPlans();
    expect(Array.isArray(plans)).toBe(true);
  });

  it("should block non-admin users from updating plans", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.updatePlan({ id: 1, name: "Hacked Plan" })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin users from creating plans", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.createPlan({
        name: "Hacked Plan",
        slug: "hacked",
        priceMonthlyAED: 100,
        priceAnnualAED: 1000,
        vinLimitPerMonth: 10,
        features: ["hack"],
      })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin users from deleting plans", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.deletePlan({ id: 1 })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Admin Router - Dashboard Stats", () => {
  it("should return dashboard stats for admin users", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.admin.getDashboardStats();
    expect(stats).toHaveProperty("totalClients");
    expect(stats).toHaveProperty("activeClients");
    expect(stats).toHaveProperty("pendingClients");
    expect(stats).toHaveProperty("totalVinSearches");
    expect(stats).toHaveProperty("monthlyVinSearches");
    expect(stats).toHaveProperty("activeSubscriptions");
    expect(stats).toHaveProperty("monthlyRevenueAED");
    expect(typeof stats.totalClients).toBe("number");
    expect(typeof stats.activeClients).toBe("number");
    // SQL COALESCE may return string; just verify it's a valid number
    expect(Number(stats.monthlyRevenueAED)).toBeGreaterThanOrEqual(0);
  });

  it("should block non-admin users from accessing dashboard stats", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.getDashboardStats()).rejects.toThrow(/admin|forbidden/i);
  });

  it("should return client usage stats for admin users", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const clients = await caller.admin.getClientUsageStats();
    expect(Array.isArray(clients)).toBe(true);
    for (const client of clients) {
      expect(client).toHaveProperty("id");
      expect(client).toHaveProperty("username");
      expect(client).toHaveProperty("status");
      expect(client).toHaveProperty("vinSearches");
      expect(typeof client.vinSearches).toBe("number");
    }
  });

  it("should block non-admin users from accessing client usage stats", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.getClientUsageStats()).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Admin Router - VIN Quota", () => {
  it("should return VIN quota for a given account (public access)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Use a non-existent account ID — should still return free trial defaults
    const quota = await caller.admin.getVinQuota({ accountId: 99999 });
    expect(quota).toHaveProperty("limit");
    expect(quota).toHaveProperty("used");
    expect(quota).toHaveProperty("remaining");
    expect(quota).toHaveProperty("hasSubscription");
    expect(quota).toHaveProperty("planName");
    expect(quota.limit).toBe(3); // Free trial = 3 VINs
    expect(quota.hasSubscription).toBe(false);
    expect(quota.planName).toBe("Free Trial");
  });
});
