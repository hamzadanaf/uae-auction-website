/**
 * Seed script — populate adminFeeSchedules table with all hardcoded fee data
 * Run: node server/seedFees.mjs
 */
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const conn = await mysql.createConnection(DATABASE_URL);

// Helper to upsert
async function upsert(category, feeKey, label, value, sortOrder = 0) {
  const [rows] = await conn.execute(
    "SELECT id FROM adminFeeSchedules WHERE category = ? AND feeKey = ?",
    [category, feeKey]
  );
  if (rows.length > 0) {
    await conn.execute(
      "UPDATE adminFeeSchedules SET label = ?, value = ?, sortOrder = ? WHERE id = ?",
      [label, JSON.stringify(value), sortOrder, rows[0].id]
    );
  } else {
    await conn.execute(
      "INSERT INTO adminFeeSchedules (category, feeKey, label, value, sortOrder, isActive) VALUES (?, ?, ?, ?, ?, 1)",
      [category, feeKey, label, JSON.stringify(value), sortOrder]
    );
  }
}

let order = 0;

// ═══ COPART BUYER FEES ═══
const copartBuyerFees = [
  { min: 0, max: 50, fee: 1 },
  { min: 50, max: 100, fee: 1 },
  { min: 100, max: 200, fee: 25 },
  { min: 200, max: 300, fee: 60 },
  { min: 300, max: 350, fee: 85 },
  { min: 350, max: 400, fee: 100 },
  { min: 400, max: 450, fee: 125 },
  { min: 450, max: 500, fee: 135 },
  { min: 500, max: 550, fee: 145 },
  { min: 550, max: 600, fee: 155 },
  { min: 600, max: 700, fee: 170 },
  { min: 700, max: 800, fee: 195 },
  { min: 800, max: 900, fee: 215 },
  { min: 900, max: 1000, fee: 230 },
  { min: 1000, max: 1200, fee: 250 },
  { min: 1200, max: 1300, fee: 270 },
  { min: 1300, max: 1400, fee: 285 },
  { min: 1400, max: 1500, fee: 300 },
  { min: 1500, max: 1600, fee: 315 },
  { min: 1600, max: 1700, fee: 330 },
  { min: 1700, max: 1800, fee: 350 },
  { min: 1800, max: 2000, fee: 370 },
  { min: 2000, max: 2400, fee: 390 },
  { min: 2400, max: 2500, fee: 425 },
  { min: 2500, max: 3000, fee: 460 },
  { min: 3000, max: 3500, fee: 505 },
  { min: 3500, max: 4000, fee: 555 },
  { min: 4000, max: 4500, fee: 600 },
  { min: 4500, max: 5000, fee: 625 },
  { min: 5000, max: 5500, fee: 650 },
  { min: 5500, max: 6000, fee: 675 },
  { min: 6000, max: 6500, fee: 700 },
  { min: 6500, max: 7000, fee: 720 },
  { min: 7000, max: 7500, fee: 755 },
  { min: 7500, max: 8000, fee: 775 },
  { min: 8000, max: 8500, fee: 800 },
  { min: 8500, max: 9000, fee: 820 },
  { min: 9000, max: 10000, fee: 820 },
  { min: 10000, max: 10500, fee: 850 },
  { min: 10500, max: 11000, fee: 850 },
  { min: 11000, max: 11500, fee: 850 },
  { min: 11500, max: 12000, fee: 860 },
  { min: 12000, max: 12500, fee: 875 },
  { min: 12500, max: 15000, fee: 890 },
  { min: 15000, max: null, fee: null, percent: 6 },
];

order = 0;
for (const tier of copartBuyerFees) {
  const key = `${tier.min}-${tier.max ?? "plus"}`;
  const label = tier.max ? `$${tier.min} — $${tier.max}` : `$${tier.min}+`;
  await upsert("copart_buyer_fee", key, label, tier, order++);
}
console.log(`✅ Seeded ${copartBuyerFees.length} Copart buyer fee tiers`);

// ═══ COPART VIRTUAL BID FEES ═══
const virtualFees = [
  { min: 0, max: 100, fee: 0 },
  { min: 100, max: 500, fee: 50 },
  { min: 500, max: 1000, fee: 65 },
  { min: 1000, max: 1500, fee: 85 },
  { min: 1500, max: 2000, fee: 95 },
  { min: 2000, max: 4000, fee: 110 },
  { min: 4000, max: 6000, fee: 125 },
  { min: 6000, max: 8000, fee: 145 },
  { min: 8000, max: null, fee: 160 },
];

order = 0;
for (const tier of virtualFees) {
  const key = `${tier.min}-${tier.max ?? "plus"}`;
  const label = tier.max ? `$${tier.min} — $${tier.max}` : `$${tier.min}+`;
  await upsert("copart_virtual_fee", key, label, tier, order++);
}
console.log(`✅ Seeded ${virtualFees.length} Copart virtual bid fee tiers`);

// ═══ FIXED FEES ═══
const fixedFees = [
  { key: "copart_gate_fee", label: "Copart Gate Fee", value: 95 },
  { key: "copart_env_fee", label: "Copart Environmental Fee", value: 15 },
  { key: "copart_title_fee", label: "Copart Title Fee", value: 20 },
  { key: "iaai_internet_bid_fee", label: "IAAI Internet Bid Fee", value: 79 },
];

order = 0;
for (const f of fixedFees) {
  await upsert("fixed_fee", f.key, f.label, { value: f.value }, order++);
}
console.log(`✅ Seeded ${fixedFees.length} fixed fees`);

// ═══ IMPORT TAX RATES ═══
const importTaxes = [
  { key: "customs_duty_rate", label: "UAE Customs Duty Rate", rate: 0.05 },
  { key: "vat_rate", label: "UAE VAT Rate", rate: 0.05 },
  { key: "usd_to_aed", label: "USD to AED Exchange Rate", rate: 3.685 },
];

order = 0;
for (const t of importTaxes) {
  await upsert("import_tax", t.key, t.label, { rate: t.rate }, order++);
}
console.log(`✅ Seeded ${importTaxes.length} import tax settings`);

// ═══ EMIRATE REGISTRATION FEES ═══
const emirates = [
  { id: "dubai", name: "Dubai", registrationFee: 500, inspectionFee: 150, plateFee: 200, otherFees: 100, total: 950, notes: "RTA - Fastest processing" },
  { id: "abu-dhabi", name: "Abu Dhabi", registrationFee: 450, inspectionFee: 150, plateFee: 180, otherFees: 80, total: 860, notes: "DARB - Lowest fees" },
  { id: "sharjah", name: "Sharjah", registrationFee: 400, inspectionFee: 120, plateFee: 160, otherFees: 70, total: 750, notes: "STA" },
  { id: "ajman", name: "Ajman", registrationFee: 350, inspectionFee: 100, plateFee: 140, otherFees: 60, total: 650, notes: "ATA" },
  { id: "umm-al-quwain", name: "Umm Al Quwain", registrationFee: 320, inspectionFee: 100, plateFee: 130, otherFees: 50, total: 600, notes: "UQTA" },
  { id: "ras-al-khaimah", name: "Ras Al Khaimah", registrationFee: 330, inspectionFee: 110, plateFee: 140, otherFees: 50, total: 630, notes: "RAKKTA" },
  { id: "fujairah", name: "Fujairah", registrationFee: 310, inspectionFee: 100, plateFee: 130, otherFees: 50, total: 590, notes: "FTA" },
];

order = 0;
for (const e of emirates) {
  await upsert("emirate_registration", e.id, e.name, e, order++);
}
console.log(`✅ Seeded ${emirates.length} emirate registration fees`);

// ═══ SHIPPING METHODS ═══
const shippingMethods = [
  { key: "roro", name: "RoRo (Roll-on/Roll-off)", costMin: 800, costMax: 1500, transit: "4-6 weeks", notes: "Cheapest option. Car must be driveable." },
  { key: "container_shared", name: "Container (Shared)", costMin: 1200, costMax: 2000, transit: "4-8 weeks", notes: "Shared container with other vehicles." },
  { key: "container_exclusive", name: "Container (Exclusive)", costMin: 2000, costMax: 3500, transit: "4-8 weeks", notes: "Your car only. Best for luxury/high-value." },
  { key: "air_freight", name: "Air Freight", costMin: 5000, costMax: 10000, transit: "3-5 days", notes: "Fastest. Rarely used for standard imports." },
];

order = 0;
for (const s of shippingMethods) {
  await upsert("shipping_method", s.key, s.name, s, order++);
}
console.log(`✅ Seeded ${shippingMethods.length} shipping methods`);

await conn.end();
console.log("\n🎉 All fee schedules seeded successfully!");
