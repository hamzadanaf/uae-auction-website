/**
 * Stripe Integration Tests
 * Tests for checkout session creation, webhook handling, and subscription management
 */
import { describe, it, expect, vi } from "vitest";

describe("Stripe Products Config", () => {
  it("should convert AED to Stripe amount (fils)", async () => {
    const { aedToStripeAmount } = await import("./stripe/products");
    expect(aedToStripeAmount(100)).toBe(10000);
    expect(aedToStripeAmount(49.99)).toBe(4999);
    expect(aedToStripeAmount(0)).toBe(0);
    expect(aedToStripeAmount(1)).toBe(100);
  });

  it("should use AED as currency", async () => {
    const { STRIPE_CURRENCY } = await import("./stripe/products");
    expect(STRIPE_CURRENCY).toBe("aed");
  });
});

describe("Stripe Client", () => {
  it("should throw if STRIPE_SECRET_KEY is not set", async () => {
    const originalKey = process.env.STRIPE_SECRET_KEY;
    delete process.env.STRIPE_SECRET_KEY;

    // Reset the module to clear cached instance
    vi.resetModules();
    const { getStripe } = await import("./stripe/client");

    expect(() => getStripe()).toThrow("STRIPE_SECRET_KEY is not configured");

    // Restore
    if (originalKey) process.env.STRIPE_SECRET_KEY = originalKey;
  });
});

describe("Stripe Router Schema Validation", () => {
  it("should validate createCheckoutSession input", () => {
    const { z } = require("zod");
    const schema = z.object({
      planId: z.number(),
      billingPeriod: z.enum(["monthly", "annual"]),
      accountId: z.number(),
      origin: z.string(),
    });

    // Valid input
    const valid = schema.safeParse({
      planId: 1,
      billingPeriod: "monthly",
      accountId: 5,
      origin: "https://example.com",
    });
    expect(valid.success).toBe(true);

    // Invalid billing period
    const invalid = schema.safeParse({
      planId: 1,
      billingPeriod: "weekly",
      accountId: 5,
      origin: "https://example.com",
    });
    expect(invalid.success).toBe(false);

    // Missing required fields
    const missing = schema.safeParse({ planId: 1 });
    expect(missing.success).toBe(false);
  });

  it("should validate cancelSubscription input", () => {
    const { z } = require("zod");
    const schema = z.object({ accountId: z.number() });

    expect(schema.safeParse({ accountId: 5 }).success).toBe(true);
    expect(schema.safeParse({ accountId: "abc" }).success).toBe(false);
    expect(schema.safeParse({}).success).toBe(false);
  });

  it("should validate verifyCheckout input", () => {
    const { z } = require("zod");
    const schema = z.object({ sessionId: z.string() });

    expect(schema.safeParse({ sessionId: "cs_test_123" }).success).toBe(true);
    expect(schema.safeParse({}).success).toBe(false);
  });
});

describe("Webhook Event Handling", () => {
  it("should handle test events with verified response", () => {
    // Simulate the test event check logic
    const testEventId = "evt_test_abc123";
    const isTestEvent = testEventId.startsWith("evt_test_");
    expect(isTestEvent).toBe(true);

    // Real event should not match
    const realEventId = "evt_1234567890";
    expect(realEventId.startsWith("evt_test_")).toBe(false);
  });

  it("should map subscription statuses correctly", () => {
    // Test the status mapping logic from webhook handler
    function mapStripeStatus(stripeStatus: string): string {
      if (stripeStatus === "canceled" || stripeStatus === "unpaid") return "cancelled";
      if (stripeStatus === "past_due") return "pending_payment";
      return "active";
    }

    expect(mapStripeStatus("active")).toBe("active");
    expect(mapStripeStatus("canceled")).toBe("cancelled");
    expect(mapStripeStatus("unpaid")).toBe("cancelled");
    expect(mapStripeStatus("past_due")).toBe("pending_payment");
    expect(mapStripeStatus("trialing")).toBe("active");
  });
});
