import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { savedDeals } from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";

// ─── Deal Queue Router ───
export const dealQueueRouter = router({
  // Save a deal to the queue
  save: protectedProcedure
    .input(
      z.object({
        vin: z.string().length(17),
        vehicleInfo: z.string(), // JSON string
        auctionHouse: z.string(),
        bidAmountUSD: z.number().int(),
        shippingCostUSD: z.number().int(),
        mileage: z.number().int(),
        uaeMarketPriceAED: z.number().int(),
        emirate: z.string(),
        includeRegistration: z.boolean(),
        damageTypes: z.string(), // JSON array string
        spareParts: z.string(), // JSON array string
        costBreakdown: z.string(), // JSON string
        totalCostAED: z.number().int(),
        estimatedProfitAED: z.number().int(),
        profitMarginPercent: z.number().int(),
        auctionLotData: z.string().optional(),
        damageAnalysis: z.string().optional(),
        photoUrl: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(savedDeals).values({
        userId: ctx.user.id,
        vin: input.vin,
        vehicleInfo: input.vehicleInfo,
        auctionHouse: input.auctionHouse,
        bidAmountUSD: input.bidAmountUSD,
        shippingCostUSD: input.shippingCostUSD,
        mileage: input.mileage,
        uaeMarketPriceAED: input.uaeMarketPriceAED,
        emirate: input.emirate,
        includeRegistration: input.includeRegistration ? 1 : 0,
        damageTypes: input.damageTypes,
        spareParts: input.spareParts,
        costBreakdown: input.costBreakdown,
        totalCostAED: input.totalCostAED,
        estimatedProfitAED: input.estimatedProfitAED,
        profitMarginPercent: input.profitMarginPercent,
        auctionLotData: input.auctionLotData || null,
        damageAnalysis: input.damageAnalysis || null,
        photoUrl: input.photoUrl || null,
        notes: input.notes || null,
      });

      return { success: true, id: result[0].insertId };
    }),

  // List all saved deals for the current user
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const deals = await db
      .select()
      .from(savedDeals)
      .where(eq(savedDeals.userId, ctx.user.id))
      .orderBy(desc(savedDeals.createdAt));

    return deals.map((deal) => ({
      ...deal,
      vehicleInfo: JSON.parse(deal.vehicleInfo),
      damageTypes: JSON.parse(deal.damageTypes),
      spareParts: JSON.parse(deal.spareParts),
      costBreakdown: JSON.parse(deal.costBreakdown),
      auctionLotData: deal.auctionLotData ? JSON.parse(deal.auctionLotData) : null,
      damageAnalysis: deal.damageAnalysis ? JSON.parse(deal.damageAnalysis) : null,
    }));
  }),

  // Get a single deal by ID
  getById: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select()
        .from(savedDeals)
        .where(and(eq(savedDeals.id, input.id), eq(savedDeals.userId, ctx.user.id)))
        .limit(1);

      if (result.length === 0) return null;

      const deal = result[0];
      return {
        ...deal,
        vehicleInfo: JSON.parse(deal.vehicleInfo),
        damageTypes: JSON.parse(deal.damageTypes),
        spareParts: JSON.parse(deal.spareParts),
        costBreakdown: JSON.parse(deal.costBreakdown),
        auctionLotData: deal.auctionLotData ? JSON.parse(deal.auctionLotData) : null,
        damageAnalysis: deal.damageAnalysis ? JSON.parse(deal.damageAnalysis) : null,
      };
    }),

  // Delete a deal
  delete: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .delete(savedDeals)
        .where(and(eq(savedDeals.id, input.id), eq(savedDeals.userId, ctx.user.id)));

      return { success: true };
    }),

  // Update notes on a deal
  updateNotes: protectedProcedure
    .input(z.object({ id: z.number().int(), notes: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(savedDeals)
        .set({ notes: input.notes })
        .where(and(eq(savedDeals.id, input.id), eq(savedDeals.userId, ctx.user.id)));

      return { success: true };
    }),
});
