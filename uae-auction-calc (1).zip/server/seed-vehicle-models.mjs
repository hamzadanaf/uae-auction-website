/**
 * Seed script: Populate vehicleModels table from PRICE_DB data
 * Run with: node server/seed-vehicle-models.mjs
 */
import 'dotenv/config';
import mysql from 'mysql2/promise';
import { readFileSync, writeFileSync, unlinkSync } from 'fs';

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

// Brand metadata
const BRAND_META = {
  nissan:         { region: "japanese",  display: "Nissan" },
  toyota:         { region: "japanese",  display: "Toyota" },
  honda:          { region: "japanese",  display: "Honda" },
  ford:           { region: "american",  display: "Ford" },
  chevrolet:      { region: "american",  display: "Chevrolet" },
  dodge:          { region: "american",  display: "Dodge" },
  jeep:           { region: "american",  display: "Jeep" },
  ram:            { region: "american",  display: "Ram" },
  gmc:            { region: "american",  display: "GMC" },
  hyundai:        { region: "korean",    display: "Hyundai" },
  kia:            { region: "korean",    display: "Kia" },
  bmw:            { region: "european",  display: "BMW" },
  "mercedes-benz":{ region: "european",  display: "Mercedes-Benz" },
  lexus:          { region: "japanese",  display: "Lexus" },
  subaru:         { region: "japanese",  display: "Subaru" },
  tesla:          { region: "american",  display: "Tesla" },
  cadillac:       { region: "american",  display: "Cadillac" },
  lincoln:        { region: "american",  display: "Lincoln" },
  infiniti:       { region: "japanese",  display: "Infiniti" },
  mazda:          { region: "japanese",  display: "Mazda" },
  volkswagen:     { region: "european",  display: "Volkswagen" },
  audi:           { region: "european",  display: "Audi" },
  genesis:        { region: "korean",    display: "Genesis" },
  acura:          { region: "japanese",  display: "Acura" },
  volvo:          { region: "european",  display: "Volvo" },
  porsche:        { region: "european",  display: "Porsche" },
  rivian:         { region: "american",  display: "Rivian" },
  lucid:          { region: "american",  display: "Lucid" },
  buick:          { region: "american",  display: "Buick" },
  chrysler:       { region: "american",  display: "Chrysler" },
  mitsubishi:     { region: "japanese",  display: "Mitsubishi" },
  jaguar:         { region: "european",  display: "Jaguar" },
  lamborghini:    { region: "european",  display: "Lamborghini" },
  ferrari:        { region: "european",  display: "Ferrari" },
  "rolls-royce":  { region: "european",  display: "Rolls-Royce" },
  bentley:        { region: "european",  display: "Bentley" },
  "aston martin": { region: "european",  display: "Aston Martin" },
  mclaren:        { region: "european",  display: "McLaren" },
  "alfa romeo":   { region: "european",  display: "Alfa Romeo" },
  fiat:           { region: "european",  display: "Fiat" },
  mini:           { region: "european",  display: "Mini" },
  maserati:       { region: "european",  display: "Maserati" },
  maybach:        { region: "european",  display: "Maybach" },
  suzuki:         { region: "japanese",  display: "Suzuki" },
  smart:          { region: "european",  display: "Smart" },
  peugeot:        { region: "european",  display: "Peugeot" },
  renault:        { region: "european",  display: "Renault" },
  "land rover":   { region: "european",  display: "Land Rover" },
};

// Model category mapping
const MODEL_CATEGORIES = {
  "4runner": "suv", "highlander": "suv", "rav4": "suv", "sequoia": "suv",
  "pathfinder": "suv", "rogue": "suv", "murano": "suv", "armada": "suv",
  "cr-v": "suv", "pilot": "suv", "hr-v": "suv", "passport": "suv",
  "explorer": "suv", "expedition": "suv", "bronco": "suv", "escape": "suv",
  "tahoe": "suv", "suburban": "suv", "traverse": "suv", "trailblazer": "suv", "blazer": "suv", "equinox": "suv",
  "durango": "suv", "hornet": "suv",
  "grand cherokee": "suv", "wrangler": "suv", "gladiator": "truck", "compass": "suv", "wagoneer": "suv", "grand wagoneer": "suv",
  "yukon": "suv", "acadia": "suv", "terrain": "suv",
  "tucson": "suv", "santa fe": "suv", "palisade": "suv", "kona": "suv", "venue": "suv",
  "telluride": "suv", "sportage": "suv", "sorento": "suv", "seltos": "suv", "carnival": "van",
  "x3": "suv", "x5": "suv", "x7": "suv", "x1": "suv", "ix": "electric",
  "gle": "suv", "glc": "suv", "gls": "suv", "gla": "suv", "glb": "suv", "g-class": "suv",
  "rx": "suv", "nx": "suv", "gx": "suv", "lx": "suv", "ux": "crossover",
  "outback": "crossover", "forester": "suv", "crosstrek": "crossover", "ascent": "suv",
  "escalade": "suv", "xt5": "suv", "xt4": "crossover", "xt6": "suv",
  "aviator": "suv", "navigator": "suv", "corsair": "crossover",
  "qx50": "suv", "qx60": "suv", "qx80": "suv",
  "cx-5": "suv", "cx-50": "suv", "cx-90": "suv", "cx-30": "crossover",
  "tiguan": "suv", "atlas": "suv", "id.4": "electric", "taos": "crossover",
  "q5": "suv", "q7": "suv", "q8": "suv", "q3": "crossover", "e-tron": "electric",
  "gv70": "suv", "gv80": "suv",
  "rdx": "suv", "mdx": "suv",
  "xc60": "suv", "xc90": "suv", "xc40": "crossover", "ex30": "electric",
  "cayenne": "suv", "macan": "suv",
  "f-pace": "suv", "e-pace": "crossover", "i-pace": "electric",
  "urus": "suv", "bentayga": "suv", "dbx": "suv", "cullinan": "suv",
  "levante": "suv", "grecale": "suv",
  "stelvio": "suv", "tonale": "crossover",
  "countryman": "crossover",
  "jimny": "suv", "vitara": "suv",
  "3008": "suv", "5008": "suv",
  "koleos": "suv", "duster": "suv",
  "outlander": "suv", "eclipse": "crossover",
  "enclave": "suv", "envision": "crossover", "encore": "crossover",
  "r1s": "electric",
  "f-150": "truck", "ranger": "truck", "maverick": "truck",
  "silverado": "truck", "colorado": "truck",
  "1500": "truck", "2500": "truck", "3500": "truck",
  "sierra": "truck", "canyon": "truck",
  "tundra": "truck", "tacoma": "truck",
  "frontier": "truck", "titan": "truck",
  "ridgeline": "truck", "r1t": "electric",
  "model 3": "electric", "model y": "electric", "model s": "electric", "model x": "electric", "cybertruck": "electric",
  "air": "electric", "eqe": "electric", "eqs": "electric", "i4": "electric", "i5": "electric", "i7": "electric",
  "ioniq 5": "electric", "ioniq 6": "electric", "ev6": "electric", "ev9": "electric",
  "#1": "electric", "megane": "electric",
  "mustang": "sports", "camaro": "sports", "corvette": "sports", "challenger": "sports", "charger": "sports",
  "supra": "sports", "gr86": "sports", "370z": "sports",
  "amg gt": "sports", "m3": "sports", "m4": "sports", "m5": "sports",
  "911": "sports", "718": "sports", "taycan": "electric",
  "f-type": "sports", "huracan": "sports", "aventador": "sports", "revuelto": "sports",
  "488": "sports", "f8": "sports", "roma": "sports", "sf90": "sports", "296": "sports", "portofino": "sports",
  "720s": "sports", "artura": "sports", "765lt": "sports",
  "vantage": "sports", "db11": "sports", "db12": "sports",
  "mc20": "sports",
  "s-class": "luxury", "phantom": "luxury", "ghost": "luxury", "wraith": "luxury", "spectre": "luxury",
  "continental gt": "luxury", "flying spur": "luxury",
  "ghibli": "luxury", "quattroporte": "luxury",
  "sienna": "van", "odyssey": "van", "pacifica": "van",
  "500": "hatchback", "500x": "hatchback", "cooper": "hatchback", "clubman": "hatchback",
  "fortwo": "hatchback", "swift": "hatchback",
  "golf": "hatchback", "jetta": "sedan",
};

// Default category for each brand
const BRAND_DEFAULT_CATEGORY = {
  nissan: "sedan", toyota: "sedan", honda: "sedan", ford: "sedan", chevrolet: "sedan",
  dodge: "sedan", jeep: "suv", ram: "truck", gmc: "truck", hyundai: "sedan", kia: "sedan",
  bmw: "sedan", "mercedes-benz": "sedan", lexus: "sedan", subaru: "sedan", tesla: "electric",
  cadillac: "luxury", lincoln: "luxury", infiniti: "sedan", mazda: "sedan", volkswagen: "sedan",
  audi: "sedan", genesis: "luxury", acura: "sedan", volvo: "sedan", porsche: "sports",
  rivian: "electric", lucid: "electric", buick: "sedan", chrysler: "sedan", mitsubishi: "suv",
  jaguar: "sedan", lamborghini: "sports", ferrari: "sports", "rolls-royce": "luxury",
  bentley: "luxury", "aston martin": "sports", mclaren: "sports", "alfa romeo": "sedan",
  fiat: "hatchback", mini: "hatchback", maserati: "luxury", maybach: "luxury",
  suzuki: "suv", smart: "hatchback", peugeot: "suv", renault: "suv", "land rover": "suv",
};

async function main() {
  // Step 1: Extract PRICE_DB by creating a temporary JS file
  const tsContent = readFileSync('/home/ubuntu/uae-auction-calc/client/src/lib/marketPrices.ts', 'utf-8');
  
  // Extract just the PRICE_DB object
  const dbStart = tsContent.indexOf('const PRICE_DB');
  const dbDeclStart = tsContent.indexOf('{', dbStart);
  
  // Find the matching closing brace
  let braceCount = 0;
  let dbEnd = -1;
  for (let i = dbDeclStart; i < tsContent.length; i++) {
    if (tsContent[i] === '{') braceCount++;
    if (tsContent[i] === '}') braceCount--;
    if (braceCount === 0) { dbEnd = i + 1; break; }
  }
  
  const dbObjectStr = tsContent.substring(dbDeclStart, dbEnd);
  
  // Write as a temporary module
  const tmpFile = '/tmp/price_db_extract.mjs';
  writeFileSync(tmpFile, `export const PRICE_DB = ${dbObjectStr};\n`);
  
  // Import it
  const { PRICE_DB } = await import(tmpFile);
  unlinkSync(tmpFile);
  
  const makes = Object.keys(PRICE_DB);
  console.log(`Found ${makes.length} makes in PRICE_DB`);
  
  // Step 2: Build rows
  const rows = [];
  for (const make of makes) {
    const models = Object.keys(PRICE_DB[make]);
    const meta = BRAND_META[make] || { region: "european", display: make.charAt(0).toUpperCase() + make.slice(1) };
    
    for (const model of models) {
      const yearData = PRICE_DB[make][model];
      const years = Object.keys(yearData).map(Number).filter(y => y >= 2000 && y <= 2030);
      
      if (years.length === 0) continue;
      
      const minYear = Math.min(...years);
      const maxYear = Math.max(...years);
      const latestYear = maxYear;
      const latest = yearData[latestYear];
      
      if (!latest || !latest.low || !latest.mid || !latest.high) continue;
      
      const category = MODEL_CATEGORIES[model] || BRAND_DEFAULT_CATEGORY[make] || "sedan";
      const auctionAvgUSD = Math.round(latest.mid * 0.5 / 3.67);
      
      // Capitalize model name
      const displayModel = model.split(/[\s-]/).map(w => {
        if (w.length <= 2 && w === w.toUpperCase()) return w; // Keep acronyms
        return w.charAt(0).toUpperCase() + w.slice(1);
      }).join(model.includes('-') ? '-' : ' ');
      
      rows.push({
        brand: meta.display,
        model: displayModel,
        region: meta.region,
        category,
        yearFrom: minYear,
        yearTo: maxYear,
        uaeMarketPriceLow: latest.low,
        uaeMarketPriceMid: latest.mid,
        uaeMarketPriceHigh: latest.high,
        auctionAvgPriceUSD: auctionAvgUSD,
      });
    }
    
    console.log(`  ${meta.display}: ${models.length} models`);
  }
  
  console.log(`\nTotal: ${rows.length} models to seed`);
  
  // Step 3: Insert into database
  const conn = await mysql.createConnection(DATABASE_URL);
  
  // Clear existing data
  await conn.execute("DELETE FROM vehicleModels");
  console.log("Cleared existing data");
  
  // Insert in batches
  const batchSize = 50;
  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const placeholders = batch.map(() => "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())").join(", ");
    const values = batch.flatMap(r => [
      r.brand, r.model, r.region, r.category,
      r.yearFrom, r.yearTo,
      r.uaeMarketPriceLow, r.uaeMarketPriceMid, r.uaeMarketPriceHigh,
      r.auctionAvgPriceUSD
    ]);

    await conn.execute(
      `INSERT INTO vehicleModels (brand, model, region, category, yearFrom, yearTo, uaeMarketPriceLow, uaeMarketPriceMid, uaeMarketPriceHigh, auctionAvgPriceUSD, isActive, createdAt, updatedAt) VALUES ${placeholders}`,
      values
    );
  }
  
  // Verify
  const [summary] = await conn.execute("SELECT COUNT(DISTINCT brand) as brands, COUNT(*) as models FROM vehicleModels");
  console.log(`\nDone! Database now has: ${summary[0].brands} brands, ${summary[0].models} models`);
  
  // Show per-brand breakdown
  const [breakdown] = await conn.execute("SELECT brand, COUNT(*) as cnt FROM vehicleModels GROUP BY brand ORDER BY brand");
  for (const row of breakdown) {
    console.log(`  ${row.brand}: ${row.cnt} models`);
  }
  
  await conn.end();
}

main().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
