import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };

  return { ctx };
}

function createPublicContext(): { ctx: TrpcContext } {
  const ctx: TrpcContext = {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
  return { ctx };
}

function createUserContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
  return { ctx };
}

// ═══════════════════════════════════════════════════════
// FEE SCHEDULE TESTS
// ═══════════════════════════════════════════════════════

describe("Fee Schedule - Public Access", () => {
  it("should allow public access to get fee schedules", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    expect(Array.isArray(fees)).toBe(true);
  });

  it("should return seeded fee data with correct categories", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const categories = [...new Set(fees.map((f: any) => f.category))];

    // Should have at least buyer fees, virtual fees, fixed fees, import tax, emirate registration, shipping
    expect(categories.length).toBeGreaterThanOrEqual(4);
  });

  it("should return buyer fee entries with valid JSON values", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const buyerFees = fees.filter((f: any) => f.category === "copart_buyer_fee");

    expect(buyerFees.length).toBeGreaterThan(0);

    // Each buyer fee should have parseable JSON value
    for (const fee of buyerFees) {
      const parsed = JSON.parse(fee.value);
      expect(parsed).toHaveProperty("min");
      expect(typeof parsed.min).toBe("number");
    }
  });

  it("should return emirate registration fees for all 7 emirates", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const emirateFees = fees.filter((f: any) => f.category === "emirate_registration");

    expect(emirateFees.length).toBe(7);

    // Each should have a total field
    for (const fee of emirateFees) {
      const parsed = JSON.parse(fee.value);
      expect(parsed).toHaveProperty("total");
      expect(typeof parsed.total).toBe("number");
    }
  });
});

describe("Fee Schedule - Admin CRUD", () => {
  it("should block non-admin from upserting fee schedules", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.upsertFeeSchedule({
        category: "test",
        feeKey: "test_key",
        label: "Test Fee",
        value: '{"fee": 100}',
        sortOrder: 0,
        isActive: 1,
      })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from deleting fee schedules", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.deleteFeeSchedule({ id: 1 })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should allow admin to upsert a fee schedule entry", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.siteConfig.upsertFeeSchedule({
      category: "test_category",
      feeKey: "vitest_test_fee",
      label: "Vitest Test Fee",
      value: '{"fee": 999}',
      sortOrder: 99,
      isActive: 1,
    });

    expect(result).toBeDefined();
  });

  it("should allow admin to retrieve the upserted fee", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const testFee = fees.find((f: any) => f.feeKey === "vitest_test_fee");

    expect(testFee).toBeDefined();
    expect(testFee!.label).toBe("Vitest Test Fee");
    expect(testFee!.category).toBe("test_category");
    expect(JSON.parse(testFee!.value)).toEqual({ fee: 999 });
  });

  it("should allow admin to delete the test fee", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    // Find the test fee first
    const fees = await caller.siteConfig.getFeeSchedules();
    const testFee = fees.find((f: any) => f.feeKey === "vitest_test_fee");

    if (testFee) {
      const result = await caller.siteConfig.deleteFeeSchedule({ id: testFee.id });
      expect(result).toBeDefined();
    }

    // Verify it's gone
    const feesAfter = await caller.siteConfig.getFeeSchedules();
    const deletedFee = feesAfter.find((f: any) => f.feeKey === "vitest_test_fee");
    expect(deletedFee).toBeUndefined();
  });
});

describe("Fee Schedule - Data Integrity", () => {
  it("should have fixed fees (gate, env, title)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const fixedFees = fees.filter((f: any) => f.category === "fixed_fee");

    expect(fixedFees.length).toBeGreaterThanOrEqual(3);

    const feeKeys = fixedFees.map((f: any) => f.feeKey);
    expect(feeKeys).toContain("copart_gate_fee");
    expect(feeKeys).toContain("copart_env_fee");
    expect(feeKeys).toContain("copart_title_fee");
  });

  it("should have import tax entries (customs, VAT, exchange rate)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const taxFees = fees.filter((f: any) => f.category === "import_tax");

    expect(taxFees.length).toBeGreaterThanOrEqual(3);

    const feeKeys = taxFees.map((f: any) => f.feeKey);
    expect(feeKeys).toContain("customs_duty_rate");
    expect(feeKeys).toContain("vat_rate");
    expect(feeKeys).toContain("usd_to_aed");
  });

  it("should have shipping method entries", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const fees = await caller.siteConfig.getFeeSchedules();
    const shippingFees = fees.filter((f: any) => f.category === "shipping_method");

    expect(shippingFees.length).toBeGreaterThanOrEqual(2);
  });
});
