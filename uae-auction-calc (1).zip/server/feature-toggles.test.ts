/**
 * Tests for feature toggles and fee schedules — verifying that:
 * 1. Public endpoints return site settings (feature toggles)
 * 2. Public endpoints return fee schedules from the database
 * 3. Admin can upsert settings and fee schedules
 */
import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { siteSettings, adminFeeSchedules } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

describe("Feature Toggles (siteSettings)", () => {
  let db: Awaited<ReturnType<typeof getDb>>;

  beforeAll(async () => {
    db = await getDb();
  });

  it("should be able to insert and read a feature toggle", async () => {
    if (!db) return;

    // Insert a test toggle
    const testKey = `test_toggle_${Date.now()}`;
    await db.insert(siteSettings).values({
      settingKey: testKey,
      settingValue: "true",
      label: "Test Toggle",
      category: "feature_toggle",
    });

    // Read it back
    const [result] = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.settingKey, testKey));

    expect(result).toBeDefined();
    expect(result.settingKey).toBe(testKey);
    expect(result.settingValue).toBe("true");
    expect(result.category).toBe("feature_toggle");

    // Clean up
    await db.delete(siteSettings).where(eq(siteSettings.settingKey, testKey));
  });

  it("should be able to update a feature toggle value", async () => {
    if (!db) return;

    const testKey = `test_toggle_update_${Date.now()}`;
    await db.insert(siteSettings).values({
      settingKey: testKey,
      settingValue: "true",
      label: "Test Toggle Update",
      category: "feature_toggle",
    });

    // Update it
    await db
      .update(siteSettings)
      .set({ settingValue: "false" })
      .where(eq(siteSettings.settingKey, testKey));

    // Read it back
    const [result] = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.settingKey, testKey));

    expect(result.settingValue).toBe("false");

    // Clean up
    await db.delete(siteSettings).where(eq(siteSettings.settingKey, testKey));
  });

  it("should return empty for non-existent toggle", async () => {
    if (!db) return;

    const results = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.settingKey, "non_existent_toggle_xyz"));

    expect(results).toHaveLength(0);
  });
});

describe("Fee Schedules (adminFeeSchedules)", () => {
  let db: Awaited<ReturnType<typeof getDb>>;

  beforeAll(async () => {
    db = await getDb();
  });

  it("should be able to insert and read a fee schedule entry", async () => {
    if (!db) return;

    const testKey = `test_fee_${Date.now()}`;
    await db.insert(adminFeeSchedules).values({
      category: "test_category",
      feeKey: testKey,
      label: "Test Fee",
      value: JSON.stringify({ min: 0, max: 100, fee: 25 }),
      sortOrder: 0,
      isActive: 1,
    });

    // Read it back
    const [result] = await db
      .select()
      .from(adminFeeSchedules)
      .where(
        and(
          eq(adminFeeSchedules.category, "test_category"),
          eq(adminFeeSchedules.feeKey, testKey)
        )
      );

    expect(result).toBeDefined();
    expect(result.category).toBe("test_category");
    expect(result.feeKey).toBe(testKey);
    expect(result.label).toBe("Test Fee");
    expect(result.isActive).toBe(1);

    const parsed = JSON.parse(result.value);
    expect(parsed.min).toBe(0);
    expect(parsed.max).toBe(100);
    expect(parsed.fee).toBe(25);

    // Clean up
    await db
      .delete(adminFeeSchedules)
      .where(eq(adminFeeSchedules.id, result.id));
  });

  it("should be able to query fee schedules by category", async () => {
    if (!db) return;

    const testCategory = `test_cat_${Date.now()}`;
    // Insert multiple entries
    await db.insert(adminFeeSchedules).values([
      {
        category: testCategory,
        feeKey: "fee_a",
        label: "Fee A",
        value: JSON.stringify({ min: 0, max: 50, fee: 10 }),
        sortOrder: 0,
        isActive: 1,
      },
      {
        category: testCategory,
        feeKey: "fee_b",
        label: "Fee B",
        value: JSON.stringify({ min: 50, max: 100, fee: 20 }),
        sortOrder: 1,
        isActive: 1,
      },
    ]);

    // Query by category
    const results = await db
      .select()
      .from(adminFeeSchedules)
      .where(eq(adminFeeSchedules.category, testCategory));

    expect(results).toHaveLength(2);
    expect(results.map((r) => r.feeKey).sort()).toEqual(["fee_a", "fee_b"]);

    // Clean up
    for (const r of results) {
      await db
        .delete(adminFeeSchedules)
        .where(eq(adminFeeSchedules.id, r.id));
    }
  });

  it("should filter inactive fee schedules", async () => {
    if (!db) return;

    const testCategory = `test_inactive_${Date.now()}`;
    await db.insert(adminFeeSchedules).values([
      {
        category: testCategory,
        feeKey: "active_fee",
        label: "Active",
        value: JSON.stringify({ fee: 10 }),
        sortOrder: 0,
        isActive: 1,
      },
      {
        category: testCategory,
        feeKey: "inactive_fee",
        label: "Inactive",
        value: JSON.stringify({ fee: 20 }),
        sortOrder: 1,
        isActive: 0,
      },
    ]);

    // Query active only
    const results = await db
      .select()
      .from(adminFeeSchedules)
      .where(
        and(
          eq(adminFeeSchedules.category, testCategory),
          eq(adminFeeSchedules.isActive, 1)
        )
      );

    expect(results).toHaveLength(1);
    expect(results[0].feeKey).toBe("active_fee");

    // Clean up
    const all = await db
      .select()
      .from(adminFeeSchedules)
      .where(eq(adminFeeSchedules.category, testCategory));
    for (const r of all) {
      await db
        .delete(adminFeeSchedules)
        .where(eq(adminFeeSchedules.id, r.id));
    }
  });

  it("should be able to update a fee schedule entry", async () => {
    if (!db) return;

    const testKey = `test_update_fee_${Date.now()}`;
    await db.insert(adminFeeSchedules).values({
      category: "test_update",
      feeKey: testKey,
      label: "Original",
      value: JSON.stringify({ fee: 10 }),
      sortOrder: 0,
      isActive: 1,
    });

    const [inserted] = await db
      .select()
      .from(adminFeeSchedules)
      .where(
        and(
          eq(adminFeeSchedules.category, "test_update"),
          eq(adminFeeSchedules.feeKey, testKey)
        )
      );

    // Update it
    await db
      .update(adminFeeSchedules)
      .set({
        label: "Updated",
        value: JSON.stringify({ fee: 50 }),
      })
      .where(eq(adminFeeSchedules.id, inserted.id));

    // Read back
    const [updated] = await db
      .select()
      .from(adminFeeSchedules)
      .where(eq(adminFeeSchedules.id, inserted.id));

    expect(updated.label).toBe("Updated");
    const parsed = JSON.parse(updated.value);
    expect(parsed.fee).toBe(50);

    // Clean up
    await db
      .delete(adminFeeSchedules)
      .where(eq(adminFeeSchedules.id, inserted.id));
  });
});
