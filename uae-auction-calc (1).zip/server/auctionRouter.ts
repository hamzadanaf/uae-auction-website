import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { ENV } from "./_core/env";
import axios from "axios";

// Types for auction lot data
interface AuctionLot {
  lotId: string;
  vin: string;
  year: number;
  make: string;
  model: string;
  trim?: string;
  bodyStyle?: string;
  engine?: string;
  transmission?: string;
  driveType?: string;
  fuelType?: string;
  cylinders?: string;
  color?: string;
  odometer?: number;
  odometerUnit?: string;
  primaryDamage?: string;
  secondaryDamage?: string;
  lossType?: string;
  titleType?: string;
  saleStatus?: string;
  currentBid?: number;
  buyNowPrice?: number;
  saleDate?: string;
  location?: string;
  sellingBranch?: string;
  images?: string[];
  source: "copart" | "iaai";
  url?: string;
  hasKeys?: boolean;
  repairCost?: number;
  retailValue?: number;
}

// ─── JWT Token Cache ───
// The login endpoint returns a JWT that expires after some time.
// We cache it and refresh when needed.
let cachedJwt: string | null = null;
let jwtExpiresAt: number = 0;

async function getAuctionApiJwt(): Promise<string | null> {
  const email = ENV.auctionApiEmail;
  const password = ENV.auctionApiPassword;

  if (!email || !password) {
    console.log("[auction-api.app] No email/password configured, skipping login");
    return null;
  }

  // Return cached token if still valid (with 5 min buffer)
  if (cachedJwt && Date.now() < jwtExpiresAt - 5 * 60 * 1000) {
    return cachedJwt;
  }

  try {
    console.log("[auction-api.app] Logging in to get JWT token...");
    const formData = new URLSearchParams();
    formData.append("email", email);
    formData.append("password", password);

    const resp = await axios.post(
      "https://auction-api.app/api/v1/login",
      formData.toString(),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          Accept: "application/json",
        },
        timeout: 15000,
      }
    );

    const token = resp.data?.token;
    if (!token) {
      console.error("[auction-api.app] Login response missing token:", resp.data);
      return null;
    }

    cachedJwt = token;
    // JWT typically expires in 6 hours, set conservative 5 hour cache
    jwtExpiresAt = Date.now() + 5 * 60 * 60 * 1000;
    console.log("[auction-api.app] JWT token obtained successfully");
    return token;
  } catch (error: any) {
    console.error("[auction-api.app] Login failed:", error?.message);
    // If Cloudflare blocks us, try using the static API token as fallback
    if (ENV.auctionApiToken) {
      console.log("[auction-api.app] Falling back to static API token");
      return ENV.auctionApiToken;
    }
    return null;
  }
}

// ─── NHTSA VIN Decoder (always free) ───
async function decodeVinNHTSA(vin: string) {
  try {
    const resp = await axios.get(
      `https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/${vin}?format=json`,
      { timeout: 10000 }
    );
    const r = resp.data?.Results?.[0];
    if (!r) return null;
    return {
      vin,
      year: parseInt(r.ModelYear) || 0,
      make: r.Make || "",
      model: r.Model || "",
      trim: r.Trim || "",
      bodyStyle: r.BodyClass || "",
      engine: `${r.DisplacementL || ""}L ${r.EngineCylinders || ""}-cyl ${r.FuelTypePrimary || ""}`.trim(),
      transmission: r.TransmissionStyle || "",
      driveType: r.DriveType || "",
      fuelType: r.FuelTypePrimary || "",
      cylinders: r.EngineCylinders || "",
    };
  } catch {
    return null;
  }
}

// ─── auction-api.app (paid, primary) ───
// Uses login→JWT→API flow per their documentation
async function searchAuctionApiApp(vin: string): Promise<AuctionLot[] | null> {
  // Try JWT login first, fall back to static token
  const token = await getAuctionApiJwt();
  if (!token) return null;

  try {
    const formData = new URLSearchParams();
    formData.append("vin", vin);
    formData.append("history", "true");

    const resp = await axios.post(
      "https://auction-api.app/api/v1/get-car-vin",
      formData.toString(),
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          Accept: "application/json",
        },
        timeout: 15000,
      }
    );

    const data = resp.data?.data;
    console.log(`[auction-api.app] VIN=${vin} response status=${resp.status}, data type=${typeof data}, isArray=${Array.isArray(data)}, length=${Array.isArray(data) ? data.length : 'N/A'}, raw keys=${resp.data ? Object.keys(resp.data).join(',') : 'null'}`);
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log(`[auction-api.app] VIN=${vin} no lot data found. Full response:`, JSON.stringify(resp.data).substring(0, 500));
      return null;
    }

    return data.map((lot: any) => {
      console.log(`[auction-api.app] Lot data: source=${lot.source}, lot_id=${lot.lot_id}, number=${lot.number}, source_lot_id=${lot.source_lot_id}, link=${lot.link}`);
      // Build full image URLs — photos use relative paths
      const images = (lot.photo || []).map((p: any) => {
        const imgPath = p.thumb_url || p.url || "";
        return imgPath.startsWith("http")
          ? imgPath
          : `https://auction-api.app${imgPath}`;
      });

      return {
        lotId: lot.number || lot.source_lot_id || "",
        vin: lot.vin || vin,
        year: parseInt(lot.year) || 0,
        make: lot.brand_name || lot.model?.brand?.name || "",
        model: lot.model_name || lot.model?.name || "",
        trim: lot.trim || "",
        bodyStyle: "",
        engine: `${lot.engine_volume || ""}L ${lot.cylinders || ""}-cyl ${lot.engine_fuel || ""}`.trim(),
        transmission: lot.transmission || "",
        driveType: lot.drive || "",
        fuelType: lot.engine_fuel || "",
        cylinders: lot.cylinders || "",
        color: lot.color || "",
        odometer: lot.mileage ? parseInt(lot.mileage) : undefined,
        odometerUnit: "mi",
        primaryDamage: lot.damage_main_damages || "",
        secondaryDamage: lot.damage_secondary_damages || "",
        lossType: lot.damage_status || "",
        titleType: lot.sale_title_type || lot.document || "",
        saleStatus: lot.active === "1" ? "active" : "sold",
        currentBid: lot.final_bid ? parseFloat(lot.final_bid) : undefined,
        buyNowPrice: lot.buy_it_now_price ? parseFloat(lot.buy_it_now_price) : undefined,
        saleDate: lot.sold_at || lot.ended_at || "",
        location: lot.yard_name || `${lot.city || ""}, ${lot.state || ""}`.trim(),
        sellingBranch: lot.seller || "",
        images,
        source: (lot.source === "iaai" ? "iaai" : "copart") as "copart" | "iaai",
        url: lot.link
          || (lot.source === "iaai"
            ? `https://www.iaai.com/VehicleDetail/${lot.lot_id || lot.source_lot_id || ""}~US`
            : (lot.lot_id
              ? `https://www.copart.com/lot/${lot.lot_id}`
              : `https://www.copart.com/lotSearchResults?query=${lot.vin || vin}`)),
        hasKeys: lot.has_keys === "1",
        repairCost: lot.repair_cost ? parseFloat(lot.repair_cost) : undefined,
        retailValue: lot.retail_value ? parseFloat(lot.retail_value) : undefined,
      } as AuctionLot;
    });
  } catch (error: any) {
    console.error("[auction-api.app] Search failed:", error?.message);
    // If 401/403, invalidate cached JWT so next request re-authenticates
    if (error?.response?.status === 401 || error?.response?.status === 403) {
      cachedJwt = null;
      jwtExpiresAt = 0;
    }
    return null;
  }
}

// ─── AutoBidCar Free API (fallback) ───
async function searchAutoBidCar(vin: string): Promise<AuctionLot | null> {
  try {
    const checkResp = await axios.get(
      `https://autobidcar.com/api/check/${vin}`,
      { timeout: 10000 }
    );
    const fullUrl = checkResp.data?.full_url;
    if (!fullUrl) return null;

    const pageResp = await axios.get(fullUrl, {
      timeout: 15000,
      headers: { "User-Agent": "Mozilla/5.0 (compatible; UAEAuctionCalc/1.0)" },
    });
    const html: string = pageResp.data;

    const ldMatches = html.match(/application\/ld\+json">([\s\S]*?)<\/script>/g) || [];
    let vehicleData: any = null;
    for (const match of ldMatches) {
      try {
        const jsonStr = match
          .replace(/application\/ld\+json">/, "")
          .replace(/<\/script>/, "");
        const parsed = JSON.parse(jsonStr);
        if (parsed?.["@type"] === "Vehicle") {
          vehicleData = parsed;
          break;
        }
      } catch {
        // skip
      }
    }
    if (!vehicleData) return null;

    const desc: string = vehicleData.description || "";
    const odometerMatch = desc.match(/Odometer:\s*(\d+)/);
    const lotMatch = desc.match(/Lot:\s*(IAAI|Copart)\s*(\d+)/);
    const locationMatch = desc.match(/Location:\s*([^|"]+)/);
    const saleDateMatch = desc.match(/Sale date:\s*([\d-]+)/);

    const auctionSource = lotMatch
      ? (lotMatch[1].toLowerCase() as "copart" | "iaai")
      : "copart";

    const imgPattern = new RegExp(
      `https://cdn\\.autobidcar\\.com/cars/${vin}/main/[^"\\\\]+`,
      "g"
    );
    const allImgs = html.match(imgPattern) || [];
    const uniqueImgs = Array.from(new Set(allImgs));
    if (uniqueImgs.length === 0 && vehicleData.image) {
      uniqueImgs.push(vehicleData.image);
    }

    return {
      lotId: lotMatch?.[2] || "",
      vin: vehicleData.vehicleIdentificationNumber || vin,
      year: parseInt(vehicleData.productionDate) || 0,
      make: vehicleData.manufacturer || "",
      model: vehicleData.model || "",
      trim: "",
      bodyStyle: "",
      engine: vehicleData.vehicleEngine?.engineType || vehicleData.vehicleEngine?.name || "",
      transmission: vehicleData.vehicleTransmission || "",
      driveType: "",
      fuelType: vehicleData.vehicleEngine?.fuelType || "",
      cylinders: "",
      color: vehicleData.color || "",
      odometer: odometerMatch ? parseInt(odometerMatch[1]) : undefined,
      odometerUnit: "mi",
      primaryDamage: vehicleData.knownVehicleDamages || "",
      secondaryDamage: "",
      lossType: "",
      titleType: "",
      saleStatus: "",
      currentBid: undefined,
      buyNowPrice: undefined,
      saleDate: saleDateMatch?.[1] || vehicleData.purchaseDate || "",
      location: locationMatch?.[1]?.trim() || "",
      sellingBranch: "",
      images: uniqueImgs,
      source: auctionSource,
      url: lotMatch?.[2]
        ? auctionSource === "iaai"
          ? `https://www.iaai.com/VehicleDetail/${lotMatch[2]}~US`
          : `https://www.copart.com/lot/${lotMatch[2]}`
        : auctionSource === "iaai"
          ? `https://www.iaai.com/Vehiclelisting`
          : `https://www.copart.com/lotSearchResults?query=${vin}`,
    };
  } catch (error: any) {
    if (error?.response?.status === 404) return null;
    console.error("[AutoBidCar] Search failed:", error?.message);
    return null;
  }
}

// ─── VIN History (Sale History API) ───
async function getVinHistory(vin: string): Promise<any[] | null> {
  const token = await getAuctionApiJwt();
  if (!token) return null;

  try {
    const formData = new URLSearchParams();
    formData.append("vin", vin);

    const resp = await axios.post(
      "https://auction-api.app/api/v1/get-vin-history",
      formData.toString(),
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          Accept: "application/json",
        },
        timeout: 15000,
      }
    );

    return resp.data?.data || null;
  } catch (error: any) {
    console.error("[auction-api.app] VIN history failed:", error?.message);
    return null;
  }
}

export const auctionRouter = router({
  // Search by VIN — tries auction-api.app first (login→JWT→API), then AutoBidCar, always includes NHTSA
  searchVin: publicProcedure
    .input(z.object({ vin: z.string().min(11).max(17) }))
    .query(async ({ input }) => {
      const { vin } = input;

      // Always run NHTSA in parallel
      const nhtsaPromise = decodeVinNHTSA(vin);

      // Try auction-api.app first (paid, best data)
      const auctionApiResult = await searchAuctionApiApp(vin);
      if (auctionApiResult && auctionApiResult.length > 0) {
        const nhtsaData = await nhtsaPromise;
        const firstLot = auctionApiResult[0];
        const vehicleInfo = nhtsaData || {
          vin,
          year: firstLot.year,
          make: firstLot.make,
          model: firstLot.model,
          trim: firstLot.trim || "",
          bodyStyle: firstLot.bodyStyle || "",
          engine: firstLot.engine || "",
          transmission: firstLot.transmission || "",
          driveType: firstLot.driveType || "",
          fuelType: firstLot.fuelType || "",
          cylinders: firstLot.cylinders || "",
        };

        return {
          source: "auction-api" as const,
          vehicleInfo,
          lots: auctionApiResult,
          hasAuctionData: true,
        };
      }

      // Fallback to AutoBidCar (free)
      const [autoBidResult, nhtsaData] = await Promise.all([
        searchAutoBidCar(vin),
        nhtsaPromise,
      ]);

      if (autoBidResult) {
        const vehicleInfo = nhtsaData || {
          vin,
          year: autoBidResult.year,
          make: autoBidResult.make,
          model: autoBidResult.model,
          trim: autoBidResult.trim || "",
          bodyStyle: autoBidResult.bodyStyle || "",
          engine: autoBidResult.engine || "",
          transmission: autoBidResult.transmission || "",
          driveType: autoBidResult.driveType || "",
          fuelType: autoBidResult.fuelType || "",
          cylinders: autoBidResult.cylinders || "",
        };

        return {
          source: "autobidcar" as const,
          vehicleInfo,
          lots: [autoBidResult],
          hasAuctionData: true,
        };
      }

      // NHTSA only fallback
      const nhtsaFinal = await nhtsaPromise;
      return {
        source: "nhtsa" as const,
        vehicleInfo: nhtsaFinal,
        lots: [] as AuctionLot[],
        hasAuctionData: false,
      };
    }),

  // VIN History (Sale History API - separate endpoint)
  vinHistory: publicProcedure
    .input(z.object({ vin: z.string().min(11).max(17) }))
    .query(async ({ input }) => {
      const history = await getVinHistory(input.vin);
      return {
        hasHistory: !!history && history.length > 0,
        records: history || [],
      };
    }),

  // API status
  apiStatus: publicProcedure.query(() => {
    const hasCredentials = !!(ENV.auctionApiEmail && ENV.auctionApiPassword);
    const hasToken = !!ENV.auctionApiToken;
    const isConfigured = hasCredentials || hasToken;

    return {
      hasAuctionApi: true,
      primarySource: isConfigured ? "auction-api.app" : "autobidcar",
      isConfigured,
      hasJwtAuth: hasCredentials,
      hasStaticToken: hasToken,
      message: isConfigured
        ? "auction-api.app connected — premium Copart/IAAI data with HD photos, live bids, and full history. Uses login→JWT authentication."
        : "AutoBidCar free API connected — Copart/IAAI archive data. Upgrade to auction-api.app for live data and HD photos.",
    };
  }),
});
