import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import {
  siteSettings,
  adminPartsPrices,
  adminAiCostSettings,
  adminFeeSchedules,
  clientAccounts,
  clientSubscriptions,
  pricingPlans,
  vinUsage,
  shippingRates,
} from "../drizzle/schema";
import { eq, and, gte, sql } from "drizzle-orm";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
  return db;
}

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const siteConfigRouter = router({
  // ═══════════════════════════════════════════════════════
  // SITE SETTINGS (key/value feature toggles)
  // ═══════════════════════════════════════════════════════

  /** Get all site settings (admin) */
  getAllSettings: adminProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(siteSettings);
  }),

  /** Get a single setting by key (public — used by frontend to check feature flags) */
  getSetting: publicProcedure
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = await requireDb();
      const [setting] = await db
        .select()
        .from(siteSettings)
        .where(eq(siteSettings.settingKey, input.key));
      return setting ?? null;
    }),

  /** Get multiple settings by keys (public) */
  getSettings: publicProcedure
    .input(z.object({ keys: z.array(z.string()) }))
    .query(async ({ input }) => {
      const db = await requireDb();
      const all = await db.select().from(siteSettings);
      const map: Record<string, string> = {};
      for (const s of all) {
        if (input.keys.includes(s.settingKey)) {
          map[s.settingKey] = s.settingValue;
        }
      }
      return map;
    }),

  /** Upsert a site setting (admin) */
  upsertSetting: adminProcedure
    .input(
      z.object({
        key: z.string(),
        value: z.string(),
        label: z.string().optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      // Try update first
      const [existing] = await db
        .select()
        .from(siteSettings)
        .where(eq(siteSettings.settingKey, input.key));

      if (existing) {
        await db
          .update(siteSettings)
          .set({ settingValue: input.value, label: input.label, category: input.category })
          .where(eq(siteSettings.settingKey, input.key));
      } else {
        await db.insert(siteSettings).values({
          settingKey: input.key,
          settingValue: input.value,
          label: input.label,
          category: input.category ?? "general",
        });
      }
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // ADMIN PARTS PRICES
  // ═══════════════════════════════════════════════════════

  /** Get all admin parts prices */
  getPartsPrices: publicProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(adminPartsPrices);
  }),

  /** Upsert a part price (admin) */
  upsertPartPrice: adminProcedure
    .input(
      z.object({
        partId: z.string(),
        partName: z.string(),
        category: z.string(),
        priceAED: z.number(),
        isActive: z.number().default(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const [existing] = await db
        .select()
        .from(adminPartsPrices)
        .where(eq(adminPartsPrices.partId, input.partId));

      if (existing) {
        await db
          .update(adminPartsPrices)
          .set({
            partName: input.partName,
            category: input.category,
            priceAED: input.priceAED,
            isActive: input.isActive,
          })
          .where(eq(adminPartsPrices.partId, input.partId));
      } else {
        await db.insert(adminPartsPrices).values(input);
      }
      return { success: true };
    }),

  /** Bulk upsert parts prices (admin — for initial seed or bulk edit) */
  bulkUpsertPartsPrices: adminProcedure
    .input(
      z.array(
        z.object({
          partId: z.string(),
          partName: z.string(),
          category: z.string(),
          priceAED: z.number(),
          isActive: z.number().default(1),
        })
      )
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      for (const part of input) {
        const [existing] = await db
          .select()
          .from(adminPartsPrices)
          .where(eq(adminPartsPrices.partId, part.partId));

        if (existing) {
          await db
            .update(adminPartsPrices)
            .set({
              partName: part.partName,
              category: part.category,
              priceAED: part.priceAED,
              isActive: part.isActive,
            })
            .where(eq(adminPartsPrices.partId, part.partId));
        } else {
          await db.insert(adminPartsPrices).values(part);
        }
      }
      return { success: true, count: input.length };
    }),

  /** Delete a part price (admin) */
  deletePartPrice: adminProcedure
    .input(z.object({ partId: z.string() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(adminPartsPrices).where(eq(adminPartsPrices.partId, input.partId));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // AI COST SETTINGS
  // ═══════════════════════════════════════════════════════

  /** Get all AI cost settings */
  getAiCostSettings: publicProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(adminAiCostSettings);
  }),

  /** Upsert an AI cost setting (admin) */
  upsertAiCostSetting: adminProcedure
    .input(
      z.object({
        settingKey: z.string(),
        settingValue: z.string(),
        label: z.string().optional(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const [existing] = await db
        .select()
        .from(adminAiCostSettings)
        .where(eq(adminAiCostSettings.settingKey, input.settingKey));

      if (existing) {
        await db
          .update(adminAiCostSettings)
          .set({
            settingValue: input.settingValue,
            label: input.label,
            description: input.description,
          })
          .where(eq(adminAiCostSettings.settingKey, input.settingKey));
      } else {
        await db.insert(adminAiCostSettings).values(input);
      }
      return { success: true };
    }),

  /** Bulk upsert AI cost settings (admin) */
  bulkUpsertAiCostSettings: adminProcedure
    .input(
      z.array(
        z.object({
          settingKey: z.string(),
          settingValue: z.string(),
          label: z.string().optional(),
          description: z.string().optional(),
        })
      )
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      for (const setting of input) {
        const [existing] = await db
          .select()
          .from(adminAiCostSettings)
          .where(eq(adminAiCostSettings.settingKey, setting.settingKey));

        if (existing) {
          await db
            .update(adminAiCostSettings)
            .set({
              settingValue: setting.settingValue,
              label: setting.label,
              description: setting.description,
            })
            .where(eq(adminAiCostSettings.settingKey, setting.settingKey));
        } else {
          await db.insert(adminAiCostSettings).values(setting);
        }
      }
      return { success: true, count: input.length };
    }),

  // ═══════════════════════════════════════════════════════
  // FEE SCHEDULES (buyer fees, virtual fees, fixed fees, import tax, emirate registration)
  // ═══════════════════════════════════════════════════════

  /** Get all fee schedules (public — used by Fee Guide page) */
  getFeeSchedules: publicProcedure
    .input(z.object({ category: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = await requireDb();
      if (input?.category) {
        return db.select().from(adminFeeSchedules).where(eq(adminFeeSchedules.category, input.category));
      }
      return db.select().from(adminFeeSchedules);
    }),

  /** Upsert a fee schedule entry (admin) */
  upsertFeeSchedule: adminProcedure
    .input(
      z.object({
        category: z.string(),
        feeKey: z.string(),
        label: z.string().optional(),
        value: z.string(), // JSON string
        sortOrder: z.number().default(0),
        isActive: z.number().default(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const [existing] = await db
        .select()
        .from(adminFeeSchedules)
        .where(
          and(
            eq(adminFeeSchedules.category, input.category),
            eq(adminFeeSchedules.feeKey, input.feeKey)
          )
        );

      if (existing) {
        await db
          .update(adminFeeSchedules)
          .set({
            label: input.label,
            value: input.value,
            sortOrder: input.sortOrder,
            isActive: input.isActive,
          })
          .where(eq(adminFeeSchedules.id, existing.id));
      } else {
        await db.insert(adminFeeSchedules).values(input);
      }
      return { success: true };
    }),

  /** Bulk upsert fee schedules (admin — for seeding or bulk edit) */
  bulkUpsertFeeSchedules: adminProcedure
    .input(
      z.array(
        z.object({
          category: z.string(),
          feeKey: z.string(),
          label: z.string().optional(),
          value: z.string(),
          sortOrder: z.number().default(0),
          isActive: z.number().default(1),
        })
      )
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      for (const entry of input) {
        const [existing] = await db
          .select()
          .from(adminFeeSchedules)
          .where(
            and(
              eq(adminFeeSchedules.category, entry.category),
              eq(adminFeeSchedules.feeKey, entry.feeKey)
            )
          );

        if (existing) {
          await db
            .update(adminFeeSchedules)
            .set({
              label: entry.label,
              value: entry.value,
              sortOrder: entry.sortOrder,
              isActive: entry.isActive,
            })
            .where(eq(adminFeeSchedules.id, existing.id));
        } else {
          await db.insert(adminFeeSchedules).values(entry);
        }
      }
      return { success: true, count: input.length };
    }),

  /** Delete a fee schedule entry (admin) */
  deleteFeeSchedule: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(adminFeeSchedules).where(eq(adminFeeSchedules.id, input.id));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // PER-USER VIN LIMIT MANAGEMENT
  // ═══════════════════════════════════════════════════════

  /** Set VIN limit override for a specific user (admin) */
  setUserVinLimit: adminProcedure
    .input(
      z.object({
        accountId: z.number(),
        vinLimitOverride: z.number().nullable(), // null = use plan default
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db
        .update(clientAccounts)
        .set({ vinLimitOverride: input.vinLimitOverride })
        .where(eq(clientAccounts.id, input.accountId));
      return { success: true };
    }),

  /** Add bonus VIN credits to a user (admin) */
  addBonusVinCredits: adminProcedure
    .input(
      z.object({
        accountId: z.number(),
        credits: z.number().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      // Get current bonus credits
      const [account] = await db
        .select({ bonusVinCredits: clientAccounts.bonusVinCredits })
        .from(clientAccounts)
        .where(eq(clientAccounts.id, input.accountId));

      if (!account) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Account not found" });
      }

      const newCredits = (account.bonusVinCredits ?? 0) + input.credits;
      await db
        .update(clientAccounts)
        .set({ bonusVinCredits: newCredits })
        .where(eq(clientAccounts.id, input.accountId));

      return { success: true, newTotal: newCredits };
    }),

  /** Reset bonus VIN credits for a user (admin) */
  resetBonusVinCredits: adminProcedure
    .input(z.object({ accountId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db
        .update(clientAccounts)
        .set({ bonusVinCredits: 0 })
        .where(eq(clientAccounts.id, input.accountId));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // SHIPPING RATES MANAGEMENT
  // ═══════════════════════════════════════════════════════

  /** Get all shipping rates (public — used by Calculator) */
  getShippingRates: publicProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(shippingRates);
  }),

  /** Add a new shipping rate (admin) */
  addShippingRate: adminProcedure
    .input(
      z.object({
        auction: z.enum(["Copart", "IAAI"]),
        state: z.string().min(1).max(10),
        city: z.string().min(1).max(100),
        loadingPort: z.string().min(1).max(10),
        price: z.string(), // decimal as string
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.insert(shippingRates).values(input);
      return { success: true };
    }),

  /** Update a shipping rate (admin) */
  updateShippingRate: adminProcedure
    .input(
      z.object({
        id: z.number(),
        auction: z.enum(["Copart", "IAAI"]).optional(),
        state: z.string().min(1).max(10).optional(),
        city: z.string().min(1).max(100).optional(),
        loadingPort: z.string().min(1).max(10).optional(),
        price: z.string().optional(),
        isActive: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, ...data } = input;
      await db.update(shippingRates).set(data).where(eq(shippingRates.id, id));
      return { success: true };
    }),

  /** Delete a shipping rate (admin) */
  deleteShippingRate: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(shippingRates).where(eq(shippingRates.id, input.id));
      return { success: true };
    }),

  /** Bulk import shipping rates from hardcoded data (admin — one-time seed) */
  bulkImportShippingRates: adminProcedure
    .input(
      z.array(
        z.object({
          auction: z.enum(["Copart", "IAAI"]),
          state: z.string(),
          city: z.string(),
          loadingPort: z.string(),
          price: z.string(),
        })
      )
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      // Insert in batches of 50
      for (let i = 0; i < input.length; i += 50) {
        const batch = input.slice(i, i + 50);
        await db.insert(shippingRates).values(batch);
      }
      return { success: true, count: input.length };
    }),

  /** Enhanced VIN quota check — uses override > plan default > free trial + bonus credits */
  getEnhancedVinQuota: publicProcedure
    .input(z.object({ accountId: z.number() }))
    .query(async ({ input }) => {
      const db = await requireDb();

      // Get account with override and bonus
      const [account] = await db
        .select({
          vinLimitOverride: clientAccounts.vinLimitOverride,
          bonusVinCredits: clientAccounts.bonusVinCredits,
        })
        .from(clientAccounts)
        .where(eq(clientAccounts.id, input.accountId));

      if (!account) {
        return { limit: 3, used: 0, remaining: 3, bonus: 0, hasSubscription: false, planName: "Free Trial", source: "default" as const };
      }

      // Determine base limit
      let baseLimit = 3; // Free trial default
      let planName = "Free Trial";
      let hasSubscription = false;
      let source: "override" | "plan" | "default" = "default";

      if (account.vinLimitOverride !== null && account.vinLimitOverride !== undefined) {
        // Admin override takes priority
        baseLimit = account.vinLimitOverride;
        source = "override";
        planName = "Custom Limit";
      } else {
        // Check subscription plan
        const [subscription] = await db
          .select()
          .from(clientSubscriptions)
          .where(
            and(
              eq(clientSubscriptions.accountId, input.accountId),
              eq(clientSubscriptions.status, "active")
            )
          );

        if (subscription) {
          hasSubscription = true;
          const [plan] = await db
            .select()
            .from(pricingPlans)
            .where(eq(pricingPlans.id, subscription.planId));
          if (plan) {
            baseLimit = plan.vinLimitPerMonth === 0 ? 999999 : plan.vinLimitPerMonth;
            planName = plan.name;
            source = "plan";
          }
        }
      }

      // Add bonus credits
      const bonus = account.bonusVinCredits ?? 0;
      const totalLimit = baseLimit + bonus;

      // Count VIN searches this month
      const firstOfMonth = new Date();
      firstOfMonth.setDate(1);
      firstOfMonth.setHours(0, 0, 0, 0);
      const [usage] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(vinUsage)
        .where(
          and(
            eq(vinUsage.accountId, input.accountId),
            gte(vinUsage.createdAt, firstOfMonth)
          )
        );

      const used = usage?.count ?? 0;
      return {
        limit: totalLimit,
        baseLimit,
        used,
        remaining: Math.max(0, totalLimit - used),
        bonus,
        hasSubscription,
        planName,
        source,
      };
    }),
});
