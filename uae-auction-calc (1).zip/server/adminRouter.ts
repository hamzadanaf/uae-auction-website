import { z } from "zod";
import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import {
  pricingPlans,
  clientAccounts,
  vinUsage,
  clientSubscriptions,
} from "../drizzle/schema";
import { eq, sql, desc, and, gte } from "drizzle-orm";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
  return db;
}

/**
 * Admin-only middleware: checks that the user is an admin (either Manus OAuth admin or client admin)
 */
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const adminRouter = router({
  // ─── Pricing Plans ────────────────────────────────────────

  /** Get all pricing plans (public — for pricing page) */
  getPlans: publicProcedure.query(async () => {
    const db = await requireDb();
    const plans = await db
      .select()
      .from(pricingPlans)
      .orderBy(pricingPlans.sortOrder);
    return plans.map((p) => ({
      ...p,
      features: JSON.parse(p.features || "[]") as string[],
    }));
  }),

  /** Get active pricing plans only (for public pricing page) */
  getActivePlans: publicProcedure.query(async () => {
    const db = await requireDb();
    const plans = await db
      .select()
      .from(pricingPlans)
      .where(eq(pricingPlans.isActive, 1))
      .orderBy(pricingPlans.sortOrder);
    return plans.map((p) => ({
      ...p,
      features: JSON.parse(p.features || "[]") as string[],
    }));
  }),

  /** Update a pricing plan (admin only) */
  updatePlan: adminProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        priceMonthlyAED: z.number().optional(),
        priceAnnualAED: z.number().optional(),
        vinLimitPerMonth: z.number().optional(),
        features: z.array(z.string()).optional(),
        isActive: z.number().optional(),
        isPopular: z.number().optional(),
        sortOrder: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, features, ...rest } = input;
      const updateData: Record<string, unknown> = { ...rest };
      if (features !== undefined) {
        updateData.features = JSON.stringify(features);
      }
      await db.update(pricingPlans).set(updateData).where(eq(pricingPlans.id, id));
      return { success: true };
    }),

  /** Create a new pricing plan (admin only) */
  createPlan: adminProcedure
    .input(
      z.object({
        name: z.string(),
        slug: z.string(),
        description: z.string().optional(),
        priceMonthlyAED: z.number(),
        priceAnnualAED: z.number(),
        vinLimitPerMonth: z.number(),
        features: z.array(z.string()),
        isActive: z.number().default(1),
        isPopular: z.number().default(0),
        sortOrder: z.number().default(0),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { features, ...rest } = input;
      await db.insert(pricingPlans).values({
        ...rest,
        features: JSON.stringify(features),
      });
      return { success: true };
    }),

  /** Delete a pricing plan (admin only) */
  deletePlan: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(pricingPlans).where(eq(pricingPlans.id, input.id));
      return { success: true };
    }),

  // ─── Dashboard Stats ──────────────────────────────────────

  /** Get admin dashboard overview stats */
  getDashboardStats: adminProcedure.query(async () => {
    const db = await requireDb();

    // Total clients
    const [totalClients] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(clientAccounts);

    // Active clients (approved)
    const [activeClients] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(clientAccounts)
      .where(eq(clientAccounts.status, "approved"));

    // Pending approvals
    const [pendingClients] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(clientAccounts)
      .where(eq(clientAccounts.status, "pending"));

    // Total VIN searches
    const [totalVinSearches] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(vinUsage);

    // VIN searches this month
    const firstOfMonth = new Date();
    firstOfMonth.setDate(1);
    firstOfMonth.setHours(0, 0, 0, 0);
    const [monthlyVinSearches] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(vinUsage)
      .where(gte(vinUsage.createdAt, firstOfMonth));

    // Active subscriptions
    const [activeSubscriptions] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(clientSubscriptions)
      .where(eq(clientSubscriptions.status, "active"));

    // Monthly revenue (sum of active subscriptions)
    const [monthlyRevenue] = await db
      .select({ total: sql<number>`COALESCE(SUM(amountAED), 0)` })
      .from(clientSubscriptions)
      .where(eq(clientSubscriptions.status, "active"));

    return {
      totalClients: totalClients?.count ?? 0,
      activeClients: activeClients?.count ?? 0,
      pendingClients: pendingClients?.count ?? 0,
      totalVinSearches: totalVinSearches?.count ?? 0,
      monthlyVinSearches: monthlyVinSearches?.count ?? 0,
      activeSubscriptions: activeSubscriptions?.count ?? 0,
      monthlyRevenueAED: monthlyRevenue?.total ?? 0,
    };
  }),

  /** Get per-client usage stats */
  getClientUsageStats: adminProcedure.query(async () => {
    const db = await requireDb();
    const clients = await db
      .select({
        id: clientAccounts.id,
        username: clientAccounts.username,
        displayName: clientAccounts.displayName,
        email: clientAccounts.email,
        status: clientAccounts.status,
        role: clientAccounts.role,
        lastLoginAt: clientAccounts.lastLoginAt,
        createdAt: clientAccounts.createdAt,
      })
      .from(clientAccounts)
      .orderBy(desc(clientAccounts.createdAt));

    // Get VIN usage count per client
    const usageCounts = await db
      .select({
        accountId: vinUsage.accountId,
        count: sql<number>`COUNT(*)`,
      })
      .from(vinUsage)
      .groupBy(vinUsage.accountId);

    const usageMap = new Map(usageCounts.map((u) => [u.accountId, u.count]));

    return clients.map((c) => ({
      ...c,
      vinSearches: usageMap.get(c.id) ?? 0,
    }));
  }),

  // ─── VIN Quota ────────────────────────────────────────────

  /** Check remaining VIN quota for a client */
  getVinQuota: publicProcedure
    .input(z.object({ accountId: z.number() }))
    .query(async ({ input }) => {
      const db = await requireDb();

      // Check if client has an active subscription
      const [subscription] = await db
        .select()
        .from(clientSubscriptions)
        .where(
          and(
            eq(clientSubscriptions.accountId, input.accountId),
            eq(clientSubscriptions.status, "active")
          )
        );

      let vinLimit = 3; // Free trial: 3 VINs
      if (subscription) {
        const [plan] = await db
          .select()
          .from(pricingPlans)
          .where(eq(pricingPlans.id, subscription.planId));
        if (plan) {
          vinLimit = plan.vinLimitPerMonth === 0 ? 999999 : plan.vinLimitPerMonth;
        }
      }

      // Count VIN searches this month
      const firstOfMonth = new Date();
      firstOfMonth.setDate(1);
      firstOfMonth.setHours(0, 0, 0, 0);
      const [usage] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(vinUsage)
        .where(
          and(
            eq(vinUsage.accountId, input.accountId),
            gte(vinUsage.createdAt, firstOfMonth)
          )
        );

      const used = usage?.count ?? 0;
      return {
        limit: vinLimit,
        used,
        remaining: Math.max(0, vinLimit - used),
        hasSubscription: !!subscription,
        planName: subscription ? "Subscribed" : "Free Trial",
      };
    }),

  /** Record a VIN usage */
  trackVinUsage: publicProcedure
    .input(
      z.object({
        accountId: z.number(),
        vin: z.string(),
        actionType: z.string().default("vin_search"),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.insert(vinUsage).values({
        accountId: input.accountId,
        vin: input.vin,
        actionType: input.actionType,
      });
      return { success: true };
    }),
});
