import { describe, it, expect } from "vitest";

// We test the shared modules directly
import { findShippingRate, getStateList, getCitiesForState } from "../shared/shippingData";

describe("Shipping Data Helpers", () => {
  it("getStateList should return a sorted list of states", () => {
    const states = getStateList();
    expect(states.length).toBeGreaterThan(10);
    // Should be sorted alphabetically
    for (let i = 1; i < states.length; i++) {
      expect(states[i].state.localeCompare(states[i - 1].state)).toBeGreaterThanOrEqual(0);
    }
    // Each state should have avgPrice and count
    for (const s of states) {
      expect(s.avgPrice).toBeGreaterThan(0);
      expect(s.count).toBeGreaterThan(0);
    }
  });

  it("getCitiesForState should return cities for a valid state", () => {
    const cities = getCitiesForState("FL");
    expect(cities.length).toBeGreaterThan(0);
    // Each city should have auction, state, city, loadingPort, price
    for (const c of cities) {
      expect(c.state).toBe("FL");
      expect(c.city).toBeTruthy();
      expect(c.price).toBeGreaterThan(0);
    }
  });

  it("getCitiesForState should filter by auction when specified", () => {
    const copartCities = getCitiesForState("FL", "copart");
    const iaaiCities = getCitiesForState("FL", "iaai");
    expect(copartCities.length).toBeGreaterThan(0);
    expect(iaaiCities.length).toBeGreaterThan(0);
    // All copart cities should be Copart
    for (const c of copartCities) {
      expect(c.auction).toBe("Copart");
    }
    // All iaai cities should be IAAI
    for (const c of iaaiCities) {
      expect(c.auction).toBe("IAAI");
    }
  });

  it("getCitiesForState should return empty for invalid state", () => {
    const cities = getCitiesForState("ZZ");
    expect(cities.length).toBe(0);
  });

  it("findShippingRate should find a known rate", () => {
    const rate = findShippingRate("Copart", "FL", "Miami South");
    expect(rate).not.toBeNull();
    expect(rate!.price).toBeGreaterThan(0);
    expect(rate!.state).toBe("FL");
  });

  it("findShippingRate should fall back to state average", () => {
    const rate = findShippingRate("Copart", "FL", "Nonexistent City");
    expect(rate).not.toBeNull();
    expect(rate!.city).toBe("State Average");
    expect(rate!.price).toBeGreaterThan(0);
  });
});

// Test the shipping rates count via the imported module
import { SHIPPING_RATES } from "../shared/shippingData";

describe("Market Price Database", () => {
  it("shipping rates database should have 382+ entries", () => {
    expect(SHIPPING_RATES.length).toBeGreaterThanOrEqual(380);
  });
});
