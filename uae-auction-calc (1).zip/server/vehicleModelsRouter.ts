import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { vehicleModels } from "../drizzle/schema";
import { eq, like, and, or, sql, desc, asc } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";

export const vehicleModelsRouter = router({
  /**
   * Get all unique brands with model counts (for brand grid)
   */
  getBrands: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const result = await db
      .select({
        brand: vehicleModels.brand,
        modelCount: sql<number>`COUNT(DISTINCT ${vehicleModels.model})`.as("modelCount"),
        totalRows: sql<number>`COUNT(*)`.as("totalRows"),
        region: vehicleModels.region,
        brandLogoUrl: vehicleModels.brandLogoUrl,
        dubizzleBrandSlug: vehicleModels.dubizzleBrandSlug,
        minYear: sql<number>`MIN(${vehicleModels.year})`.as("minYear"),
        maxYear: sql<number>`MAX(${vehicleModels.year})`.as("maxYear"),
      })
      .from(vehicleModels)
      .where(eq(vehicleModels.isActive, 1))
      .groupBy(vehicleModels.brand, vehicleModels.region, vehicleModels.brandLogoUrl, vehicleModels.dubizzleBrandSlug)
      .orderBy(asc(vehicleModels.brand));

    return result;
  }),

  /**
   * Get all models for a specific brand, grouped by model with per-year pricing
   */
  getModelsByBrand: publicProcedure
    .input(z.object({ brand: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select()
        .from(vehicleModels)
        .where(
          and(
            eq(vehicleModels.isActive, 1),
            sql`LOWER(${vehicleModels.brand}) = LOWER(${input.brand})`
          )
        )
        .orderBy(asc(vehicleModels.model), asc(vehicleModels.year));

      // Group by model name
      const grouped: Record<string, {
        model: string;
        category: string;
        region: string;
        dubizzleBrandSlug: string | null;
        dubizzleModelSlug: string | null;
        years: Array<{
          id: number;
          year: number;
          uaeMarketPriceLow: number | null;
          uaeMarketPriceMid: number | null;
          uaeMarketPriceHigh: number | null;
          auctionAvgPriceUSD: number | null;
        }>;
      }> = {};

      for (const row of result) {
        if (!grouped[row.model]) {
          grouped[row.model] = {
            model: row.model,
            category: row.category,
            region: row.region,
            dubizzleBrandSlug: row.dubizzleBrandSlug,
            dubizzleModelSlug: row.dubizzleModelSlug,
            years: [],
          };
        }
        grouped[row.model].years.push({
          id: row.id,
          year: row.year,
          uaeMarketPriceLow: row.uaeMarketPriceLow,
          uaeMarketPriceMid: row.uaeMarketPriceMid,
          uaeMarketPriceHigh: row.uaeMarketPriceHigh,
          auctionAvgPriceUSD: row.auctionAvgPriceUSD,
        });
      }

      return Object.values(grouped);
    }),

  /**
   * Search models by brand, model name, or category
   * Returns distinct model entries (not per-year rows)
   */
  searchModels: publicProcedure
    .input(
      z.object({
        query: z.string().optional(),
        region: z.string().optional(),
        category: z.string().optional(),
        year: z.number().optional(),
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const conditions = [eq(vehicleModels.isActive, 1)];

      if (input.query) {
        const q = `%${input.query}%`;
        conditions.push(
          or(
            like(vehicleModels.brand, q),
            like(vehicleModels.model, q)
          )!
        );
      }

      if (input.region) {
        conditions.push(sql`${vehicleModels.region} = ${input.region}`);
      }

      if (input.category) {
        conditions.push(sql`${vehicleModels.category} = ${input.category}`);
      }

      if (input.year) {
        conditions.push(eq(vehicleModels.year, input.year));
      }

      const [results, countResult] = await Promise.all([
        db
          .select()
          .from(vehicleModels)
          .where(and(...conditions))
          .orderBy(asc(vehicleModels.brand), asc(vehicleModels.model), asc(vehicleModels.year))
          .limit(input.limit)
          .offset(input.offset),
        db
          .select({ count: sql<number>`COUNT(*)` })
          .from(vehicleModels)
          .where(and(...conditions)),
      ]);

      return {
        models: results,
        total: countResult[0]?.count ?? 0,
      };
    }),

  /**
   * Match a VIN-decoded vehicle to a model in the database
   * Now matches by exact year for accurate per-year pricing
   */
  matchVinToModel: publicProcedure
    .input(
      z.object({
        make: z.string(),
        model: z.string(),
        year: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const makeLower = input.make.toLowerCase().trim();
      const modelLower = input.model.toLowerCase().trim();

      // Build conditions: brand + model + optional year
      const baseConditions = [
        eq(vehicleModels.isActive, 1),
        sql`LOWER(${vehicleModels.brand}) = ${makeLower}`,
      ];

      // Try exact brand + model + year match first
      if (input.year) {
        const exactResults = await db
          .select()
          .from(vehicleModels)
          .where(
            and(
              ...baseConditions,
              sql`LOWER(${vehicleModels.model}) = ${modelLower}`,
              eq(vehicleModels.year, input.year)
            )
          )
          .limit(1);

        if (exactResults.length > 0) {
          return {
            match: exactResults[0],
            suggestions: [],
            matchType: "exact" as const,
          };
        }
      }

      // Try fuzzy model match with year
      if (input.year) {
        const fuzzyResults = await db
          .select()
          .from(vehicleModels)
          .where(
            and(
              ...baseConditions,
              like(vehicleModels.model, `%${modelLower}%`),
              eq(vehicleModels.year, input.year)
            )
          )
          .limit(1);

        if (fuzzyResults.length > 0) {
          return {
            match: fuzzyResults[0],
            suggestions: [],
            matchType: "fuzzy" as const,
          };
        }
      }

      // Try exact model match without year (get closest year)
      const modelResults = await db
        .select()
        .from(vehicleModels)
        .where(
          and(
            ...baseConditions,
            sql`LOWER(${vehicleModels.model}) = ${modelLower}`
          )
        )
        .orderBy(desc(vehicleModels.year))
        .limit(1);

      if (modelResults.length > 0) {
        return {
          match: modelResults[0],
          suggestions: [],
          matchType: "model_only" as const,
        };
      }

      // Try brand only — return top models for that brand
      const brandResults = await db
        .select()
        .from(vehicleModels)
        .where(and(...baseConditions))
        .orderBy(desc(vehicleModels.year))
        .limit(5);

      if (brandResults.length > 0) {
        return {
          match: null,
          suggestions: brandResults,
          matchType: "brand_only" as const,
        };
      }

      return {
        match: null,
        suggestions: [],
        matchType: "none" as const,
      };
    }),

  /**
   * Get a single model by ID
   */
  getModelById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select()
        .from(vehicleModels)
        .where(eq(vehicleModels.id, input.id))
        .limit(1);

      return result[0] ?? null;
    }),

  /**
   * Get all years for a specific brand + model (for year picker)
   */
  getYearsForModel: publicProcedure
    .input(z.object({ brand: z.string(), model: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select({
          id: vehicleModels.id,
          year: vehicleModels.year,
          uaeMarketPriceLow: vehicleModels.uaeMarketPriceLow,
          uaeMarketPriceMid: vehicleModels.uaeMarketPriceMid,
          uaeMarketPriceHigh: vehicleModels.uaeMarketPriceHigh,
          auctionAvgPriceUSD: vehicleModels.auctionAvgPriceUSD,
          dubizzleBrandSlug: vehicleModels.dubizzleBrandSlug,
          dubizzleModelSlug: vehicleModels.dubizzleModelSlug,
        })
        .from(vehicleModels)
        .where(
          and(
            eq(vehicleModels.isActive, 1),
            sql`LOWER(${vehicleModels.brand}) = LOWER(${input.brand})`,
            sql`LOWER(${vehicleModels.model}) = LOWER(${input.model})`
          )
        )
        .orderBy(asc(vehicleModels.year));

      return result;
    }),

  /**
   * Admin: Add a new vehicle model (single year entry)
   */
  addModel: publicProcedure
    .input(
      z.object({
        brand: z.string(),
        model: z.string(),
        trims: z.string().optional(),
        region: z.enum(["american", "japanese", "european", "korean"]),
        category: z.enum([
          "sedan", "suv", "truck", "coupe", "hatchback",
          "van", "electric", "sports", "luxury", "crossover",
        ]),
        year: z.number(),
        uaeMarketPriceLow: z.number().nullable().optional(),
        uaeMarketPriceMid: z.number().nullable().optional(),
        uaeMarketPriceHigh: z.number().nullable().optional(),
        auctionAvgPriceUSD: z.number().nullable().optional(),
        dubizzleBrandSlug: z.string().optional(),
        dubizzleModelSlug: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(vehicleModels).values({
        brand: input.brand,
        model: input.model,
        trims: input.trims ?? null,
        region: input.region,
        category: input.category,
        year: input.year,
        uaeMarketPriceLow: input.uaeMarketPriceLow ?? null,
        uaeMarketPriceMid: input.uaeMarketPriceMid ?? null,
        uaeMarketPriceHigh: input.uaeMarketPriceHigh ?? null,
        auctionAvgPriceUSD: input.auctionAvgPriceUSD ?? null,
        dubizzleBrandSlug: input.dubizzleBrandSlug ?? null,
        dubizzleModelSlug: input.dubizzleModelSlug ?? null,
      });

      return { success: true, id: result[0].insertId };
    }),

  /**
   * Admin: Update a vehicle model
   */
  updateModel: publicProcedure
    .input(
      z.object({
        id: z.number(),
        uaeMarketPriceLow: z.number().nullable().optional(),
        uaeMarketPriceMid: z.number().nullable().optional(),
        uaeMarketPriceHigh: z.number().nullable().optional(),
        auctionAvgPriceUSD: z.number().nullable().optional(),
        trims: z.string().nullable().optional(),
        isActive: z.number().optional(),
        category: z.string().optional(),
        year: z.number().optional(),
        dubizzleBrandSlug: z.string().nullable().optional(),
        dubizzleModelSlug: z.string().nullable().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const { id, ...updates } = input;
      const cleanUpdates: Record<string, any> = {};
      for (const [key, value] of Object.entries(updates)) {
        if (value !== undefined) cleanUpdates[key] = value;
      }

      if (Object.keys(cleanUpdates).length === 0) {
        return { success: false, message: "No fields to update" };
      }

      await db
        .update(vehicleModels)
        .set(cleanUpdates)
        .where(eq(vehicleModels.id, id));

      return { success: true };
    }),

  /**
   * Admin: Delete a vehicle model
   */
  deleteModel: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.delete(vehicleModels).where(eq(vehicleModels.id, input.id));
      return { success: true };
    }),

  /**
   * Admin: Auto-update prices for a specific model-year using LLM
   */
  autoUpdatePrice: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const model = await db
        .select()
        .from(vehicleModels)
        .where(eq(vehicleModels.id, input.id))
        .limit(1);

      if (!model[0]) throw new Error("Model not found");

      const m = model[0];
      const prompt = `You are a UAE car market pricing expert. Estimate the current UAE market price range (in AED) for a ${m.year} ${m.brand} ${m.model}.

Consider:
- UAE import market (cars imported from US auctions)
- Clean title, average condition
- Current 2025-2026 market conditions in UAE
- This is a ${m.year} model year specifically

Return ONLY a JSON object with these fields:
{
  "low": <number - lowest typical price in AED>,
  "mid": <number - average market price in AED>,
  "high": <number - highest typical price in AED>,
  "auctionAvgUSD": <number - average US auction price in USD>
}

No explanation, just the JSON.`;

      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are a car market pricing expert specializing in UAE import market." },
            { role: "user", content: prompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "price_estimate",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  low: { type: "integer", description: "Low price in AED" },
                  mid: { type: "integer", description: "Mid price in AED" },
                  high: { type: "integer", description: "High price in AED" },
                  auctionAvgUSD: { type: "integer", description: "Average US auction price in USD" },
                },
                required: ["low", "mid", "high", "auctionAvgUSD"],
                additionalProperties: false,
              },
            },
          },
        });

        const rawContent = response.choices?.[0]?.message?.content;
        if (!rawContent || typeof rawContent !== 'string') throw new Error("No response from LLM");

        const prices = JSON.parse(rawContent);

        await db
          .update(vehicleModels)
          .set({
            uaeMarketPriceLow: prices.low,
            uaeMarketPriceMid: prices.mid,
            uaeMarketPriceHigh: prices.high,
            auctionAvgPriceUSD: prices.auctionAvgUSD,
            pricesUpdatedAt: new Date(),
          })
          .where(eq(vehicleModels.id, input.id));

        return {
          success: true,
          prices: {
            low: prices.low,
            mid: prices.mid,
            high: prices.high,
            auctionAvgUSD: prices.auctionAvgUSD,
          },
        };
      } catch (error: any) {
        return {
          success: false,
          message: error.message || "Failed to auto-update prices",
        };
      }
    }),

  /**
   * Get statistics about the vehicle models database
   */
  getStats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const [stats] = await db
      .select({
        totalRows: sql<number>`COUNT(*)`,
        totalBrands: sql<number>`COUNT(DISTINCT ${vehicleModels.brand})`,
        totalModels: sql<number>`COUNT(DISTINCT CONCAT(${vehicleModels.brand}, '-', ${vehicleModels.model}))`,
        avgPrice: sql<number>`AVG(${vehicleModels.uaeMarketPriceMid})`,
        withPrices: sql<number>`SUM(CASE WHEN ${vehicleModels.uaeMarketPriceMid} IS NOT NULL THEN 1 ELSE 0 END)`,
        minYear: sql<number>`MIN(${vehicleModels.year})`,
        maxYear: sql<number>`MAX(${vehicleModels.year})`,
      })
      .from(vehicleModels)
      .where(eq(vehicleModels.isActive, 1));

    return stats;
  }),
});
