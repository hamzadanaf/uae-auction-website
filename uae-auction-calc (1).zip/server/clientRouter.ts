import { z } from "zod";
import { publicProcedure, router, protectedProcedure, adminProcedure } from "./_core/trpc";
import {
  createClientAccount,
  getClientAccountByUsername,
  getClientAccountByEmail,
  getClientAccountByPhone,
  getClientAccountById,
  listClientAccountsByAdmin,
  listAllClientAccounts,
  updateClientAccount,
  deleteClientAccount,
  updateLastLogin,
} from "./clientAccounts";
import bcrypt from "bcryptjs";
import { SignJWT } from "jose";
import { ENV } from "./_core/env";
import { CLIENT_COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";

const SALT_ROUNDS = 10;

/**
 * UAE phone number regex: +971 followed by 2-digit operator code + 7-digit number
 * Valid formats: +971501234567, +971551234567, etc.
 * Accepts with or without leading +
 */
const UAE_PHONE_REGEX = /^\+?971(5[0-9])\d{7}$/;

/**
 * Normalize a UAE phone number to +971XXXXXXXXX format
 */
function normalizeUAEPhone(phone: string): string {
  // Remove spaces, dashes, parentheses
  let cleaned = phone.replace(/[\s\-\(\)]/g, "");
  // If starts with 0, replace with +971
  if (cleaned.startsWith("05")) {
    cleaned = "+971" + cleaned.slice(1);
  }
  // Ensure + prefix
  if (cleaned.startsWith("971")) {
    cleaned = "+" + cleaned;
  }
  return cleaned;
}

/**
 * Create a JWT for client session authentication.
 * This token is stored as an httpOnly cookie so tRPC procedures can read it.
 */
async function createClientSessionToken(accountId: number, role: string): Promise<string> {
  const secret = new TextEncoder().encode(ENV.cookieSecret);
  const expiresInMs = ONE_YEAR_MS;
  const expirationSeconds = Math.floor((Date.now() + expiresInMs) / 1000);

  return new SignJWT({ accountId, role })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(secret);
}

/**
 * In-memory store for password reset OTP tokens.
 * In production, use a database table or Redis for persistence.
 */
const resetTokenStore = new Map<
  string,
  { otp: string; accountId: number; expiresAt: number }
>();

/**
 * In-memory store for registration OTP verification.
 * Key: normalized phone number, Value: { otp, expiresAt, attempts }
 * OTP expires after 5 minutes. Max 3 verification attempts.
 * In production, replace with Twilio Verify or similar SMS service.
 */
const registrationOtpStore = new Map<
  string,
  { otp: string; expiresAt: number; attempts: number; verified: boolean }
>();

/** Rate limit: max 1 OTP request per phone per 60 seconds */
const otpCooldownStore = new Map<string, number>();

const OTP_EXPIRY_MS = 5 * 60 * 1000; // 5 minutes
const OTP_COOLDOWN_MS = 60 * 1000; // 60 seconds between resends
const MAX_OTP_ATTEMPTS = 5;

export const clientRouter = router({
  /**
   * Client login with phone number (or username) + password
   * Sets an httpOnly JWT cookie for server-side auth + returns account info for frontend state
   */
  login: publicProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Try to find by phone number first, then by username
      let account = await getClientAccountByPhone(normalizeUAEPhone(input.username));
      if (!account) {
        account = await getClientAccountByUsername(input.username);
      }

      if (!account || !account.isActive) {
        throw new Error("Invalid username or password");
      }

      // Check account status
      if (account.status === "pending") {
        throw new Error("Your account is pending approval. Please wait for admin approval.");
      }
      if (account.status === "rejected") {
        throw new Error("Your account has been rejected. Please contact the administrator.");
      }

      const passwordMatch = await bcrypt.compare(input.password, account.passwordHash);
      if (!passwordMatch) {
        throw new Error("Invalid username or password");
      }

      // Update last login
      await updateLastLogin(account.id);

      // Set httpOnly JWT cookie for server-side auth
      const token = await createClientSessionToken(account.id, account.role);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(CLIENT_COOKIE_NAME, token, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      // Return account info (without password hash)
      return {
        id: account.id,
        username: account.username,
        displayName: account.displayName,
        email: account.email,
        phoneNumber: account.phoneNumber,
        role: account.role,
      };
    }),

  /**
   * Client logout — clear the client session cookie
   */
  clientLogout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(CLIENT_COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true };
  }),

  /**
   * Get current client's account details (for the account popover)
   */
  getMyAccount: protectedProcedure.query(async ({ ctx }) => {
    const account = await getClientAccountById(ctx.user.id);
    if (!account) throw new Error("Account not found");
    return {
      id: account.id,
      username: account.username,
      displayName: account.displayName,
      email: account.email,
      phoneNumber: account.phoneNumber,
      role: account.role,
      createdAt: account.createdAt,
      lastLoginAt: account.lastLoginAt,
    };
  }),

  /**
   * Client: Change own password
   */
  changePassword: protectedProcedure
    .input(
      z.object({
        currentPassword: z.string().min(6),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const account = await getClientAccountById(ctx.user.id);
      if (!account) throw new Error("Account not found");

      // Verify current password
      const passwordMatch = await bcrypt.compare(input.currentPassword, account.passwordHash);
      if (!passwordMatch) {
        throw new Error("Current password is incorrect");
      }

      // Hash new password and update
      const newPasswordHash = await bcrypt.hash(input.newPassword, SALT_ROUNDS);
      await updateClientAccount(account.id, { passwordHash: newPasswordHash });

      return { success: true, message: "Password changed successfully" };
    }),

  /**
   * Admin: Create a new client account
   */
  createAccount: adminProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(6),
        displayName: z.string().optional(),
        email: z.string().email().optional(),
        phoneNumber: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Check if username already exists
      const existing = await getClientAccountByUsername(input.username);
      if (existing) {
        throw new Error("Username already exists");
      }

      // If phone number provided, validate and check uniqueness
      let normalizedPhone: string | null = null;
      if (input.phoneNumber) {
        normalizedPhone = normalizeUAEPhone(input.phoneNumber);
        if (!UAE_PHONE_REGEX.test(normalizedPhone)) {
          throw new Error("Invalid UAE phone number. Must be +971 followed by 9 digits (e.g., +971501234567)");
        }
        const existingPhone = await getClientAccountByPhone(normalizedPhone);
        if (existingPhone) {
          throw new Error("An account with this phone number already exists");
        }
      }

      // Hash password
      const passwordHash = await bcrypt.hash(input.password, SALT_ROUNDS);

      // Create account
      const account = await createClientAccount({
        username: input.username,
        passwordHash,
        displayName: input.displayName || null,
        email: input.email || null,
        phoneNumber: normalizedPhone,
        createdByUserId: ctx.user.id,
        isActive: 1,
      });

      return {
        id: account.id,
        username: account.username,
        displayName: account.displayName,
        email: account.email,
        phoneNumber: account.phoneNumber,
        isActive: Boolean(account.isActive),
        createdAt: account.createdAt,
      };
    }),

  /**
   * Admin: List all client accounts they created
   */
  listAccounts: adminProcedure.query(async ({ ctx }) => {
    const accounts = await listClientAccountsByAdmin(ctx.user.id);
    return accounts.map((acc) => ({
      id: acc.id,
      username: acc.username,
      displayName: acc.displayName,
      email: acc.email,
      phoneNumber: acc.phoneNumber,
      isActive: Boolean(acc.isActive),
      createdAt: acc.createdAt,
      lastLoginAt: acc.lastLoginAt,
    }));
  }),

  /**
   * Admin: Update a client account
   */
  updateAccount: adminProcedure
    .input(
      z.object({
        id: z.number(),
        displayName: z.string().optional(),
        email: z.string().email().optional(),
        phoneNumber: z.string().optional(),
        isActive: z.boolean().optional(),
        password: z.string().min(6).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const updateData: any = {};
      if (input.displayName !== undefined) updateData.displayName = input.displayName;
      if (input.email !== undefined) updateData.email = input.email;
      if (input.isActive !== undefined) updateData.isActive = input.isActive ? 1 : 0;
      if (input.password) {
        updateData.passwordHash = await bcrypt.hash(input.password, SALT_ROUNDS);
      }

      // If phone number provided, validate and check uniqueness
      if (input.phoneNumber !== undefined) {
        if (input.phoneNumber) {
          const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
          if (!UAE_PHONE_REGEX.test(normalizedPhone)) {
            throw new Error("Invalid UAE phone number. Must be +971 followed by 9 digits (e.g., +971501234567)");
          }
          const existingPhone = await getClientAccountByPhone(normalizedPhone);
          if (existingPhone && existingPhone.id !== input.id) {
            throw new Error("An account with this phone number already exists");
          }
          updateData.phoneNumber = normalizedPhone;
        } else {
          updateData.phoneNumber = null;
        }
      }

      const updated = await updateClientAccount(input.id, updateData);
      if (!updated) throw new Error("Failed to update account");

      return {
        id: updated.id,
        username: updated.username,
        displayName: updated.displayName,
        email: updated.email,
        phoneNumber: updated.phoneNumber,
        isActive: Boolean(updated.isActive),
      };
    }),

  /**
   * Public: Send OTP to a UAE phone number for registration verification.
   * In dev mode, the OTP is returned in the response.
   * In production, this would send a real SMS via Twilio/WhatsApp.
   */
  sendRegistrationOtp: publicProcedure
    .input(z.object({ phoneNumber: z.string() }))
    .mutation(async ({ input }) => {
      const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
      if (!UAE_PHONE_REGEX.test(normalizedPhone)) {
        throw new Error("Invalid UAE phone number. Must be a valid +971 number (e.g., +971501234567 or 0501234567)");
      }

      // Check if phone number already registered
      const existingPhone = await getClientAccountByPhone(normalizedPhone);
      if (existingPhone) {
        throw new Error("An account with this phone number already exists");
      }

      // Rate limit: 1 OTP per 60 seconds per phone
      const lastSent = otpCooldownStore.get(normalizedPhone);
      if (lastSent && Date.now() - lastSent < OTP_COOLDOWN_MS) {
        const remainingSec = Math.ceil((OTP_COOLDOWN_MS - (Date.now() - lastSent)) / 1000);
        throw new Error(`Please wait ${remainingSec} seconds before requesting a new code.`);
      }

      // Generate 6-digit OTP
      const otp = String(Math.floor(100000 + Math.random() * 900000));

      // Store OTP with expiry
      registrationOtpStore.set(normalizedPhone, {
        otp,
        expiresAt: Date.now() + OTP_EXPIRY_MS,
        attempts: 0,
        verified: false,
      });
      otpCooldownStore.set(normalizedPhone, Date.now());

      // TODO: In production, send real SMS here via Twilio/WhatsApp
      // await sendSMS(normalizedPhone, `Your UAE AuctionCalc verification code is: ${otp}`);
      console.log(`[Registration OTP] Code for ${normalizedPhone}: ${otp}`);

      return {
        success: true,
        message: "Verification code sent to your phone.",
        // Dev mode: return OTP on screen (remove in production)
        _devOtp: otp,
        expiresInSeconds: Math.floor(OTP_EXPIRY_MS / 1000),
      };
    }),

  /**
   * Public: Verify the OTP code sent during registration.
   * Must be called before register to prove phone ownership.
   */
  verifyRegistrationOtp: publicProcedure
    .input(
      z.object({
        phoneNumber: z.string(),
        otp: z.string().length(6),
      })
    )
    .mutation(async ({ input }) => {
      const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
      const stored = registrationOtpStore.get(normalizedPhone);

      if (!stored) {
        throw new Error("No verification code found. Please request a new one.");
      }

      if (Date.now() > stored.expiresAt) {
        registrationOtpStore.delete(normalizedPhone);
        throw new Error("Verification code has expired. Please request a new one.");
      }

      if (stored.attempts >= MAX_OTP_ATTEMPTS) {
        registrationOtpStore.delete(normalizedPhone);
        throw new Error("Too many failed attempts. Please request a new code.");
      }

      if (stored.otp !== input.otp) {
        stored.attempts += 1;
        throw new Error(`Invalid code. ${MAX_OTP_ATTEMPTS - stored.attempts} attempts remaining.`);
      }

      // Mark as verified
      stored.verified = true;

      return {
        success: true,
        message: "Phone number verified! You can now complete registration.",
      };
    }),

  /**
   * Public: Self-register a new account with OTP-verified UAE phone number (auto-approved)
   */
  register: publicProcedure
    .input(
      z.object({
        phoneNumber: z.string(),
        displayName: z.string().min(2).max(100),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      // Normalize and validate UAE phone number
      const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
      if (!UAE_PHONE_REGEX.test(normalizedPhone)) {
        throw new Error("Invalid UAE phone number. Must be a valid +971 number (e.g., +971501234567 or 0501234567)");
      }

      // Check that phone was OTP-verified
      const otpRecord = registrationOtpStore.get(normalizedPhone);
      if (!otpRecord || !otpRecord.verified) {
        throw new Error("Phone number not verified. Please verify your phone number first.");
      }

      // Check if phone number already exists
      const existingPhone = await getClientAccountByPhone(normalizedPhone);
      if (existingPhone) {
        throw new Error("An account with this phone number already exists");
      }

      // Use phone number as username (unique identifier)
      const existingUsername = await getClientAccountByUsername(normalizedPhone);
      if (existingUsername) {
        throw new Error("An account with this phone number already exists");
      }

      // Hash password
      const passwordHash = await bcrypt.hash(input.password, SALT_ROUNDS);

      // Create account with approved status (auto-approved after OTP verification)
      const account = await createClientAccount({
        username: normalizedPhone,
        passwordHash,
        displayName: input.displayName,
        email: null,
        phoneNumber: normalizedPhone,
        createdByUserId: 0, // self-registered
        isActive: 1,
        status: "approved",
      });

      // Clean up OTP record
      registrationOtpStore.delete(normalizedPhone);
      otpCooldownStore.delete(normalizedPhone);

      return {
        id: account.id,
        phoneNumber: account.phoneNumber,
        status: account.status,
        message: "Account created successfully! You can now log in.",
      };
    }),

  /**
   * Admin: List all accounts (including pending)
   */
  listAllAccounts: adminProcedure.query(async () => {
    const accounts = await listAllClientAccounts();
    return accounts.map((acc) => ({
      id: acc.id,
      username: acc.username,
      displayName: acc.displayName,
      email: acc.email,
      phoneNumber: acc.phoneNumber,
      role: acc.role,
      isActive: Boolean(acc.isActive),
      status: acc.status,
      createdAt: acc.createdAt,
      lastLoginAt: acc.lastLoginAt,
      createdByUserId: acc.createdByUserId,
      vinLimitOverride: acc.vinLimitOverride,
      bonusVinCredits: acc.bonusVinCredits,
    }));
  }),

  /**
   * Admin: Approve or reject a pending account
   */
  updateAccountStatus: adminProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["approved", "rejected"]),
      })
    )
    .mutation(async ({ input }) => {
      const updated = await updateClientAccount(input.id, {
        status: input.status,
      });
      if (!updated) throw new Error("Failed to update account status");

      return {
        id: updated.id,
        username: updated.username,
        status: updated.status,
      };
    }),

  /**
   * Public: Request password reset via phone number
   * Generates a 6-digit OTP code stored in memory (valid for 10 minutes)
   */
  requestPasswordReset: publicProcedure
    .input(z.object({ phoneNumber: z.string() }))
    .mutation(async ({ input }) => {
      const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
      if (!UAE_PHONE_REGEX.test(normalizedPhone)) {
        throw new Error("Invalid UAE phone number");
      }

      const account = await getClientAccountByPhone(normalizedPhone);
      if (!account) {
        // Don't reveal whether the phone exists
        return { success: true, message: "If this phone number is registered, a reset code has been generated." };
      }

      // Generate 6-digit OTP and store in memory
      const otp = String(Math.floor(100000 + Math.random() * 900000));
      resetTokenStore.set(normalizedPhone, {
        otp,
        accountId: account.id,
        expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes
      });

      // In production, this would send an SMS. For now, we log it and also
      // store it so the admin can see it or the user can use it.
      console.log(`[Password Reset] OTP for ${normalizedPhone}: ${otp}`);

      return {
        success: true,
        message: "If this phone number is registered, a reset code has been generated.",
        // In development, return the OTP so the user can use it
        // In production, remove this and send via SMS instead
        _devOtp: otp,
      };
    }),

  /**
   * Public: Reset password using OTP code
   */
  resetPassword: publicProcedure
    .input(
      z.object({
        phoneNumber: z.string(),
        otp: z.string().length(6),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const normalizedPhone = normalizeUAEPhone(input.phoneNumber);
      const stored = resetTokenStore.get(normalizedPhone);

      if (!stored) {
        throw new Error("No reset request found. Please request a new code.");
      }

      if (Date.now() > stored.expiresAt) {
        resetTokenStore.delete(normalizedPhone);
        throw new Error("Reset code has expired. Please request a new one.");
      }

      if (stored.otp !== input.otp) {
        throw new Error("Invalid reset code. Please try again.");
      }

      // Hash new password and update
      const newPasswordHash = await bcrypt.hash(input.newPassword, SALT_ROUNDS);
      await updateClientAccount(stored.accountId, { passwordHash: newPasswordHash });

      // Clean up token
      resetTokenStore.delete(normalizedPhone);

      return { success: true, message: "Password has been reset successfully. You can now log in." };
    }),

  /**
   * Admin: Delete a client account
   */
  deleteAccount: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteClientAccount(input.id);
      return { success: true };
    }),
});
