/**
 * Stripe Webhook Handler
 * Handles payment events and updates subscription status
 */
import { Request, Response } from "express";
import Stripe from "stripe";
import { getStripe } from "./client";
import { getDb } from "../db";
import { clientSubscriptions, clientAccounts } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export async function handleStripeWebhook(req: Request, res: Response) {
  const stripe = getStripe();
  const sig = req.headers["stripe-signature"] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;

  try {
    if (!webhookSecret) {
      throw new Error("STRIPE_WEBHOOK_SECRET not configured");
    }
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    console.error(`[Stripe Webhook] Signature verification failed:`, err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  console.log(`[Stripe Webhook] Received event: ${event.type} (${event.id})`);

  // Handle test events
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    return res.json({
      verified: true,
    });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutComplete(session);
        break;
      }
      case "invoice.paid": {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaid(invoice);
        break;
      }
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdated(subscription);
        break;
      }
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(subscription);
        break;
      }
      default:
        console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
    }
  } catch (err: any) {
    console.error(`[Stripe Webhook] Error processing ${event.type}:`, err);
    // Return 200 to prevent Stripe from retrying
  }

  return res.json({ received: true });
}

async function handleCheckoutComplete(session: Stripe.Checkout.Session) {
  const db = await getDb();
  if (!db) return;

  const accountId = session.metadata?.account_id;
  const planId = session.metadata?.plan_id;
  const billingPeriod = session.metadata?.billing_period as "monthly" | "annual";

  if (!accountId || !planId) {
    console.error("[Stripe Webhook] Missing metadata in checkout session");
    return;
  }

  const stripeSubscriptionId = session.subscription as string;

  // Calculate period end based on billing period
  const now = new Date();
  const periodEnd = new Date(now);
  if (billingPeriod === "annual") {
    periodEnd.setFullYear(periodEnd.getFullYear() + 1);
  } else {
    periodEnd.setMonth(periodEnd.getMonth() + 1);
  }

  // Check if there's an existing subscription for this account
  const [existing] = await db
    .select()
    .from(clientSubscriptions)
    .where(eq(clientSubscriptions.accountId, parseInt(accountId)));

  if (existing) {
    // Update existing subscription
    await db
      .update(clientSubscriptions)
      .set({
        planId: parseInt(planId),
        billingPeriod,
        paymentMethod: "stripe",
        status: "active",
        amountAED: Math.round((session.amount_total || 0) / 100),
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
        stripeSubscriptionId,
      })
      .where(eq(clientSubscriptions.id, existing.id));
  } else {
    // Create new subscription
    await db.insert(clientSubscriptions).values({
      accountId: parseInt(accountId),
      planId: parseInt(planId),
      billingPeriod,
      paymentMethod: "stripe",
      status: "active",
      amountAED: Math.round((session.amount_total || 0) / 100),
      currentPeriodStart: now,
      currentPeriodEnd: periodEnd,
      stripeSubscriptionId,
    });
  }

  console.log(`[Stripe Webhook] Subscription activated for account ${accountId}, plan ${planId}`);
}

async function handleInvoicePaid(invoice: Stripe.Invoice) {
  const db = await getDb();
  if (!db) return;

  const subscriptionId = (invoice as any).subscription as string;
  if (!subscriptionId) return;

  // Update subscription period
  const [sub] = await db
    .select()
    .from(clientSubscriptions)
    .where(eq(clientSubscriptions.stripeSubscriptionId, subscriptionId));

  if (sub) {
    const now = new Date();
    const periodEnd = new Date(now);
    if (sub.billingPeriod === "annual") {
      periodEnd.setFullYear(periodEnd.getFullYear() + 1);
    } else {
      periodEnd.setMonth(periodEnd.getMonth() + 1);
    }

    await db
      .update(clientSubscriptions)
      .set({
        status: "active",
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
      })
      .where(eq(clientSubscriptions.id, sub.id));

    console.log(`[Stripe Webhook] Invoice paid, subscription ${sub.id} renewed`);
  }
}

async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  const db = await getDb();
  if (!db) return;

  const [sub] = await db
    .select()
    .from(clientSubscriptions)
    .where(eq(clientSubscriptions.stripeSubscriptionId, subscription.id));

  if (sub) {
    let status: "active" | "cancelled" | "expired" | "pending_payment" = "active";
    if (subscription.status === "canceled" || subscription.status === "unpaid") {
      status = "cancelled";
    } else if (subscription.status === "past_due") {
      status = "pending_payment";
    }

    await db
      .update(clientSubscriptions)
      .set({ status })
      .where(eq(clientSubscriptions.id, sub.id));

    console.log(`[Stripe Webhook] Subscription ${sub.id} updated to ${status}`);
  }
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  const db = await getDb();
  if (!db) return;

  const [sub] = await db
    .select()
    .from(clientSubscriptions)
    .where(eq(clientSubscriptions.stripeSubscriptionId, subscription.id));

  if (sub) {
    await db
      .update(clientSubscriptions)
      .set({ status: "cancelled" })
      .where(eq(clientSubscriptions.id, sub.id));

    console.log(`[Stripe Webhook] Subscription ${sub.id} cancelled`);
  }
}
