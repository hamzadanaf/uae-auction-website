/**
 * Stripe Products & Prices Configuration
 * 
 * Products and prices are created dynamically in Stripe on first use.
 * This file maps our internal pricing plans to Stripe products.
 */

export interface StripeProductConfig {
  name: string;
  description: string;
  metadata: Record<string, string>;
}

/**
 * Convert our AED pricing plan to Stripe-compatible format.
 * Stripe uses the smallest currency unit (fils for AED = 1/100).
 */
export function aedToStripeAmount(aedAmount: number): number {
  return Math.round(aedAmount * 100); // AED to fils
}

/**
 * Stripe uses ISO 4217 currency codes
 */
export const STRIPE_CURRENCY = "aed";
