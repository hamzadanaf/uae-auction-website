/**
 * Stripe tRPC Router
 * Handles checkout session creation and subscription management
 */
import { z } from "zod";
import { router, publicProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getStripe } from "./client";
import { getDb } from "../db";
import { pricingPlans, clientSubscriptions, clientAccounts } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { aedToStripeAmount, STRIPE_CURRENCY } from "./products";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
  return db;
}

export const stripeRouter = router({
  /**
   * Create a Stripe Checkout Session for a subscription plan
   */
  createCheckoutSession: publicProcedure
    .input(
      z.object({
        planId: z.number(),
        billingPeriod: z.enum(["monthly", "annual"]),
        accountId: z.number(),
        origin: z.string(), // Frontend origin for redirect URLs
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const stripe = getStripe();

      // Get the plan
      const [plan] = await db
        .select()
        .from(pricingPlans)
        .where(eq(pricingPlans.id, input.planId));

      if (!plan) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Plan not found" });
      }

      // Get client account for email
      const [account] = await db
        .select()
        .from(clientAccounts)
        .where(eq(clientAccounts.id, input.accountId));

      if (!account) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Account not found" });
      }

      const priceAED = input.billingPeriod === "annual"
        ? plan.priceAnnualAED
        : plan.priceMonthlyAED;

      // Create or find a Stripe product for this plan
      const products = await stripe.products.list({
        limit: 100,
      });

      let product = products.data.find(
        (p) => p.metadata?.plan_id === plan.id.toString()
      );

      if (!product) {
        product = await stripe.products.create({
          name: `${plan.name} Plan`,
          description: plan.description || `${plan.name} subscription - ${plan.vinLimitPerMonth} VIN lookups/month`,
          metadata: {
            plan_id: plan.id.toString(),
            plan_slug: plan.slug,
          },
        });
      }

      // Create a price for this billing period
      const interval = input.billingPeriod === "annual" ? "year" : "month";
      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: aedToStripeAmount(priceAED),
        currency: STRIPE_CURRENCY,
        recurring: {
          interval: interval as "month" | "year",
        },
        metadata: {
          plan_id: plan.id.toString(),
          billing_period: input.billingPeriod,
        },
      });

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price: price.id,
            quantity: 1,
          },
        ],
        customer_email: account.email || undefined,
        client_reference_id: input.accountId.toString(),
        allow_promotion_codes: true,
        metadata: {
          account_id: input.accountId.toString(),
          plan_id: plan.id.toString(),
          billing_period: input.billingPeriod,
          customer_name: account.displayName || account.username,
        },
        success_url: `${input.origin}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${input.origin}/payment/cancel`,
      });

      return { checkoutUrl: session.url };
    }),

  /**
   * Get current subscription status for a client
   */
  getSubscriptionStatus: publicProcedure
    .input(z.object({ accountId: z.number() }))
    .query(async ({ input }) => {
      const db = await requireDb();

      const [subscription] = await db
        .select()
        .from(clientSubscriptions)
        .where(
          and(
            eq(clientSubscriptions.accountId, input.accountId),
            eq(clientSubscriptions.status, "active")
          )
        );

      if (!subscription) {
        return { hasSubscription: false, subscription: null, plan: null };
      }

      const [plan] = await db
        .select()
        .from(pricingPlans)
        .where(eq(pricingPlans.id, subscription.planId));

      return {
        hasSubscription: true,
        subscription: {
          id: subscription.id,
          status: subscription.status,
          billingPeriod: subscription.billingPeriod,
          amountAED: subscription.amountAED,
          currentPeriodEnd: subscription.currentPeriodEnd,
        },
        plan: plan
          ? {
              id: plan.id,
              name: plan.name,
              vinLimitPerMonth: plan.vinLimitPerMonth,
              features: JSON.parse(plan.features || "[]") as string[],
            }
          : null,
      };
    }),

  /**
   * Cancel a subscription via Stripe
   */
  cancelSubscription: publicProcedure
    .input(z.object({ accountId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const stripe = getStripe();

      const [subscription] = await db
        .select()
        .from(clientSubscriptions)
        .where(
          and(
            eq(clientSubscriptions.accountId, input.accountId),
            eq(clientSubscriptions.status, "active")
          )
        );

      if (!subscription) {
        throw new TRPCError({ code: "NOT_FOUND", message: "No active subscription found" });
      }

      // Cancel at period end (not immediately)
      if (subscription.stripeSubscriptionId) {
        await stripe.subscriptions.update(subscription.stripeSubscriptionId, {
          cancel_at_period_end: true,
        });
      }

      // Update local status
      await db
        .update(clientSubscriptions)
        .set({ status: "cancelled" })
        .where(eq(clientSubscriptions.id, subscription.id));

      return { success: true };
    }),

  /**
   * Verify a checkout session was successful (for success page)
   */
  verifyCheckout: publicProcedure
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      try {
        const stripe = getStripe();
        const session = await stripe.checkout.sessions.retrieve(input.sessionId);
        return {
          success: session.payment_status === "paid",
          planId: session.metadata?.plan_id,
          billingPeriod: session.metadata?.billing_period,
        };
      } catch {
        return { success: false, planId: null, billingPeriod: null };
      }
    }),
});
