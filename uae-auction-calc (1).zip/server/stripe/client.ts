/**
 * Stripe client singleton
 */
import Stripe from "stripe";

let stripeInstance: Stripe | null = null;

export function getStripe(): Stripe {
  if (!stripeInstance) {
    const secretKey = process.env.STRIPE_SECRET_KEY;
    if (!secretKey) {
      throw new Error("STRIPE_SECRET_KEY is not configured. Go to Settings → Payment to set it up.");
    }
    stripeInstance = new Stripe(secretKey, {
      apiVersion: "2025-04-30.basil" as any,
    });
  }
  return stripeInstance;
}
