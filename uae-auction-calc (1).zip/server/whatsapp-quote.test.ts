/**
 * Tests for WhatsApp shipping quote feature.
 * Validates that shipping companies are available via the public endpoint
 * and that the phone number format is correct for WhatsApp URL generation.
 */
import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

function createPublicContext() {
  return {
    ctx: { user: null, req: {} as any, res: {} as any },
  };
}

function createAdminContext() {
  return {
    ctx: {
      user: { id: 1, openId: "admin-1", name: "Admin", role: "admin" as const },
      req: {} as any,
      res: {} as any,
    },
  };
}

/** Normalize a UAE phone number for WhatsApp (same logic as frontend) */
function normalizePhoneForWhatsApp(phone: string): string {
  let cleaned = phone.replace(/[\s\-\(\)]/g, "");
  if (cleaned.startsWith("0")) cleaned = "971" + cleaned.slice(1);
  if (!cleaned.startsWith("+")) cleaned = "+" + cleaned;
  cleaned = cleaned.replace("+", ""); // WhatsApp API uses number without +
  return cleaned;
}

describe("WhatsApp Shipping Quote", () => {
  it("should list active shipping companies via public endpoint", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const companies = await caller.directory.listActiveShippingCompanies();
    expect(Array.isArray(companies)).toBe(true);
  });

  it("shipping companies should have phone field in schema", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const companies = await caller.directory.listActiveShippingCompanies();
    if (companies.length > 0) {
      // Each company should have a phone field (may be null)
      expect("phone" in companies[0]).toBe(true);
    }
  });

  it("should normalize UAE phone numbers correctly for WhatsApp", () => {
    // 0521040460 → 971521040460
    expect(normalizePhoneForWhatsApp("0521040460")).toBe("971521040460");
    // +971521040460 → 971521040460
    expect(normalizePhoneForWhatsApp("+971521040460")).toBe("971521040460");
    // 971521040460 → 971521040460
    expect(normalizePhoneForWhatsApp("971521040460")).toBe("971521040460");
    // With spaces: 052 104 0460 → 971521040460
    expect(normalizePhoneForWhatsApp("052 104 0460")).toBe("971521040460");
    // With dashes: 052-104-0460 → 971521040460
    expect(normalizePhoneForWhatsApp("052-104-0460")).toBe("971521040460");
  });

  it("should generate valid WhatsApp URL format", () => {
    const phone = normalizePhoneForWhatsApp("0521040460");
    const message = "🚗 *Shipping Quote Request*\n\nVIN: 1HGBH41JXMN109186\nVehicle: 2022 Honda Civic\nAuction: COPART\nDestination: UAE\n\nPlease provide a shipping quote. Thank you!";
    const encodedMsg = encodeURIComponent(message);
    const waUrl = `https://wa.me/${phone}?text=${encodedMsg}`;

    expect(waUrl).toContain("https://wa.me/971521040460");
    expect(waUrl).toContain("text=");
    expect(waUrl).toContain("Shipping%20Quote");
  });

  it("should build WhatsApp message with vehicle details", () => {
    const lines: string[] = [
      "🚗 *Shipping Quote Request*",
      "",
    ];
    const vin = "1HGBH41JXMN109186";
    const make = "Honda";
    const model = "Civic";
    const year = "2022";
    const auctionHouse = "copart";
    const shippingCost = 1500;

    if (vin) lines.push(`VIN: ${vin}`);
    lines.push(`Vehicle: ${year} ${make} ${model}`);
    lines.push(`Auction: ${auctionHouse.toUpperCase()}`);
    if (shippingCost > 0) lines.push(`Estimated Rate: $${shippingCost}`);
    lines.push("", "Destination: UAE");
    lines.push("", "Please provide a shipping quote. Thank you!");

    const message = lines.join("\n");
    expect(message).toContain("VIN: 1HGBH41JXMN109186");
    expect(message).toContain("Vehicle: 2022 Honda Civic");
    expect(message).toContain("Auction: COPART");
    expect(message).toContain("Estimated Rate: $1500");
    expect(message).toContain("Destination: UAE");
  });

  it("admin should be able to manage shipping companies", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const companies = await caller.directory.listShippingCompanies();
    expect(Array.isArray(companies)).toBe(true);
  });
});
