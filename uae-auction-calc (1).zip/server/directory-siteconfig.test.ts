import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };

  return { ctx };
}

function createPublicContext(): { ctx: TrpcContext } {
  const ctx: TrpcContext = {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
  return { ctx };
}

function createUserContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
  return { ctx };
}

// ═══════════════════════════════════════════════════════
// DIRECTORY ROUTER TESTS
// ═══════════════════════════════════════════════════════

describe("Directory Router - Shipping Companies", () => {
  it("should allow public access to list active shipping companies", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const companies = await caller.directory.listActiveShippingCompanies();
    expect(Array.isArray(companies)).toBe(true);
  });

  it("should block non-admin from listing all shipping companies", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.directory.listShippingCompanies()).rejects.toThrow(
      /admin|forbidden/i
    );
  });

  it("should block non-admin from creating shipping companies", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.createShippingCompany({ name: "Test Shipping Co" })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from deleting shipping companies", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.deleteShippingCompany({ id: 1 })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should allow admin to list all shipping companies", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const companies = await caller.directory.listShippingCompanies();
    expect(Array.isArray(companies)).toBe(true);
  });
});

describe("Directory Router - Insurance Companies", () => {
  it("should allow public access to list active insurance companies", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const companies = await caller.directory.listActiveInsuranceCompanies();
    expect(Array.isArray(companies)).toBe(true);
  });

  it("should block non-admin from listing all insurance companies", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.directory.listInsuranceCompanies()).rejects.toThrow(
      /admin|forbidden/i
    );
  });

  it("should block non-admin from creating insurance companies", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.createInsuranceCompany({ name: "Test Insurance" })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Directory Router - Spare Parts Shops", () => {
  it("should allow public access to list active parts shops", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const shops = await caller.directory.listActivePartsShops();
    expect(Array.isArray(shops)).toBe(true);
  });

  it("should block non-admin from listing all parts shops", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.directory.listPartsShops()).rejects.toThrow(
      /admin|forbidden/i
    );
  });

  it("should block non-admin from creating parts shops", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.createPartsShop({ name: "Test Shop" })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Directory Router - Quote Requests", () => {
  it("should block unauthenticated users from submitting quote requests", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.submitQuoteRequest({
        companyType: "shipping",
        companyId: 1,
        companyName: "Test Co",
      })
    ).rejects.toThrow();
  });

  it("should block non-admin from listing quote requests", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.directory.listQuoteRequests()).rejects.toThrow(
      /admin|forbidden/i
    );
  });

  it("should allow admin to list quote requests", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const requests = await caller.directory.listQuoteRequests();
    expect(Array.isArray(requests)).toBe(true);
  });

  it("should block non-admin from updating quote request status", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.directory.updateQuoteRequestStatus({ id: 1, status: "sent" })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

// ═══════════════════════════════════════════════════════
// SITE CONFIG ROUTER TESTS
// ═══════════════════════════════════════════════════════

describe("Site Config Router - Settings", () => {
  it("should allow public access to get a single setting", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const setting = await caller.siteConfig.getSetting({ key: "nonexistent_key" });
    expect(setting).toBeNull();
  });

  it("should allow public access to get multiple settings", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const settings = await caller.siteConfig.getSettings({
      keys: ["shipping_quotes_enabled", "insurance_quotes_enabled"],
    });
    expect(typeof settings).toBe("object");
  });

  it("should block non-admin from getting all settings", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.siteConfig.getAllSettings()).rejects.toThrow(
      /admin|forbidden/i
    );
  });

  it("should allow admin to get all settings", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const settings = await caller.siteConfig.getAllSettings();
    expect(Array.isArray(settings)).toBe(true);
  });

  it("should block non-admin from upserting settings", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.upsertSetting({ key: "test_key", value: "test_value" })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Site Config Router - Parts Prices", () => {
  it("should allow public access to get parts prices", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const prices = await caller.siteConfig.getPartsPrices();
    expect(Array.isArray(prices)).toBe(true);
  });

  it("should block non-admin from upserting part prices", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.upsertPartPrice({
        partId: "test-part",
        partName: "Test Part",
        category: "test",
        priceAED: 100,
      })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from bulk upserting part prices", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.bulkUpsertPartsPrices([
        { partId: "p1", partName: "Part 1", category: "cat", priceAED: 50 },
      ])
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from deleting part prices", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.deletePartPrice({ partId: "test-part" })
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Site Config Router - AI Cost Settings", () => {
  it("should allow public access to get AI cost settings", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const settings = await caller.siteConfig.getAiCostSettings();
    expect(Array.isArray(settings)).toBe(true);
  });

  it("should block non-admin from upserting AI cost settings", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.upsertAiCostSetting({
        settingKey: "test_key",
        settingValue: "100",
      })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from bulk upserting AI cost settings", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.bulkUpsertAiCostSettings([
        { settingKey: "k1", settingValue: "v1" },
      ])
    ).rejects.toThrow(/admin|forbidden/i);
  });
});

describe("Site Config Router - Per-User VIN Limits", () => {
  it("should block non-admin from setting user VIN limit", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.setUserVinLimit({ accountId: 1, vinLimitOverride: 100 })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from adding bonus VIN credits", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.addBonusVinCredits({ accountId: 1, credits: 10 })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should block non-admin from resetting bonus VIN credits", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.siteConfig.resetBonusVinCredits({ accountId: 1 })
    ).rejects.toThrow(/admin|forbidden/i);
  });

  it("should allow public access to get enhanced VIN quota (returns free trial defaults for unknown account)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const quota = await caller.siteConfig.getEnhancedVinQuota({ accountId: 99999 });
    expect(quota).toHaveProperty("limit");
    expect(quota).toHaveProperty("used");
    expect(quota).toHaveProperty("remaining");
    expect(quota).toHaveProperty("bonus");
    expect(quota).toHaveProperty("hasSubscription");
    expect(quota).toHaveProperty("planName");
    expect(quota).toHaveProperty("source");
    expect(quota.limit).toBe(3); // Free trial default
    expect(quota.bonus).toBe(0);
    expect(quota.hasSubscription).toBe(false);
    expect(quota.planName).toBe("Free Trial");
    expect(quota.source).toBe("default");
  });
});
