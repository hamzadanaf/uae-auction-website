import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

/**
 * Tests for vehicleModelsRouter — Per-Year Pricing Schema
 * These tests use the tRPC caller to test the router procedures directly.
 * Since they hit the real database, they test the actual query logic.
 */

function createPublicContext(): TrpcContext {
  return {
    user: null,
    clientAccountId: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("vehicleModels.getBrands", () => {
  it("returns an array of brands with model counts and year ranges", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const brands = await caller.vehicleModels.getBrands();

    expect(Array.isArray(brands)).toBe(true);
    expect(brands.length).toBeGreaterThan(0);

    // Each brand should have new per-year fields
    const first = brands[0];
    expect(first).toHaveProperty("brand");
    expect(first).toHaveProperty("modelCount");
    expect(first).toHaveProperty("totalRows");
    expect(first).toHaveProperty("region");
    expect(first).toHaveProperty("minYear");
    expect(first).toHaveProperty("maxYear");
    expect(first).toHaveProperty("dubizzleBrandSlug");
    expect(typeof first.brand).toBe("string");
    expect(typeof first.modelCount).toBe("number");
    expect(first.modelCount).toBeGreaterThan(0);
    expect(first.minYear).toBeLessThanOrEqual(first.maxYear);
  });

  it("returns brands from all four regions", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const brands = await caller.vehicleModels.getBrands();
    const regions = new Set(brands.map((b) => b.region));

    expect(regions.has("american")).toBe(true);
    expect(regions.has("japanese")).toBe(true);
    expect(regions.has("european")).toBe(true);
    expect(regions.has("korean")).toBe(true);
  });

  it("has year range spanning 2010 to 2026", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const brands = await caller.vehicleModels.getBrands();
    const allMinYears = brands.map((b) => b.minYear);
    const allMaxYears = brands.map((b) => b.maxYear);

    expect(Math.min(...allMinYears)).toBe(2010);
    expect(Math.max(...allMaxYears)).toBe(2026);
  });
});

describe("vehicleModels.getModelsByBrand", () => {
  it("returns models for Toyota grouped by model with per-year pricing", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const models = await caller.vehicleModels.getModelsByBrand({
      brand: "Toyota",
    });

    expect(Array.isArray(models)).toBe(true);
    expect(models.length).toBeGreaterThan(0);

    // Each model should be grouped with a years array
    const first = models[0];
    expect(first).toHaveProperty("model");
    expect(first).toHaveProperty("category");
    expect(first).toHaveProperty("region");
    expect(first).toHaveProperty("dubizzleBrandSlug");
    expect(first).toHaveProperty("dubizzleModelSlug");
    expect(first).toHaveProperty("years");
    expect(Array.isArray(first.years)).toBe(true);
    expect(first.years.length).toBeGreaterThan(0);

    // Each year entry should have pricing
    const yearEntry = first.years[0];
    expect(yearEntry).toHaveProperty("id");
    expect(yearEntry).toHaveProperty("year");
    expect(yearEntry).toHaveProperty("uaeMarketPriceLow");
    expect(yearEntry).toHaveProperty("uaeMarketPriceMid");
    expect(yearEntry).toHaveProperty("uaeMarketPriceHigh");
    expect(yearEntry).toHaveProperty("auctionAvgPriceUSD");
  });

  it("returns years sorted in ascending order", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const models = await caller.vehicleModels.getModelsByBrand({
      brand: "Toyota",
    });

    const camry = models.find((m) => m.model.toLowerCase() === "camry");
    expect(camry).toBeDefined();
    if (camry) {
      for (let i = 1; i < camry.years.length; i++) {
        expect(camry.years[i].year).toBeGreaterThan(camry.years[i - 1].year);
      }
    }
  });

  it("returns empty array for non-existent brand", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const models = await caller.vehicleModels.getModelsByBrand({
      brand: "NonExistentBrand12345",
    });

    expect(Array.isArray(models)).toBe(true);
    expect(models.length).toBe(0);
  });

  it("is case-insensitive for brand matching", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const modelsLower = await caller.vehicleModels.getModelsByBrand({
      brand: "toyota",
    });
    const modelsUpper = await caller.vehicleModels.getModelsByBrand({
      brand: "TOYOTA",
    });

    expect(modelsLower.length).toBe(modelsUpper.length);
    expect(modelsLower.length).toBeGreaterThan(0);
  });
});

describe("vehicleModels.matchVinToModel", () => {
  it("matches Toyota Camry 2020 exactly with per-year pricing", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "Camry",
      year: 2020,
    });

    expect(result.match).not.toBeNull();
    expect(result.match?.brand.toLowerCase()).toBe("toyota");
    expect(result.match?.model.toLowerCase()).toBe("camry");
    expect(result.match?.year).toBe(2020);
    expect(result.matchType).toBe("exact");
    // Should have pricing for 2020
    expect(result.match?.uaeMarketPriceMid).toBeGreaterThan(0);
  });

  it("returns different prices for different years of the same model", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result2015 = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "Camry",
      year: 2015,
    });

    const result2024 = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "Camry",
      year: 2024,
    });

    expect(result2015.match).not.toBeNull();
    expect(result2024.match).not.toBeNull();
    expect(result2015.match?.year).toBe(2015);
    expect(result2024.match?.year).toBe(2024);

    // 2024 should be more expensive than 2015
    if (result2015.match?.uaeMarketPriceMid && result2024.match?.uaeMarketPriceMid) {
      expect(result2024.match.uaeMarketPriceMid).toBeGreaterThan(
        result2015.match.uaeMarketPriceMid
      );
    }
  });

  it("handles case-insensitive matching", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.vehicleModels.matchVinToModel({
      make: "TOYOTA",
      model: "CAMRY",
      year: 2022,
    });

    expect(result.match).not.toBeNull();
    expect(result.matchType).toBe("exact");
  });

  it("returns none for unknown make/model", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.vehicleModels.matchVinToModel({
      make: "UnknownMake",
      model: "UnknownModel",
      year: 2022,
    });

    expect(result.match).toBeNull();
    expect(result.matchType).toBe("none");
  });

  it("returns brand_only suggestions when model doesn't match", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "SomeNonExistentModel",
      year: 2022,
    });

    expect(result.matchType).toBe("brand_only");
    expect(result.suggestions.length).toBeGreaterThan(0);
    expect(result.suggestions[0].brand.toLowerCase()).toBe("toyota");
  });

  it("falls back to model_only match when year is not in range", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Year 2005 is before our 2010-2026 range
    const result = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "Camry",
      year: 2005,
    });

    // Should fall back to model_only (latest year)
    expect(result.match).not.toBeNull();
    expect(result.matchType).toBe("model_only");
  });

  it("includes dubizzle slug data in match result", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.vehicleModels.matchVinToModel({
      make: "Toyota",
      model: "Camry",
      year: 2022,
    });

    expect(result.match).not.toBeNull();
    expect(result.match).toHaveProperty("dubizzleBrandSlug");
    expect(result.match).toHaveProperty("dubizzleModelSlug");
    expect(result.match?.dubizzleBrandSlug).toBe("toyota");
    expect(result.match?.dubizzleModelSlug).toBe("camry");
  });
});

describe("vehicleModels.getYearsForModel", () => {
  it("returns all years for Toyota Camry", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const years = await caller.vehicleModels.getYearsForModel({
      brand: "Toyota",
      model: "Camry",
    });

    expect(Array.isArray(years)).toBe(true);
    expect(years.length).toBeGreaterThanOrEqual(10); // At least 2010-2026

    // Should be sorted by year ascending
    for (let i = 1; i < years.length; i++) {
      expect(years[i].year).toBeGreaterThan(years[i - 1].year);
    }

    // Each entry should have pricing and dubizzle data
    const first = years[0];
    expect(first).toHaveProperty("year");
    expect(first).toHaveProperty("uaeMarketPriceLow");
    expect(first).toHaveProperty("uaeMarketPriceMid");
    expect(first).toHaveProperty("uaeMarketPriceHigh");
    expect(first).toHaveProperty("dubizzleBrandSlug");
    expect(first).toHaveProperty("dubizzleModelSlug");
  });
});

describe("vehicleModels.getStats", () => {
  it("returns aggregate statistics with per-year counts", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.vehicleModels.getStats();

    expect(stats).toHaveProperty("totalRows");
    expect(stats).toHaveProperty("totalBrands");
    expect(stats).toHaveProperty("totalModels");
    expect(stats).toHaveProperty("avgPrice");
    expect(stats).toHaveProperty("withPrices");
    expect(stats).toHaveProperty("minYear");
    expect(stats).toHaveProperty("maxYear");
    expect(stats.totalRows).toBeGreaterThan(0);
    expect(stats.totalBrands).toBeGreaterThan(0);
    expect(stats.totalModels).toBeGreaterThan(0);
    // totalRows should be much larger than totalModels (per-year expansion)
    expect(stats.totalRows).toBeGreaterThan(stats.totalModels);
    expect(stats.minYear).toBe(2010);
    expect(stats.maxYear).toBe(2026);
  });
});
