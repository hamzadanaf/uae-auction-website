import { describe, it, expect } from "vitest";
import { z } from "zod";

/**
 * Tests for phone-based registration, login, change password, and account details.
 * These tests validate the schema, phone normalization, and UAE phone regex.
 */

// ── UAE Phone Regex (same as in clientRouter.ts) ──
const UAE_PHONE_REGEX = /^\+?971(5[0-9])\d{7}$/;

function normalizeUAEPhone(phone: string): string {
  let cleaned = phone.replace(/[\s\-\(\)]/g, "");
  if (cleaned.startsWith("05")) {
    cleaned = "+971" + cleaned.slice(1);
  }
  if (cleaned.startsWith("971")) {
    cleaned = "+" + cleaned;
  }
  return cleaned;
}

describe("UAE Phone Number Validation", () => {
  it("should accept valid +971 format", () => {
    expect(UAE_PHONE_REGEX.test("+971501234567")).toBe(true);
    expect(UAE_PHONE_REGEX.test("+971551234567")).toBe(true);
    expect(UAE_PHONE_REGEX.test("+971569876543")).toBe(true);
  });

  it("should accept valid 971 format without +", () => {
    expect(UAE_PHONE_REGEX.test("971501234567")).toBe(true);
  });

  it("should reject invalid phone numbers", () => {
    expect(UAE_PHONE_REGEX.test("123456789")).toBe(false);
    expect(UAE_PHONE_REGEX.test("+1234567890")).toBe(false);
    expect(UAE_PHONE_REGEX.test("+971401234567")).toBe(false); // 40 not valid operator
    expect(UAE_PHONE_REGEX.test("+97150123456")).toBe(false); // too short
    expect(UAE_PHONE_REGEX.test("+9715012345678")).toBe(false); // too long
    expect(UAE_PHONE_REGEX.test("")).toBe(false);
  });

  it("should reject non-UAE country codes", () => {
    expect(UAE_PHONE_REGEX.test("+966501234567")).toBe(false); // Saudi
    expect(UAE_PHONE_REGEX.test("+1501234567")).toBe(false); // US
  });
});

describe("UAE Phone Normalization", () => {
  it("should normalize 05XXXXXXXX to +971XXXXXXXXX", () => {
    expect(normalizeUAEPhone("0501234567")).toBe("+971501234567");
    expect(normalizeUAEPhone("0551234567")).toBe("+971551234567");
  });

  it("should normalize 971XXXXXXXXX to +971XXXXXXXXX", () => {
    expect(normalizeUAEPhone("971501234567")).toBe("+971501234567");
  });

  it("should keep +971XXXXXXXXX as is", () => {
    expect(normalizeUAEPhone("+971501234567")).toBe("+971501234567");
  });

  it("should strip spaces, dashes, and parentheses", () => {
    expect(normalizeUAEPhone("+971 50 123 4567")).toBe("+971501234567");
    expect(normalizeUAEPhone("050-123-4567")).toBe("+971501234567");
    expect(normalizeUAEPhone("(050) 1234567")).toBe("+971501234567");
  });
});

describe("Registration Input Validation", () => {
  const registerSchema = z.object({
    phoneNumber: z.string(),
    displayName: z.string().min(2).max(100),
    password: z.string().min(6),
  });

  it("should accept valid registration input", () => {
    const result = registerSchema.safeParse({
      phoneNumber: "+971501234567",
      displayName: "Ahmed Al Mansouri",
      password: "secure123",
    });
    expect(result.success).toBe(true);
  });

  it("should reject missing phone number", () => {
    const result = registerSchema.safeParse({
      phoneNumber: "",
      displayName: "Ahmed",
      password: "secure123",
    });
    // phoneNumber is z.string() so empty string is technically valid at zod level
    // but the server-side regex check will reject it
    expect(result.success).toBe(true);
    // The actual phone validation happens server-side with UAE_PHONE_REGEX
    expect(UAE_PHONE_REGEX.test(normalizeUAEPhone(""))).toBe(false);
  });

  it("should reject short display name", () => {
    const result = registerSchema.safeParse({
      phoneNumber: "+971501234567",
      displayName: "A",
      password: "secure123",
    });
    expect(result.success).toBe(false);
  });

  it("should reject short password", () => {
    const result = registerSchema.safeParse({
      phoneNumber: "+971501234567",
      displayName: "Ahmed",
      password: "12345",
    });
    expect(result.success).toBe(false);
  });
});

describe("Change Password Input Validation", () => {
  const changePasswordSchema = z.object({
    currentPassword: z.string().min(6),
    newPassword: z.string().min(6),
  });

  it("should accept valid password change input", () => {
    const result = changePasswordSchema.safeParse({
      currentPassword: "oldpass123",
      newPassword: "newpass456",
    });
    expect(result.success).toBe(true);
  });

  it("should reject short current password", () => {
    const result = changePasswordSchema.safeParse({
      currentPassword: "short",
      newPassword: "newpass456",
    });
    expect(result.success).toBe(false);
  });

  it("should reject short new password", () => {
    const result = changePasswordSchema.safeParse({
      currentPassword: "oldpass123",
      newPassword: "short",
    });
    expect(result.success).toBe(false);
  });
});

describe("Login Input Validation", () => {
  const loginSchema = z.object({
    username: z.string().min(3).max(64),
    password: z.string().min(6),
  });

  it("should accept phone number as username for login", () => {
    const result = loginSchema.safeParse({
      username: "+971501234567",
      password: "secure123",
    });
    expect(result.success).toBe(true);
  });

  it("should accept regular username for login", () => {
    const result = loginSchema.safeParse({
      username: "admin",
      password: "secure123",
    });
    expect(result.success).toBe(true);
  });

  it("should accept 05XXXXXXXX format for login", () => {
    const result = loginSchema.safeParse({
      username: "0501234567",
      password: "secure123",
    });
    expect(result.success).toBe(true);
  });
});
