import { describe, it, expect } from "vitest";

/**
 * Tests for OTP Registration Flow
 * Tests the sendRegistrationOtp, verifyRegistrationOtp, and register endpoints
 */

const BASE = "http://localhost:3000/api/trpc";

async function callMutation(procedure: string, input: any) {
  const res = await fetch(`${BASE}/${procedure}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ json: input }),
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.json?.message || json.error.message || "Unknown error");
  return json.result?.data?.json ?? json.result?.data;
}

describe("OTP Registration Flow", () => {
  const testPhone = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);

  it("should reject invalid phone numbers for OTP", async () => {
    await expect(
      callMutation("accounts.sendRegistrationOtp", { phoneNumber: "12345" })
    ).rejects.toThrow();
  });

  it("should send OTP for a valid UAE phone number", async () => {
    const result = await callMutation("accounts.sendRegistrationOtp", {
      phoneNumber: testPhone,
    });
    expect(result.success).toBe(true);
    expect(result._devOtp).toBeDefined();
    expect(result._devOtp).toHaveLength(6);
    expect(result.expiresInSeconds).toBe(300);
  });

  it("should enforce cooldown on resend", async () => {
    // Try sending again immediately (within 60s cooldown)
    await expect(
      callMutation("accounts.sendRegistrationOtp", { phoneNumber: testPhone })
    ).rejects.toThrow(/wait/i);
  });

  it("should reject wrong OTP code", async () => {
    await expect(
      callMutation("accounts.verifyRegistrationOtp", {
        phoneNumber: testPhone,
        otp: "000000",
      })
    ).rejects.toThrow(/invalid|attempts/i);
  });

  it("should verify correct OTP code", async () => {
    // First send a new OTP with a different number
    const phone2 = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);
    const sendResult = await callMutation("accounts.sendRegistrationOtp", {
      phoneNumber: phone2,
    });
    const otp = sendResult._devOtp;

    // Verify with correct OTP
    const verifyResult = await callMutation("accounts.verifyRegistrationOtp", {
      phoneNumber: phone2,
      otp,
    });
    expect(verifyResult.success).toBe(true);
    expect(verifyResult.message).toContain("verified");
  });

  it("should reject registration without OTP verification", async () => {
    const unverifiedPhone = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);
    await expect(
      callMutation("accounts.register", {
        phoneNumber: unverifiedPhone,
        displayName: "Test User",
        password: "test123456",
      })
    ).rejects.toThrow(/not verified/i);
  });

  it("should allow registration after OTP verification", async () => {
    // Send OTP
    const phone3 = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);
    const sendResult = await callMutation("accounts.sendRegistrationOtp", {
      phoneNumber: phone3,
    });
    const otp = sendResult._devOtp;

    // Verify OTP
    await callMutation("accounts.verifyRegistrationOtp", {
      phoneNumber: phone3,
      otp,
    });

    // Register
    const regResult = await callMutation("accounts.register", {
      phoneNumber: phone3,
      displayName: "OTP Test User",
      password: "test123456",
    });
    expect(regResult.id).toBeDefined();
    expect(regResult.status).toBe("approved");
    expect(regResult.message).toContain("successfully");
  });

  it("should reject duplicate phone registration", async () => {
    // Try registering the same phone again
    const phone4 = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);

    // Send + verify + register
    const send1 = await callMutation("accounts.sendRegistrationOtp", { phoneNumber: phone4 });
    await callMutation("accounts.verifyRegistrationOtp", { phoneNumber: phone4, otp: send1._devOtp });
    await callMutation("accounts.register", {
      phoneNumber: phone4,
      displayName: "First User",
      password: "test123456",
    });

    // Try sending OTP for same phone again
    await expect(
      callMutation("accounts.sendRegistrationOtp", { phoneNumber: phone4 })
    ).rejects.toThrow(/already exists/i);
  });

  it("should reject OTP verification for non-existent request", async () => {
    const randomPhone = "+9715" + String(Math.floor(10000000 + Math.random() * 89999999)).slice(0, 8);
    await expect(
      callMutation("accounts.verifyRegistrationOtp", {
        phoneNumber: randomPhone,
        otp: "123456",
      })
    ).rejects.toThrow(/no verification|not found/i);
  });
});
