import { describe, it, expect } from "vitest";

describe("Auction API Secrets", () => {
  it("should have AUCTION_API_EMAIL set", () => {
    expect(process.env.AUCTION_API_EMAIL).toBeTruthy();
    expect(process.env.AUCTION_API_EMAIL).toContain("@");
  });

  it("should have AUCTION_API_PASSWORD set", () => {
    expect(process.env.AUCTION_API_PASSWORD).toBeTruthy();
    expect(process.env.AUCTION_API_PASSWORD!.length).toBeGreaterThan(3);
  });

  it("should have AUCTION_API_TOKEN set", () => {
    expect(process.env.AUCTION_API_TOKEN).toBeTruthy();
    expect(process.env.AUCTION_API_TOKEN).toBe("tb84dkujvf");
  });
});
