import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import {
  shippingCompanies,
  insuranceCompanies,
  sparePartsShops,
  quoteRequests,
  siteSettings,
} from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
  return db;
}

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// ─── Shared company schema ───
const companyInput = z.object({
  name: z.string().min(1),
  email: z.string().optional(),
  phone: z.string().optional(),
  website: z.string().optional(),
  location: z.string().optional(),
  description: z.string().optional(),
  logoUrl: z.string().optional(),
  isActive: z.number().default(1),
  sortOrder: z.number().default(0),
});

export const directoryRouter = router({
  // ═══════════════════════════════════════════════════════
  // SHIPPING COMPANIES
  // ═══════════════════════════════════════════════════════

  /** List all shipping companies (admin) */
  listShippingCompanies: adminProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(shippingCompanies).orderBy(shippingCompanies.sortOrder);
  }),

  /** List active shipping companies (public — for client directory) */
  listActiveShippingCompanies: publicProcedure.query(async () => {
    const db = await requireDb();
    return db
      .select()
      .from(shippingCompanies)
      .where(eq(shippingCompanies.isActive, 1))
      .orderBy(shippingCompanies.sortOrder);
  }),

  /** Create shipping company */
  createShippingCompany: adminProcedure
    .input(companyInput.extend({ services: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.insert(shippingCompanies).values(input);
      return { success: true };
    }),

  /** Update shipping company */
  updateShippingCompany: adminProcedure
    .input(z.object({ id: z.number() }).merge(companyInput.extend({ services: z.string().optional() }).partial()))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, ...data } = input;
      await db.update(shippingCompanies).set(data).where(eq(shippingCompanies.id, id));
      return { success: true };
    }),

  /** Delete shipping company */
  deleteShippingCompany: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(shippingCompanies).where(eq(shippingCompanies.id, input.id));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // INSURANCE COMPANIES
  // ═══════════════════════════════════════════════════════

  listInsuranceCompanies: adminProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(insuranceCompanies).orderBy(insuranceCompanies.sortOrder);
  }),

  listActiveInsuranceCompanies: publicProcedure.query(async () => {
    const db = await requireDb();
    return db
      .select()
      .from(insuranceCompanies)
      .where(eq(insuranceCompanies.isActive, 1))
      .orderBy(insuranceCompanies.sortOrder);
  }),

  createInsuranceCompany: adminProcedure
    .input(companyInput.extend({ coverageTypes: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.insert(insuranceCompanies).values(input);
      return { success: true };
    }),

  updateInsuranceCompany: adminProcedure
    .input(z.object({ id: z.number() }).merge(companyInput.extend({ coverageTypes: z.string().optional() }).partial()))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, ...data } = input;
      await db.update(insuranceCompanies).set(data).where(eq(insuranceCompanies.id, id));
      return { success: true };
    }),

  deleteInsuranceCompany: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(insuranceCompanies).where(eq(insuranceCompanies.id, input.id));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // SPARE PARTS SHOPS
  // ═══════════════════════════════════════════════════════

  listPartsShops: adminProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(sparePartsShops).orderBy(sparePartsShops.sortOrder);
  }),

  listActivePartsShops: publicProcedure.query(async () => {
    const db = await requireDb();
    return db
      .select()
      .from(sparePartsShops)
      .where(eq(sparePartsShops.isActive, 1))
      .orderBy(sparePartsShops.sortOrder);
  }),

  createPartsShop: adminProcedure
    .input(companyInput.extend({ area: z.string().optional(), specialties: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.insert(sparePartsShops).values(input);
      return { success: true };
    }),

  updatePartsShop: adminProcedure
    .input(z.object({ id: z.number() }).merge(companyInput.extend({ area: z.string().optional(), specialties: z.string().optional() }).partial()))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, ...data } = input;
      await db.update(sparePartsShops).set(data).where(eq(sparePartsShops.id, id));
      return { success: true };
    }),

  deletePartsShop: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db.delete(sparePartsShops).where(eq(sparePartsShops.id, input.id));
      return { success: true };
    }),

  // ═══════════════════════════════════════════════════════
  // QUOTE REQUESTS
  // ═══════════════════════════════════════════════════════

  /** Submit a quote request (client) */
  submitQuoteRequest: protectedProcedure
    .input(
      z.object({
        companyType: z.enum(["shipping", "insurance", "parts"]),
        companyId: z.number(),
        companyName: z.string(),
        clientName: z.string().optional(),
        clientEmail: z.string().optional(),
        clientPhone: z.string().optional(),
        vehicleInfo: z.string().optional(),
        message: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await db.insert(quoteRequests).values({
        ...input,
        clientAccountId: ctx.user.id,
      });

      // Notify admin about new quote request
      try {
        const { notifyOwner } = await import("./_core/notification");
        await notifyOwner({
          title: `New ${input.companyType} quote request`,
          content: `Client: ${input.clientName || "Unknown"}\nCompany: ${input.companyName}\nPhone: ${input.clientPhone || "N/A"}\nVehicle: ${input.vehicleInfo || "N/A"}\nMessage: ${input.message || "N/A"}`,
        });
      } catch (e) {
        // Non-critical — don't fail the mutation if notification fails
        console.warn("[QuoteRequest] Failed to notify admin:", e);
      }

      return { success: true };
    }),

  /** List my quote requests (client) */
  myQuoteRequests: protectedProcedure.query(async ({ ctx }) => {
    const db = await requireDb();
    return db
      .select()
      .from(quoteRequests)
      .where(eq(quoteRequests.clientAccountId, ctx.user.id))
      .orderBy(desc(quoteRequests.createdAt));
  }),

  /** List all quote requests (admin) */
  listQuoteRequests: adminProcedure
    .input(z.object({ companyType: z.enum(["shipping", "insurance", "parts"]).optional() }).optional())
    .query(async ({ input }) => {
      const db = await requireDb();
      if (input?.companyType) {
        return db
          .select()
          .from(quoteRequests)
          .where(eq(quoteRequests.companyType, input.companyType))
          .orderBy(desc(quoteRequests.createdAt));
      }
      return db.select().from(quoteRequests).orderBy(desc(quoteRequests.createdAt));
    }),

  /** Update quote request status (admin) */
  updateQuoteRequestStatus: adminProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "sent", "responded", "closed"]),
        adminNotes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await requireDb();
      const { id, ...data } = input;
      await db.update(quoteRequests).set(data).where(eq(quoteRequests.id, id));
      return { success: true };
    }),
});
