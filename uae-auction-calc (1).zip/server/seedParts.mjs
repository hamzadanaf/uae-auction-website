/**
 * Seed script: Insert all hardcoded SPARE_PARTS into adminPartsPrices DB table
 * Run: node server/seedParts.mjs
 */
import 'dotenv/config';
import mysql from 'mysql2/promise';

const SPARE_PARTS = [
  // Engine & Drivetrain
  { partId: "engine", category: "Engine & Drivetrain", partName: "Engine", priceAED: 8000 },
  { partId: "transmission", category: "Engine & Drivetrain", partName: "Transmission", priceAED: 6500 },
  { partId: "radiator", category: "Engine & Drivetrain", partName: "Radiator", priceAED: 1200 },
  { partId: "ac-compressor", category: "Engine & Drivetrain", partName: "AC Compressor", priceAED: 1500 },

  // Body Parts
  { partId: "front-bumper", category: "Body Parts", partName: "Front Bumper", priceAED: 800 },
  { partId: "rear-bumper", category: "Body Parts", partName: "Rear Bumper", priceAED: 700 },
  { partId: "hood", category: "Body Parts", partName: "Hood", priceAED: 600 },
  { partId: "trunk-lid", category: "Body Parts", partName: "Trunk Lid", priceAED: 700 },
  { partId: "fender", category: "Body Parts", partName: "Fender", priceAED: 500 },
  { partId: "door", category: "Body Parts", partName: "Door", priceAED: 1200 },
  { partId: "roof", category: "Body Parts", partName: "Roof Panel", priceAED: 1500 },

  // Glass
  { partId: "windshield", category: "Glass", partName: "Windshield", priceAED: 1000 },
  { partId: "rear-window", category: "Glass", partName: "Rear Window", priceAED: 800 },
  { partId: "side-window", category: "Glass", partName: "Side Window", priceAED: 500 },

  // Electrical
  { partId: "headlights", category: "Electrical", partName: "Headlights (Pair)", priceAED: 1200 },
  { partId: "taillights", category: "Electrical", partName: "Taillights (Pair)", priceAED: 900 },
  { partId: "alternator", category: "Electrical", partName: "Alternator", priceAED: 1800 },
  { partId: "battery", category: "Electrical", partName: "Battery", priceAED: 400 },

  // Suspension
  { partId: "shock-absorbers", category: "Suspension", partName: "Shock Absorbers (Set)", priceAED: 1600 },
  { partId: "springs", category: "Suspension", partName: "Springs (Set)", priceAED: 1200 },
  { partId: "control-arms", category: "Suspension", partName: "Control Arms (Pair)", priceAED: 1400 },

  // Brakes
  { partId: "brake-pads", category: "Brakes", partName: "Brake Pads (Set)", priceAED: 600 },
  { partId: "brake-rotors", category: "Brakes", partName: "Brake Rotors (Set)", priceAED: 1000 },
  { partId: "brake-calipers", category: "Brakes", partName: "Brake Calipers (Pair)", priceAED: 1800 },

  // Interior
  { partId: "dashboard", category: "Interior", partName: "Dashboard", priceAED: 2000 },
  { partId: "seats", category: "Interior", partName: "Seats (Set)", priceAED: 2500 },
  { partId: "carpet", category: "Interior", partName: "Carpet/Floor Mats", priceAED: 500 },
];

async function seed() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('DATABASE_URL not set');
    process.exit(1);
  }

  const connection = await mysql.createConnection(url);
  console.log('Connected to database');

  let inserted = 0;
  let updated = 0;

  for (const part of SPARE_PARTS) {
    // Check if part already exists
    const [rows] = await connection.execute(
      'SELECT id FROM adminPartsPrices WHERE partId = ?',
      [part.partId]
    );

    if (Array.isArray(rows) && rows.length > 0) {
      // Update existing
      await connection.execute(
        'UPDATE adminPartsPrices SET partName = ?, category = ?, priceAED = ?, isActive = 1 WHERE partId = ?',
        [part.partName, part.category, part.priceAED, part.partId]
      );
      updated++;
    } else {
      // Insert new
      await connection.execute(
        'INSERT INTO adminPartsPrices (partId, partName, category, priceAED, isActive) VALUES (?, ?, ?, ?, 1)',
        [part.partId, part.partName, part.category, part.priceAED]
      );
      inserted++;
    }
  }

  console.log(`Done! Inserted: ${inserted}, Updated: ${updated}, Total: ${SPARE_PARTS.length}`);
  await connection.end();
}

seed().catch(err => {
  console.error('Seed failed:', err);
  process.exit(1);
});
