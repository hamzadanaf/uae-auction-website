/**
 * Seed script v2: Populate vehicleModels table with PER-YEAR pricing (2010-2026)
 * 
 * Strategy:
 * 1. Read existing PRICE_DB (has 2018-2025 data for most models)
 * 2. Extrapolate backwards to 2010 using depreciation curves
 * 3. Extrapolate forward to 2026 using appreciation estimates
 * 4. Insert one row per brand/model/year combination
 * 5. Include Dubizzle marketplace slugs for direct linking
 * 
 * Run with: node server/seed-vehicle-models-v2.mjs
 */
import 'dotenv/config';
import mysql from 'mysql2/promise';
import { readFileSync, writeFileSync, unlinkSync } from 'fs';

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

// ─── Brand Metadata ───
const BRAND_META = {
  nissan:         { region: "japanese",  display: "Nissan",        dubizzle: "nissan" },
  toyota:         { region: "japanese",  display: "Toyota",        dubizzle: "toyota" },
  honda:          { region: "japanese",  display: "Honda",         dubizzle: "honda" },
  ford:           { region: "american",  display: "Ford",          dubizzle: "ford" },
  chevrolet:      { region: "american",  display: "Chevrolet",     dubizzle: "chevrolet" },
  dodge:          { region: "american",  display: "Dodge",         dubizzle: "dodge" },
  jeep:           { region: "american",  display: "Jeep",          dubizzle: "jeep" },
  ram:            { region: "american",  display: "Ram",           dubizzle: "ram" },
  gmc:            { region: "american",  display: "GMC",           dubizzle: "gmc" },
  hyundai:        { region: "korean",    display: "Hyundai",       dubizzle: "hyundai" },
  kia:            { region: "korean",    display: "Kia",           dubizzle: "kia" },
  bmw:            { region: "european",  display: "BMW",           dubizzle: "bmw" },
  "mercedes-benz":{ region: "european",  display: "Mercedes-Benz", dubizzle: "mercedes-benz" },
  lexus:          { region: "japanese",  display: "Lexus",         dubizzle: "lexus" },
  subaru:         { region: "japanese",  display: "Subaru",        dubizzle: "subaru" },
  tesla:          { region: "american",  display: "Tesla",         dubizzle: "tesla" },
  cadillac:       { region: "american",  display: "Cadillac",      dubizzle: "cadillac" },
  lincoln:        { region: "american",  display: "Lincoln",       dubizzle: "lincoln" },
  infiniti:       { region: "japanese",  display: "Infiniti",      dubizzle: "infiniti" },
  mazda:          { region: "japanese",  display: "Mazda",         dubizzle: "mazda" },
  volkswagen:     { region: "european",  display: "Volkswagen",    dubizzle: "volkswagen" },
  audi:           { region: "european",  display: "Audi",          dubizzle: "audi" },
  genesis:        { region: "korean",    display: "Genesis",       dubizzle: "genesis" },
  acura:          { region: "japanese",  display: "Acura",         dubizzle: "acura" },
  volvo:          { region: "european",  display: "Volvo",         dubizzle: "volvo" },
  porsche:        { region: "european",  display: "Porsche",       dubizzle: "porsche" },
  rivian:         { region: "american",  display: "Rivian",        dubizzle: "rivian" },
  lucid:          { region: "american",  display: "Lucid",         dubizzle: "lucid" },
  buick:          { region: "american",  display: "Buick",         dubizzle: "buick" },
  chrysler:       { region: "american",  display: "Chrysler",      dubizzle: "chrysler" },
  mitsubishi:     { region: "japanese",  display: "Mitsubishi",    dubizzle: "mitsubishi" },
  jaguar:         { region: "european",  display: "Jaguar",        dubizzle: "jaguar" },
  lamborghini:    { region: "european",  display: "Lamborghini",   dubizzle: "lamborghini" },
  ferrari:        { region: "european",  display: "Ferrari",       dubizzle: "ferrari" },
  "rolls-royce":  { region: "european",  display: "Rolls-Royce",   dubizzle: "rolls-royce" },
  bentley:        { region: "european",  display: "Bentley",       dubizzle: "bentley" },
  "aston martin": { region: "european",  display: "Aston Martin",  dubizzle: "aston-martin" },
  mclaren:        { region: "european",  display: "McLaren",       dubizzle: "mclaren" },
  "alfa romeo":   { region: "european",  display: "Alfa Romeo",    dubizzle: "alfa-romeo" },
  fiat:           { region: "european",  display: "Fiat",          dubizzle: "fiat" },
  mini:           { region: "european",  display: "Mini",          dubizzle: "mini" },
  maserati:       { region: "european",  display: "Maserati",      dubizzle: "maserati" },
  maybach:        { region: "european",  display: "Maybach",       dubizzle: "maybach" },
  suzuki:         { region: "japanese",  display: "Suzuki",        dubizzle: "suzuki" },
  smart:          { region: "european",  display: "Smart",         dubizzle: "smart" },
  peugeot:        { region: "european",  display: "Peugeot",       dubizzle: "peugeot" },
  renault:        { region: "european",  display: "Renault",       dubizzle: "renault" },
  "land rover":   { region: "european",  display: "Land Rover",    dubizzle: "land-rover" },
};

// ─── Dubizzle model slug mapping ───
// Maps lowercase model names to their Dubizzle URL slugs
const DUBIZZLE_MODEL_SLUGS = {
  // Nissan
  altima: "altima", maxima: "maxima", sentra: "sentra", pathfinder: "pathfinder",
  rogue: "rogue", murano: "murano", armada: "armada", kicks: "kicks",
  "370z": "370z", frontier: "frontier", titan: "titan",
  // Toyota
  camry: "camry", corolla: "corolla", "rav4": "rav-4", highlander: "highlander",
  "4runner": "4runner", tacoma: "tacoma", tundra: "tundra", supra: "supra",
  gr86: "gr86", sienna: "sienna", sequoia: "sequoia", prius: "prius",
  avalon: "avalon",
  // Honda
  civic: "civic", accord: "accord", "cr-v": "cr-v", "hr-v": "hr-v",
  pilot: "pilot", passport: "passport", ridgeline: "ridgeline", odyssey: "odyssey",
  // Ford
  "f-150": "f-150", mustang: "mustang", explorer: "explorer", escape: "escape",
  expedition: "expedition", bronco: "bronco", ranger: "ranger", maverick: "maverick",
  edge: "edge",
  // Chevrolet
  silverado: "silverado", camaro: "camaro", corvette: "corvette", tahoe: "tahoe",
  suburban: "suburban", traverse: "traverse", equinox: "equinox", blazer: "blazer",
  trailblazer: "trailblazer", colorado: "colorado", malibu: "malibu",
  // Dodge
  charger: "charger", challenger: "challenger", durango: "durango", hornet: "hornet",
  // Jeep
  "grand cherokee": "grand-cherokee", wrangler: "wrangler", gladiator: "gladiator",
  compass: "compass", wagoneer: "wagoneer", "grand wagoneer": "grand-wagoneer",
  // Ram
  "1500": "1500", "2500": "2500", "3500": "3500",
  // GMC
  sierra: "sierra", yukon: "yukon", acadia: "acadia", terrain: "terrain", canyon: "canyon",
  // Hyundai
  elantra: "elantra", sonata: "sonata", tucson: "tucson", "santa fe": "santa-fe",
  palisade: "palisade", kona: "kona", venue: "venue", "ioniq 5": "ioniq-5", "ioniq 6": "ioniq-6",
  // Kia
  forte: "forte", k5: "k5", sportage: "sportage", sorento: "sorento",
  telluride: "telluride", seltos: "seltos", carnival: "carnival",
  ev6: "ev6", ev9: "ev9", stinger: "stinger",
  // BMW
  "3 series": "3-series", "5 series": "5-series", "7 series": "7-series",
  x3: "x3", x5: "x5", x7: "x7", x1: "x1",
  m3: "m3", m4: "m4", m5: "m5", i4: "i4", i5: "i5", i7: "i7", ix: "ix",
  // Mercedes-Benz
  "c-class": "c-class", "e-class": "e-class", "s-class": "s-class",
  gle: "gle", glc: "glc", gls: "gls", gla: "gla", glb: "glb",
  "g-class": "g-class", "amg gt": "amg-gt", eqe: "eqe", eqs: "eqs",
  // Lexus
  es: "es", is: "is", ls: "ls", rx: "rx", nx: "nx", gx: "gx", lx: "lx", ux: "ux",
  // Subaru
  outback: "outback", forester: "forester", crosstrek: "crosstrek",
  wrx: "wrx", impreza: "impreza", ascent: "ascent",
  // Tesla
  "model 3": "model-3", "model y": "model-y", "model s": "model-s",
  "model x": "model-x", cybertruck: "cybertruck",
  // Cadillac
  escalade: "escalade", ct5: "ct5", ct4: "ct4", xt5: "xt5", xt4: "xt4", xt6: "xt6",
  // Lincoln
  aviator: "aviator", navigator: "navigator", corsair: "corsair",
  // Infiniti
  q50: "q50", q60: "q60", qx50: "qx50", qx60: "qx60", qx80: "qx80",
  // Mazda
  mazda3: "mazda-3", mazda6: "mazda-6", "cx-5": "cx-5", "cx-50": "cx-50",
  "cx-90": "cx-90", "cx-30": "cx-30", "mx-5": "mx-5",
  // Volkswagen
  golf: "golf", jetta: "jetta", tiguan: "tiguan", atlas: "atlas",
  "id.4": "id-4", taos: "taos", passat: "passat",
  // Audi
  a4: "a4", a6: "a6", a8: "a8", q5: "q5", q7: "q7", q8: "q8",
  q3: "q3", "e-tron": "e-tron", rs6: "rs6", rs7: "rs7",
  // Genesis
  g70: "g70", g80: "g80", g90: "g90", gv70: "gv70", gv80: "gv80",
  // Acura
  tlx: "tlx", integra: "integra", rdx: "rdx", mdx: "mdx",
  // Volvo
  s60: "s60", s90: "s90", xc60: "xc60", xc90: "xc90", xc40: "xc40", ex30: "ex30",
  // Porsche
  "911": "911", cayenne: "cayenne", macan: "macan", taycan: "taycan",
  "718": "718-boxster", panamera: "panamera",
  // Rivian
  r1t: "r1t", r1s: "r1s",
  // Lucid
  air: "air",
  // Buick
  enclave: "enclave", envision: "envision", encore: "encore",
  // Chrysler
  "300": "300", pacifica: "pacifica",
  // Mitsubishi
  outlander: "outlander", eclipse: "eclipse-cross",
  // Jaguar
  "f-pace": "f-pace", "e-pace": "e-pace", "i-pace": "i-pace",
  "f-type": "f-type", xe: "xe", xf: "xf",
  // Lamborghini
  urus: "urus", huracan: "huracan", aventador: "aventador", revuelto: "revuelto",
  // Ferrari
  "488": "488", f8: "f8", roma: "roma", sf90: "sf90", "296": "296", portofino: "portofino",
  // Rolls-Royce
  phantom: "phantom", ghost: "ghost", wraith: "wraith", cullinan: "cullinan", spectre: "spectre",
  // Bentley
  "continental gt": "continental-gt", "flying spur": "flying-spur", bentayga: "bentayga",
  // Aston Martin
  vantage: "vantage", db11: "db11", db12: "db12", dbx: "dbx",
  // McLaren
  "720s": "720s", artura: "artura", "765lt": "765lt",
  // Alfa Romeo
  giulia: "giulia", stelvio: "stelvio", tonale: "tonale",
  // Fiat
  "500": "500", "500x": "500x",
  // Mini
  cooper: "cooper", countryman: "countryman", clubman: "clubman",
  // Maserati
  ghibli: "ghibli", levante: "levante", quattroporte: "quattroporte",
  grecale: "grecale", mc20: "mc20",
  // Maybach
  "s-class maybach": "s-class",
  // Suzuki
  jimny: "jimny", vitara: "vitara", swift: "swift",
  // Smart
  fortwo: "fortwo", "#1": "smart-1",
  // Peugeot
  "3008": "3008", "5008": "5008",
  // Renault
  koleos: "koleos", duster: "duster", megane: "megane",
  // Land Rover
  "range rover": "range-rover", "range rover sport": "range-rover-sport",
  defender: "defender", discovery: "discovery", "range rover velar": "range-rover-velar",
  "range rover evoque": "range-rover-evoque",
};

// ─── Model category mapping ───
const MODEL_CATEGORIES = {
  "4runner": "suv", highlander: "suv", "rav4": "suv", sequoia: "suv",
  pathfinder: "suv", rogue: "suv", murano: "suv", armada: "suv",
  "cr-v": "suv", pilot: "suv", "hr-v": "suv", passport: "suv",
  explorer: "suv", expedition: "suv", bronco: "suv", escape: "suv",
  tahoe: "suv", suburban: "suv", traverse: "suv", trailblazer: "suv", blazer: "suv", equinox: "suv",
  durango: "suv", hornet: "suv",
  "grand cherokee": "suv", wrangler: "suv", gladiator: "truck", compass: "suv", wagoneer: "suv", "grand wagoneer": "suv",
  yukon: "suv", acadia: "suv", terrain: "suv",
  tucson: "suv", "santa fe": "suv", palisade: "suv", kona: "suv", venue: "suv",
  telluride: "suv", sportage: "suv", sorento: "suv", seltos: "suv", carnival: "van",
  x3: "suv", x5: "suv", x7: "suv", x1: "suv", ix: "electric",
  gle: "suv", glc: "suv", gls: "suv", gla: "suv", glb: "suv", "g-class": "suv",
  rx: "suv", nx: "suv", gx: "suv", lx: "suv", ux: "crossover",
  outback: "crossover", forester: "suv", crosstrek: "crossover", ascent: "suv",
  escalade: "suv", xt5: "suv", xt4: "crossover", xt6: "suv",
  aviator: "suv", navigator: "suv", corsair: "crossover",
  qx50: "suv", qx60: "suv", qx80: "suv",
  "cx-5": "suv", "cx-50": "suv", "cx-90": "suv", "cx-30": "crossover",
  tiguan: "suv", atlas: "suv", "id.4": "electric", taos: "crossover",
  q5: "suv", q7: "suv", q8: "suv", q3: "crossover", "e-tron": "electric",
  gv70: "suv", gv80: "suv",
  rdx: "suv", mdx: "suv",
  xc60: "suv", xc90: "suv", xc40: "crossover", ex30: "electric",
  cayenne: "suv", macan: "suv",
  "f-pace": "suv", "e-pace": "crossover", "i-pace": "electric",
  urus: "suv", bentayga: "suv", dbx: "suv", cullinan: "suv",
  levante: "suv", grecale: "suv",
  stelvio: "suv", tonale: "crossover",
  countryman: "crossover",
  jimny: "suv", vitara: "suv",
  "3008": "suv", "5008": "suv",
  koleos: "suv", duster: "suv",
  outlander: "suv", eclipse: "crossover",
  enclave: "suv", envision: "crossover", encore: "crossover",
  r1s: "electric",
  "f-150": "truck", ranger: "truck", maverick: "truck",
  silverado: "truck", colorado: "truck",
  "1500": "truck", "2500": "truck", "3500": "truck",
  sierra: "truck", canyon: "truck",
  tundra: "truck", tacoma: "truck",
  frontier: "truck", titan: "truck",
  ridgeline: "truck", r1t: "electric",
  "model 3": "electric", "model y": "electric", "model s": "electric", "model x": "electric", cybertruck: "electric",
  air: "electric", eqe: "electric", eqs: "electric", i4: "electric", i5: "electric", i7: "electric",
  "ioniq 5": "electric", "ioniq 6": "electric", ev6: "electric", ev9: "electric",
  "#1": "electric", megane: "electric",
  mustang: "sports", camaro: "sports", corvette: "sports", challenger: "sports", charger: "sports",
  supra: "sports", gr86: "sports", "370z": "sports",
  "amg gt": "sports", m3: "sports", m4: "sports", m5: "sports",
  "911": "sports", "718": "sports", taycan: "electric",
  "f-type": "sports", huracan: "sports", aventador: "sports", revuelto: "sports",
  "488": "sports", f8: "sports", roma: "sports", sf90: "sports", "296": "sports", portofino: "sports",
  "720s": "sports", artura: "sports", "765lt": "sports",
  vantage: "sports", db11: "sports", db12: "sports",
  mc20: "sports",
  "s-class": "luxury", phantom: "luxury", ghost: "luxury", wraith: "luxury", spectre: "luxury",
  "continental gt": "luxury", "flying spur": "luxury",
  ghibli: "luxury", quattroporte: "luxury",
  sienna: "van", odyssey: "van", pacifica: "van",
  "500": "hatchback", "500x": "hatchback", cooper: "hatchback", clubman: "hatchback",
  fortwo: "hatchback", swift: "hatchback",
  golf: "hatchback", jetta: "sedan",
  "range rover": "suv", "range rover sport": "suv", defender: "suv",
  discovery: "suv", "range rover velar": "suv", "range rover evoque": "suv",
  "s-class maybach": "luxury",
};

const BRAND_DEFAULT_CATEGORY = {
  nissan: "sedan", toyota: "sedan", honda: "sedan", ford: "sedan", chevrolet: "sedan",
  dodge: "sedan", jeep: "suv", ram: "truck", gmc: "truck", hyundai: "sedan", kia: "sedan",
  bmw: "sedan", "mercedes-benz": "sedan", lexus: "sedan", subaru: "sedan", tesla: "electric",
  cadillac: "luxury", lincoln: "luxury", infiniti: "sedan", mazda: "sedan", volkswagen: "sedan",
  audi: "sedan", genesis: "luxury", acura: "sedan", volvo: "sedan", porsche: "sports",
  rivian: "electric", lucid: "electric", buick: "sedan", chrysler: "sedan", mitsubishi: "suv",
  jaguar: "sedan", lamborghini: "sports", ferrari: "sports", "rolls-royce": "luxury",
  bentley: "luxury", "aston martin": "sports", mclaren: "sports", "alfa romeo": "sedan",
  fiat: "hatchback", mini: "hatchback", maserati: "luxury", maybach: "luxury",
  suzuki: "suv", smart: "hatchback", peugeot: "suv", renault: "suv", "land rover": "suv",
};

// ─── Depreciation / Appreciation Rates by Category ───
// Used to extrapolate prices for years not in PRICE_DB
const DEPRECIATION_RATES = {
  sedan:      0.13,  // 13% per year
  suv:        0.11,  // SUVs hold value better
  truck:      0.10,  // Trucks hold value well
  coupe:      0.14,
  hatchback:  0.14,
  van:        0.12,
  electric:   0.18,  // EVs depreciate faster
  sports:     0.08,  // Sports cars hold value
  luxury:     0.15,  // Luxury depreciates faster
  crossover:  0.12,
};

// New car appreciation rate (2025 -> 2026)
const NEW_CAR_APPRECIATION = 0.05; // 5% price increase for brand new

/**
 * Extrapolate price from a known year to a target year
 */
function extrapolatePrice(knownPrice, knownYear, targetYear, category) {
  const yearDiff = knownYear - targetYear; // positive = going backwards (older)
  const depRate = DEPRECIATION_RATES[category] || 0.12;
  
  if (yearDiff > 0) {
    // Going backwards (older car = cheaper)
    const factor = Math.pow(1 - depRate, yearDiff);
    return {
      low: Math.round(knownPrice.low * factor / 500) * 500,
      mid: Math.round(knownPrice.mid * factor / 500) * 500,
      high: Math.round(knownPrice.high * factor / 500) * 500,
    };
  } else if (yearDiff < 0) {
    // Going forward (newer car = more expensive)
    const factor = Math.pow(1 + NEW_CAR_APPRECIATION, Math.abs(yearDiff));
    return {
      low: Math.round(knownPrice.low * factor / 500) * 500,
      mid: Math.round(knownPrice.mid * factor / 500) * 500,
      high: Math.round(knownPrice.high * factor / 500) * 500,
    };
  }
  return knownPrice;
}

/**
 * Calculate US auction price estimate from UAE market price
 * US auction cars are typically 40-60% of UAE market price (in USD)
 */
function estimateAuctionPrice(uaeMarketMidAED, year, category) {
  const currentYear = 2026;
  const age = currentYear - year;
  // Older cars have lower auction-to-market ratio
  let ratio = 0.45; // base ratio
  if (age > 10) ratio = 0.35;
  else if (age > 5) ratio = 0.40;
  
  // Sports/luxury have higher auction prices relative to market
  if (category === "sports" || category === "luxury") ratio += 0.05;
  // EVs have lower auction prices
  if (category === "electric") ratio -= 0.05;
  
  return Math.round((uaeMarketMidAED * ratio) / 3.67); // Convert AED to USD
}

// ─── Capitalize model name for display ───
function capitalizeModel(model) {
  return model.split(/[\s-]/).map(w => {
    if (w.length <= 3 && w === w.toUpperCase()) return w;
    if (/^\d/.test(w)) return w;
    return w.charAt(0).toUpperCase() + w.slice(1);
  }).join(model.includes('-') ? '-' : ' ');
}

// ─── Model first production year (approximate) ───
// Some models didn't exist before certain years
const MODEL_FIRST_YEAR = {
  // EVs (most are recent)
  "model 3": 2017, "model y": 2020, "model s": 2012, "model x": 2015, cybertruck: 2024,
  "ioniq 5": 2022, "ioniq 6": 2023, ev6: 2022, ev9: 2024,
  "id.4": 2021, "e-tron": 2019, taycan: 2020, i4: 2022, i5: 2024, i7: 2023,
  eqe: 2023, eqs: 2022, ix: 2022, ex30: 2024, spectre: 2024,
  r1t: 2022, r1s: 2022, air: 2022, "#1": 2023,
  // Recent models
  bronco: 2021, maverick: 2022, hornet: 2023, trailblazer: 2021,
  gr86: 2022, supra: 2020, // new gen
  gladiator: 2020, wagoneer: 2022, "grand wagoneer": 2022,
  palisade: 2020, venue: 2020, seltos: 2021,
  "cx-50": 2023, "cx-90": 2024, "cx-30": 2020,
  gv70: 2022, gv80: 2021,
  integra: 2023, ex30: 2024,
  revuelto: 2024, "296": 2022, artura: 2022,
  db12: 2024, grecale: 2023, mc20: 2021, tonale: 2023,
  megane: 2022,
  // Discontinued models (set last year)
  camaro: 2024, // discontinued after 2024
  "370z": 2020, // replaced by Z
  maxima: 2023, // discontinued
};

async function main() {
  // Step 1: Extract PRICE_DB
  const tsContent = readFileSync('/home/ubuntu/uae-auction-calc/client/src/lib/marketPrices.ts', 'utf-8');
  const dbStart = tsContent.indexOf('const PRICE_DB');
  const dbDeclStart = tsContent.indexOf('{', dbStart);
  
  let braceCount = 0;
  let dbEnd = -1;
  for (let i = dbDeclStart; i < tsContent.length; i++) {
    if (tsContent[i] === '{') braceCount++;
    if (tsContent[i] === '}') braceCount--;
    if (braceCount === 0) { dbEnd = i + 1; break; }
  }
  
  const dbObjectStr = tsContent.substring(dbDeclStart, dbEnd);
  const tmpFile = '/tmp/price_db_extract_v2.mjs';
  writeFileSync(tmpFile, `export const PRICE_DB = ${dbObjectStr};\n`);
  const { PRICE_DB } = await import(tmpFile);
  unlinkSync(tmpFile);
  
  const makes = Object.keys(PRICE_DB);
  console.log(`Found ${makes.length} makes in PRICE_DB`);
  
  // Step 2: Build per-year rows
  const TARGET_YEARS = [];
  for (let y = 2010; y <= 2026; y++) TARGET_YEARS.push(y);
  
  const rows = [];
  let skippedCount = 0;
  
  for (const make of makes) {
    const models = Object.keys(PRICE_DB[make]);
    const meta = BRAND_META[make] || { region: "european", display: make.charAt(0).toUpperCase() + make.slice(1), dubizzle: make.toLowerCase().replace(/\s+/g, '-') };
    
    for (const model of models) {
      const yearData = PRICE_DB[make][model];
      const knownYears = Object.keys(yearData).map(Number).sort((a, b) => a - b);
      
      if (knownYears.length === 0) continue;
      
      const category = MODEL_CATEGORIES[model] || BRAND_DEFAULT_CATEGORY[make] || "sedan";
      const displayModel = capitalizeModel(model);
      const dubizzleModelSlug = DUBIZZLE_MODEL_SLUGS[model] || model.toLowerCase().replace(/\s+/g, '-');
      
      // Determine valid year range for this model
      const firstYear = MODEL_FIRST_YEAR[model] || 2010;
      const lastYear = MODEL_FIRST_YEAR[model] && model in { camaro: 1, "370z": 1, maxima: 1 } 
        ? MODEL_FIRST_YEAR[model] 
        : 2026;
      
      for (const targetYear of TARGET_YEARS) {
        // Skip years before model existed
        if (targetYear < firstYear) {
          skippedCount++;
          continue;
        }
        // Skip years after model was discontinued
        if (model === "camaro" && targetYear > 2024) { skippedCount++; continue; }
        if (model === "370z" && targetYear > 2020) { skippedCount++; continue; }
        if (model === "maxima" && targetYear > 2023) { skippedCount++; continue; }
        
        let price;
        
        if (yearData[targetYear]) {
          // We have exact data for this year
          price = yearData[targetYear];
        } else if (targetYear < knownYears[0]) {
          // Extrapolate backwards from earliest known year
          price = extrapolatePrice(yearData[knownYears[0]], knownYears[0], targetYear, category);
        } else if (targetYear > knownYears[knownYears.length - 1]) {
          // Extrapolate forward from latest known year
          price = extrapolatePrice(yearData[knownYears[knownYears.length - 1]], knownYears[knownYears.length - 1], targetYear, category);
        } else {
          // Interpolate between two known years
          let lowerYear = knownYears[0];
          let upperYear = knownYears[knownYears.length - 1];
          for (const ky of knownYears) {
            if (ky <= targetYear) lowerYear = ky;
            if (ky >= targetYear && upperYear === knownYears[knownYears.length - 1]) upperYear = ky;
          }
          // Use the closer known year
          const closerYear = (targetYear - lowerYear) <= (upperYear - targetYear) ? lowerYear : upperYear;
          price = extrapolatePrice(yearData[closerYear], closerYear, targetYear, category);
        }
        
        // Ensure minimum prices
        price.low = Math.max(price.low, 5000);
        price.mid = Math.max(price.mid, 7000);
        price.high = Math.max(price.high, 10000);
        
        const auctionAvgUSD = estimateAuctionPrice(price.mid, targetYear, category);
        
        rows.push({
          brand: meta.display,
          model: displayModel,
          region: meta.region,
          category,
          year: targetYear,
          uaeMarketPriceLow: price.low,
          uaeMarketPriceMid: price.mid,
          uaeMarketPriceHigh: price.high,
          auctionAvgPriceUSD: auctionAvgUSD,
          dubizzleBrandSlug: meta.dubizzle,
          dubizzleModelSlug,
        });
      }
    }
    
    const brandModels = Object.keys(PRICE_DB[make]).length;
    const brandRows = rows.filter(r => r.brand === meta.display).length;
    console.log(`  ${meta.display}: ${brandModels} models × years = ${brandRows} rows`);
  }
  
  console.log(`\nTotal: ${rows.length} rows to seed (skipped ${skippedCount} invalid year combos)`);
  
  // Step 3: Insert into database
  const conn = await mysql.createConnection(DATABASE_URL);
  
  // Clear existing data
  await conn.execute("DELETE FROM vehicleModels");
  console.log("Cleared existing data");
  
  // Insert in batches
  const batchSize = 100;
  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const placeholders = batch.map(() => "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())").join(", ");
    const values = batch.flatMap(r => [
      r.brand, r.model, r.region, r.category,
      r.year,
      r.uaeMarketPriceLow, r.uaeMarketPriceMid, r.uaeMarketPriceHigh,
      r.auctionAvgPriceUSD,
      r.dubizzleBrandSlug, r.dubizzleModelSlug
    ]);

    await conn.execute(
      `INSERT INTO vehicleModels (brand, model, region, category, year, uaeMarketPriceLow, uaeMarketPriceMid, uaeMarketPriceHigh, auctionAvgPriceUSD, dubizzleBrandSlug, dubizzleModelSlug, isActive, createdAt, updatedAt) VALUES ${placeholders}`,
      values
    );
    
    if ((i + batchSize) % 500 === 0 || i + batchSize >= rows.length) {
      console.log(`  Inserted ${Math.min(i + batchSize, rows.length)}/${rows.length} rows...`);
    }
  }
  
  // Verify
  const [summary] = await conn.execute("SELECT COUNT(DISTINCT brand) as brands, COUNT(DISTINCT model) as models, COUNT(*) as total, MIN(year) as minYear, MAX(year) as maxYear FROM vehicleModels");
  console.log(`\nDone! Database now has:`);
  console.log(`  ${summary[0].brands} brands`);
  console.log(`  ${summary[0].models} unique models`);
  console.log(`  ${summary[0].total} total rows (per-year entries)`);
  console.log(`  Year range: ${summary[0].minYear} - ${summary[0].maxYear}`);
  
  // Show sample data
  const [sample] = await conn.execute("SELECT brand, model, year, uaeMarketPriceLow, uaeMarketPriceMid, uaeMarketPriceHigh, dubizzleBrandSlug, dubizzleModelSlug FROM vehicleModels WHERE brand = 'Toyota' AND model = 'Camry' ORDER BY year LIMIT 17");
  console.log(`\nSample: Toyota Camry per-year pricing:`);
  for (const row of sample) {
    console.log(`  ${row.year}: ${row.uaeMarketPriceLow.toLocaleString()} - ${row.uaeMarketPriceMid.toLocaleString()} - ${row.uaeMarketPriceHigh.toLocaleString()} AED | dubizzle: ${row.dubizzleBrandSlug}/${row.dubizzleModelSlug}/${row.year}/`);
  }
  
  await conn.end();
}

main().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
