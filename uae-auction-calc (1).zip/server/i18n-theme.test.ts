/**
 * Tests for i18n translation system and theme toggle
 * Validates that translation keys exist for both languages
 * and that the translation lookup works correctly
 */
import { describe, it, expect } from "vitest";

// We test the translation data structure directly since the React context
// is a thin wrapper around this data

// Import the translations by reading the file content
// Since the translations are in a React context file, we test the data structure
describe("i18n translations", () => {
  // Core translation keys that must exist in both languages
  const requiredKeys = [
    // Navigation
    "nav.home",
    "nav.calculator",
    "nav.feeGuide",
    "nav.dealQueue",
    "nav.brand",
    "nav.brandAccent",
    "nav.subtitle",

    // Home page
    "home.badge",
    "home.title1",
    "home.titleAccent",
    "home.title2",
    "home.subtitle",
    "home.startCalc",
    "home.feeRef",

    // Calculator
    "calc.title",
    "calc.titleAccent",
    "calc.subtitle",
    "calc.reset",
    "calc.step1",
    "calc.decode",
    "calc.searching",
    "calc.vehicleFound",
    "calc.step2",
    "calc.bidAmount",
    "calc.step3",
    "calc.shippingCost",
    "calc.step4",
    "calc.step5",
    "calc.step6",

    // Fee Guide
    "feeGuide.title",
    "feeGuide.titleAccent",
    "feeGuide.subtitle",

    // Deal Queue
    "dealQueue.title",
    "dealQueue.titleAccent",
    "dealQueue.subtitle",

    // Settings
    "settings.language",
    "settings.theme",
    "settings.dark",
    "settings.light",
  ];

  it("should have all required English translation keys", async () => {
    // Read the LanguageContext file to extract translations
    const fs = await import("fs");
    const content = fs.readFileSync(
      "./client/src/contexts/LanguageContext.tsx",
      "utf-8"
    );

    for (const key of requiredKeys) {
      expect(content).toContain(`"${key}"`);
    }
  });

  it("should have Arabic translations for all required keys", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(
      "./client/src/contexts/LanguageContext.tsx",
      "utf-8"
    );

    // The file should have an 'ar' section
    expect(content).toContain('"ar"');

    // Check that Arabic translations exist (they appear after the ar: { section)
    // We verify by checking the key appears at least twice (once in en, once in ar)
    for (const key of requiredKeys) {
      const regex = new RegExp(`"${key.replace(".", "\\.")}"`, "g");
      const matches = content.match(regex);
      expect(
        matches && matches.length >= 2,
        `Key "${key}" should appear in both en and ar translations`
      ).toBe(true);
    }
  });

  it("should have RTL direction for Arabic", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(
      "./client/src/contexts/LanguageContext.tsx",
      "utf-8"
    );

    // Check that the context provides RTL direction
    expect(content).toContain('"rtl"');
    expect(content).toContain('"ltr"');
    expect(content).toContain('isRTL');
  });
});

describe("Theme system", () => {
  it("should have dark and light theme CSS variables", async () => {
    const fs = await import("fs");
    const css = fs.readFileSync("./client/src/index.css", "utf-8");

    // Light theme (root)
    expect(css).toContain(":root {");
    expect(css).toContain("--background:");
    expect(css).toContain("--foreground:");
    expect(css).toContain("--primary:");

    // Dark theme
    expect(css).toContain(".dark {");
  });

  it("should have glass-card styles for both themes", async () => {
    const fs = await import("fs");
    const css = fs.readFileSync("./client/src/index.css", "utf-8");

    expect(css).toContain(".glass-card {");
    expect(css).toContain(".dark .glass-card {");
  });

  it("should have text-gradient styles for both themes", async () => {
    const fs = await import("fs");
    const css = fs.readFileSync("./client/src/index.css", "utf-8");

    expect(css).toContain(".text-gradient {");
    expect(css).toContain(".dark .text-gradient {");
  });

  it("ThemeContext should toggle between light and dark", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(
      "./client/src/contexts/ThemeContext.tsx",
      "utf-8"
    );

    // Check that the theme context supports toggling
    expect(content).toContain("toggleTheme");
    expect(content).toContain('"light"');
    expect(content).toContain('"dark"');
    expect(content).toContain('classList');
    // Check localStorage persistence
    expect(content).toContain('localStorage');
  });

  it("should have Arabic font defined in CSS", async () => {
    const fs = await import("fs");
    const css = fs.readFileSync("./client/src/index.css", "utf-8");

    expect(css).toContain("--font-arabic:");
    expect(css).toContain("Noto Sans Arabic");
    expect(css).toContain('[dir="rtl"]');
  });
});
