import { describe, it, expect } from "vitest";

// ─── Auction Router Tests ───
describe("Auction Router - VIN Search (auction-api.app + AutoBidCar + NHTSA)", () => {
  it("should return correct data structure from searchVin endpoint", async () => {
    const response = await fetch(
      `http://localhost:3000/api/trpc/auction.searchVin?batch=1&input=${encodeURIComponent(
        JSON.stringify({ "0": { json: { vin: "1FA6P8CF5N5100001" } } })
      )}`
    );
    const data = await response.json();

    expect(data).toBeInstanceOf(Array);
    expect(data[0]).toHaveProperty("result");
    expect(data[0].result).toHaveProperty("data");

    const result = data[0].result.data.json;
    expect(result).toHaveProperty("source");
    expect(result).toHaveProperty("vehicleInfo");
    expect(result).toHaveProperty("lots");
    expect(result).toHaveProperty("hasAuctionData");
    expect(["nhtsa", "autobidcar", "auction-api"]).toContain(result.source);
  }, 30000);

  it("should return vehicle info with correct fields from NHTSA", async () => {
    const response = await fetch(
      `http://localhost:3000/api/trpc/auction.searchVin?batch=1&input=${encodeURIComponent(
        JSON.stringify({ "0": { json: { vin: "1FA6P8CF5N5100001" } } })
      )}`
    );
    const data = await response.json();
    const vehicleInfo = data[0].result.data.json.vehicleInfo;

    expect(vehicleInfo).toHaveProperty("vin");
    expect(vehicleInfo).toHaveProperty("year");
    expect(vehicleInfo).toHaveProperty("make");
    expect(vehicleInfo).toHaveProperty("model");
    expect(vehicleInfo.vin).toBe("1FA6P8CF5N5100001");
    expect(vehicleInfo.year).toBe(2022);
    expect(vehicleInfo.make).toBe("FORD");
    expect(vehicleInfo.model).toBe("Mustang");
  }, 30000);

  it("should return auction data structure for a known VIN (may not have lots if API not activated)", async () => {
    const response = await fetch(
      `http://localhost:3000/api/trpc/auction.searchVin?batch=1&input=${encodeURIComponent(
        JSON.stringify({ "0": { json: { vin: "2C3CDXCT0PH548350" } } })
      )}`
    );
    const data = await response.json();
    const result = data[0].result.data.json;

    // Should always have vehicle info from NHTSA
    expect(result.vehicleInfo).toBeTruthy();
    expect(result.lots).toBeInstanceOf(Array);
    expect(typeof result.hasAuctionData).toBe("boolean");

    // If auction data is available, validate lot structure
    if (result.hasAuctionData && result.lots.length > 0) {
      const lot = result.lots[0];
      expect(lot.vin).toBeTruthy();
      expect(lot.make).toBeTruthy();
      expect(lot.model).toBeTruthy();
      expect(lot.source).toMatch(/copart|iaai/);
      expect(lot.images).toBeInstanceOf(Array);
    }
  }, 30000);

  it("should return apiStatus with correct source info", async () => {
    const response = await fetch(
      `http://localhost:3000/api/trpc/auction.apiStatus?batch=1&input=${encodeURIComponent(
        JSON.stringify({ "0": { json: null } })
      )}`
    );
    const data = await response.json();
    const status = data[0].result.data.json;

    expect(status.hasAuctionApi).toBe(true);
    expect(status.primarySource).toBeDefined();
    expect(["auction-api.app", "autobidcar"]).toContain(status.primarySource);
    expect(status.message).toBeTruthy();
  }, 10000);

  it("should reject invalid VIN (too short)", async () => {
    const response = await fetch(
      `http://localhost:3000/api/trpc/auction.searchVin?batch=1&input=${encodeURIComponent(
        JSON.stringify({ "0": { json: { vin: "ABC" } } })
      )}`
    );
    const data = await response.json();
    expect(data[0]).toHaveProperty("error");
  }, 10000);
});

// ─── Damage Analysis Router Tests ───
describe("Damage Analysis Router", () => {
  it("should reject empty image array", async () => {
    const resp = await fetch(
      `http://localhost:3000/api/trpc/damageAnalysis.analyze?batch=1`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          "0": { json: { imageUrls: [] } },
        }),
      }
    );
    const data = await resp.json();
    expect(data?.[0]?.error).toBeDefined();
  }, 10000);

  it("should reject invalid URLs", async () => {
    const resp = await fetch(
      `http://localhost:3000/api/trpc/damageAnalysis.analyze?batch=1`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          "0": { json: { imageUrls: ["not-a-url"] } },
        }),
      }
    );
    const data = await resp.json();
    expect(data?.[0]?.error).toBeDefined();
  }, 10000);

  it("should accept valid image URLs and return structured analysis", async () => {
    // Use a real auction image URL for testing
    const testImageUrl =
      "https://cdn.autobidcar.com/cars/2C3CDXCT0PH548350/main/2C3CDXCT0PH548350-1.jpg";

    const resp = await fetch(
      `http://localhost:3000/api/trpc/damageAnalysis.analyze?batch=1`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          "0": {
            json: {
              imageUrls: [testImageUrl],
              vehicleInfo: {
                year: "2023",
                make: "Dodge",
                model: "Charger",
                primaryDamage: "VANDALIZED",
              },
            },
          },
        }),
      }
    );
    const data = await resp.json();
    const result = data?.[0]?.result?.data?.json;

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(result.analysis).toBeDefined();
    expect(result.analysis.overallSeverity).toMatch(
      /minor|moderate|severe|total_loss/
    );
    expect(result.analysis.overallSeverityScore).toBeGreaterThanOrEqual(1);
    expect(result.analysis.overallSeverityScore).toBeLessThanOrEqual(10);
    expect(result.analysis.summary).toBeTruthy();
    expect(result.analysis.damages).toBeDefined();
    expect(Array.isArray(result.analysis.damages)).toBe(true);
    expect(result.analysis.estimatedTotalRepairAED).toBeDefined();
    expect(result.analysis.estimatedTotalRepairAED.low).toBeGreaterThanOrEqual(0);
    expect(result.analysis.estimatedTotalRepairAED.high).toBeGreaterThanOrEqual(0);
    expect(result.analysis.recommendations).toBeDefined();
    expect(Array.isArray(result.analysis.recommendations)).toBe(true);
    expect(result.photosAnalyzed).toBe(1);
  }, 60000); // LLM calls can take a while
});
