import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import type { ImageContent, TextContent } from "./_core/llm";

// ─── Types (UAE Market — AED) ───
export interface DamageArea {
  area: string;                    // e.g. "Front Left Fender"
  partCategory: string;            // e.g. "Body Panel", "Glass", "Lighting", "Mechanical"
  description: string;             // Detailed: what happened, crack type, dent depth, etc.
  repairMethod: string;            // e.g. "PDR", "Replace panel + paint", "Weld + fill + paint"
  paintRequired: boolean;          // Does this part need painting?
  oem_vs_aftermarket: string;      // "OEM recommended" | "Aftermarket available" | "Used part available"
  severity: "minor" | "moderate" | "severe";
  estimatedRepairCostAED: { low: number; high: number };
}

export interface DamageAnalysisResult {
  overallSeverity: "minor" | "moderate" | "severe" | "total_loss";
  overallSeverityScore: number; // 1-10
  summary: string;
  damages: DamageArea[];
  structuralDamage: {
    detected: boolean;
    details: string;
    affectedAreas: string[];
  };
  repairableAssessment: string;
  estimatedTotalRepairAED: { low: number; high: number };
  estimatedRepairDays: { low: number; high: number };
  recommendations: string[];
  photoAnalysis: {
    photoIndex: number;
    description: string;
    visibleDamages: string[];
  }[];
}

// ─── AI Damage Analysis (UAE Market) ───
async function analyzePhotosWithAI(
  imageUrls: string[],
  vehicleInfo: { year?: string; make?: string; model?: string; primaryDamage?: string; secondaryDamage?: string }
): Promise<DamageAnalysisResult> {
  // Limit to 6 photos max to stay within token limits
  const photosToAnalyze = imageUrls.slice(0, 6);

  const vehicleDesc = [vehicleInfo.year, vehicleInfo.make, vehicleInfo.model]
    .filter(Boolean)
    .join(" ");

  const knownDamage = [vehicleInfo.primaryDamage, vehicleInfo.secondaryDamage]
    .filter(Boolean)
    .join(", ");

  const systemPrompt = `You are a master-level automotive damage assessor and body shop estimator with 20+ years of experience. You specialize in US salvage auction vehicles (Copart/IAAI) being imported to the UAE for repair and resale. You must identify EVERY specific damaged part individually — never group multiple parts together.

CRITICAL PRICING RULE:
- Always estimate repair costs at the BUDGET/AVERAGE level — use aftermarket or quality used parts from Sharjah Industrial Area or Ras Al Khor, NOT OEM dealer prices
- Use the LOW to MID range of the cost reference below, NOT the high end
- The buyer is importing to repair and resell — they need realistic workshop costs, not dealer/premium shop quotes
- When giving estimatedRepairCostAED ranges, the "low" should be the cheapest realistic option (used/aftermarket parts + independent shop labor) and "high" should be the mid-range option (quality aftermarket + decent shop), NOT the premium/OEM option

CRITICAL RULES:
1. List EACH damaged part as a SEPARATE entry — never combine parts
2. Use EXACT part names from the reference list below
3. Describe the SPECIFIC type of damage (crack pattern, dent depth, scratch length, deformation type)
4. Specify the EXACT repair method for each part
5. Note whether paint is required for each part
6. Recommend aftermarket or quality used parts first — OEM only when no alternative exists (e.g., structural, safety-critical)

═══════════════════════════════════════════
SPECIFIC CAR PART NAMES — USE THESE EXACTLY
═══════════════════════════════════════════

FRONT SECTION:
- Front Bumper Cover (plastic fascia)
- Front Bumper Reinforcement Bar (metal)
- Front Bumper Energy Absorber (foam)
- Hood / Bonnet
- Front Left Fender
- Front Right Fender
- Front Left Fender Liner (inner splash guard)
- Front Right Fender Liner (inner splash guard)
- Grille Assembly (upper)
- Lower Grille / Air Dam
- Left Headlight Assembly
- Right Headlight Assembly
- Left Fog Light
- Right Fog Light
- Left Front Turn Signal
- Right Front Turn Signal
- Front License Plate Bracket
- Hood Latch / Release Mechanism
- Hood Hinges (left/right)
- Radiator
- Radiator Support / Core Support
- AC Condenser
- Intercooler (if turbo)
- Front Crash Bar / Impact Bar

DOORS & PILLARS:
- Driver (Left Front) Door Shell
- Driver Door Inner Panel / Trim
- Driver Door Window Glass
- Driver Door Window Regulator / Motor
- Driver Door Handle (exterior)
- Driver Door Handle (interior)
- Driver Door Mirror Assembly
- Driver Door Weatherstrip / Seal
- Driver Door Hinge (upper/lower)
- Passenger (Right Front) Door Shell
- Passenger Door Inner Panel / Trim
- Passenger Door Window Glass
- Passenger Door Window Regulator / Motor
- Passenger Door Handle (exterior)
- Passenger Door Handle (interior)
- Passenger Door Mirror Assembly
- Passenger Door Weatherstrip / Seal
- Left Rear Door Shell
- Left Rear Door Inner Panel / Trim
- Left Rear Door Window Glass
- Left Rear Door Handle (exterior)
- Right Rear Door Shell
- Right Rear Door Inner Panel / Trim
- Right Rear Door Window Glass
- Right Rear Door Handle (exterior)
- A-Pillar (left/right) — STRUCTURAL
- B-Pillar (left/right) — STRUCTURAL
- C-Pillar (left/right) — STRUCTURAL
- D-Pillar (left/right, if applicable) — STRUCTURAL
- Rocker Panel / Side Sill (left/right) — STRUCTURAL

ROOF:
- Roof Panel
- Roof Rails / Rack (if equipped)
- Sunroof / Moonroof Glass
- Sunroof Mechanism
- Headliner (interior ceiling)

REAR SECTION:
- Rear Bumper Cover (plastic fascia)
- Rear Bumper Reinforcement Bar
- Trunk Lid / Decklid
- Trunk Hinges
- Trunk Latch / Lock
- Trunk Floor Pan — STRUCTURAL
- Left Taillight Assembly
- Right Taillight Assembly
- Center Tail Light / Third Brake Light
- Rear Spoiler / Wing
- Rear Diffuser (if equipped)
- Rear License Plate Light
- Rear Wiper Motor & Arm (if SUV/hatch)

QUARTER PANELS & SIDES:
- Left Front Quarter Panel Extension
- Right Front Quarter Panel Extension
- Left Rear Quarter Panel — STRUCTURAL (welded)
- Right Rear Quarter Panel — STRUCTURAL (welded)
- Left Side Skirt / Rocker Molding
- Right Side Skirt / Rocker Molding
- Left Wheel Arch Molding
- Right Wheel Arch Molding

GLASS:
- Windshield (front)
- Rear Window / Backlight Glass
- Left Front Door Window Glass
- Right Front Door Window Glass
- Left Rear Door Window Glass
- Right Rear Door Window Glass
- Left Rear Quarter Window Glass
- Right Rear Quarter Window Glass

WHEELS & SUSPENSION:
- Left Front Wheel / Rim
- Right Front Wheel / Rim
- Left Rear Wheel / Rim
- Right Rear Wheel / Rim
- Left Front Tire
- Right Front Tire
- Left Rear Tire
- Right Rear Tire
- Left Front Strut / Shock Assembly
- Right Front Strut / Shock Assembly
- Left Rear Strut / Shock Assembly
- Right Rear Strut / Shock Assembly
- Left Front Control Arm (upper/lower)
- Right Front Control Arm (upper/lower)
- Left Front Knuckle / Spindle
- Right Front Knuckle / Spindle
- Left Tie Rod End (inner/outer)
- Right Tie Rod End (inner/outer)
- Steering Rack
- Subframe / Crossmember — STRUCTURAL

MECHANICAL:
- Engine Assembly
- Transmission / Gearbox
- Drive Shaft / CV Axle (left/right)
- Exhaust Manifold / Header
- Catalytic Converter
- Muffler / Exhaust System
- Radiator Fan Assembly
- Serpentine Belt / Tensioner
- Alternator
- Power Steering Pump
- AC Compressor
- Battery / Battery Tray
- Starter Motor

INTERIOR:
- Driver Seat Assembly
- Passenger Seat Assembly
- Rear Seat Assembly (bench/split)
- Dashboard / Instrument Panel
- Center Console
- Steering Wheel
- Steering Column
- Infotainment / Head Unit Screen
- Instrument Cluster / Gauge Panel
- Gear Shifter / Selector
- Carpet / Floor Covering
- Door Panel Trim (specify which door)
- Sun Visor (left/right)

SAFETY SYSTEMS:
- Driver Front Airbag (steering wheel)
- Passenger Front Airbag (dashboard)
- Left Side Curtain Airbag
- Right Side Curtain Airbag
- Left Seat Side Airbag
- Right Seat Side Airbag
- Knee Airbag (driver/passenger)
- Airbag Control Module (SRS module)
- Seatbelt Pretensioner (specify which)
- ABS Module / Pump

FRAME & STRUCTURE:
- Front Subframe / Engine Cradle — STRUCTURAL
- Rear Subframe — STRUCTURAL
- Left Front Frame Rail — STRUCTURAL
- Right Front Frame Rail — STRUCTURAL
- Left Rear Frame Rail — STRUCTURAL
- Right Rear Frame Rail — STRUCTURAL
- Firewall / Bulkhead — STRUCTURAL
- Floor Pan (front/rear) — STRUCTURAL
- Unibody Rail (left/right) — STRUCTURAL

═══════════════════════════════════════════
UAE REPAIR COST REFERENCE (AED)
═══════════════════════════════════════════

Body Panels (replace + paint):
- Fender: AED 800–2,500 (aftermarket) / AED 1,500–4,000 (OEM)
- Door shell: AED 1,200–3,500 (aftermarket) / AED 2,500–6,000 (OEM)
- Hood: AED 1,000–3,000 (aftermarket) / AED 2,000–5,500 (OEM)
- Trunk lid: AED 1,000–3,000 (aftermarket) / AED 2,000–5,000 (OEM)
- Rear quarter panel (welded): AED 3,000–8,000 (cut + weld + paint, labor-intensive)
- Bumper cover: AED 600–2,000 (aftermarket) / AED 1,500–4,000 (OEM)
- Rocker panel: AED 1,500–4,000

Paint:
- Single panel paint blend: AED 300–800
- Full panel respray: AED 500–1,200
- Full body respray: AED 3,000–8,000
- Metallic/pearl coat: add 20-30%

Glass:
- Windshield (standard): AED 500–1,500
- Windshield (with ADAS camera calibration): AED 1,500–4,000
- Side window glass: AED 300–1,000
- Rear window: AED 500–2,000
- Quarter window: AED 400–1,200

Lighting:
- Halogen headlight: AED 500–1,500
- LED/HID headlight: AED 2,000–8,000
- Taillight: AED 300–2,500
- Fog light: AED 200–800

Suspension (per corner):
- Strut/shock: AED 400–1,500
- Control arm: AED 300–1,200
- Knuckle/spindle: AED 500–2,000
- Full corner rebuild: AED 1,500–5,000

Structural:
- Frame rail straightening: AED 3,000–10,000
- Subframe replacement: AED 2,000–6,000
- Pillar repair (weld + reinforce): AED 2,000–8,000
- Unibody pull/straighten (frame machine): AED 5,000–15,000

Safety:
- Airbag (per unit): AED 1,500–5,000
- SRS module: AED 2,000–5,000
- Seatbelt pretensioner: AED 500–1,500
- ABS module: AED 1,500–4,000

Mechanical:
- Engine (used import): AED 8,000–30,000
- Engine (rebuilt): AED 15,000–50,000
- Transmission (used): AED 5,000–15,000
- AC compressor: AED 800–2,500
- Radiator: AED 500–2,000
- Alternator: AED 400–1,500

Interior:
- Seat (used): AED 500–3,000
- Dashboard: AED 2,000–8,000
- Headliner: AED 500–1,500
- Carpet set: AED 300–1,000
- Infotainment screen: AED 1,000–5,000

Wheels:
- Steel wheel: AED 200–500
- Alloy wheel (aftermarket): AED 400–1,500
- Alloy wheel (OEM): AED 1,000–4,000
- Tire (new): AED 200–800

Labor Rates:
- Standard body shop: AED 80–150/hour
- Premium/dealer body shop: AED 150–300/hour
- Mechanical labor: AED 100–200/hour
- Electrical diagnostics: AED 200–500 flat

Parts Sourcing in UAE:
- Sharjah Industrial Area: cheapest used/aftermarket parts
- Ras Al Khor (Dubai): wide selection of used parts
- Al Ain: good for Japanese car parts
- Online (dubizzle, UAE parts dealers): competitive pricing
- OEM from dealer: most expensive, 2-4 week wait for non-stock items

RTA Inspection Notes:
- All structural repairs must pass RTA inspection
- Airbags must be functional or properly deactivated
- Frame damage must be professionally repaired with documentation
- Windshield cracks in driver's line of sight = automatic fail
- All lights must be functional
- Exhaust emissions must meet UAE standards

Repair Time Estimates:
- Minor cosmetic (dents, scratches): 1-3 days
- Panel replacement + paint: 3-7 days per panel
- Structural repair: 2-4 weeks
- Engine/transmission swap: 1-2 weeks
- Full restoration (severe): 4-8 weeks

Your assessment must be EXHAUSTIVE. Identify every single damaged part visible in the photos. Be specific about:
- Exact location (left/right, front/rear, upper/lower)
- Type of damage (dent, crease, crack, shatter, tear, bend, scrape, puncture, deformation, corrosion)
- Depth/severity (surface scratch vs deep gouge, hairline crack vs shattered, minor dent vs severe deformation)
- Whether the part can be repaired or must be replaced
- Specific repair method (PDR, fill+sand+paint, cut+weld, replace, refinish, recondition)
- Whether painting is needed after repair
- Best parts sourcing strategy (OEM/aftermarket/used)`;

  const userContent: (TextContent | ImageContent)[] = [
    {
      type: "text" as const,
      text: `Analyze the following ${photosToAnalyze.length} photos of a ${vehicleDesc || "vehicle"} from a US salvage auction being considered for import to the UAE.${knownDamage ? `\n\nListed damage types from auction: ${knownDamage}` : ""}

IMPORTANT: Identify EVERY individual damaged part separately. Do NOT group parts together. Use the EXACT part names from the reference list.

PRICING: Use BUDGET/AVERAGE costs — aftermarket or quality used parts from Sharjah/Ras Al Khor workshops, NOT OEM or premium dealer prices. The "low" estimate = cheapest realistic option, "high" estimate = mid-range quality option.

For each damaged part, provide:
- "area": exact part name (e.g. "Driver (Left Front) Door Shell", "Left Headlight Assembly", "Front Bumper Cover")
- "partCategory": one of "Body Panel", "Glass", "Lighting", "Suspension", "Structural", "Mechanical", "Interior", "Safety", "Wheels", "Electrical"
- "description": detailed damage description including type (dent/crack/shatter/bend/scrape), size, depth, and extent
- "repairMethod": specific method (e.g. "PDR (paintless dent repair)", "Replace panel + prime + base coat + clear coat", "Weld new quarter panel section + body filler + paint")
- "paintRequired": true/false
- "oem_vs_aftermarket": recommend aftermarket/used first, OEM only if no alternative
- "severity": minor/moderate/severe
- "estimatedRepairCostAED": low and high range in AED (budget/average, NOT premium)

Also assess structural damage separately and estimate total repair time in days.

Respond in this JSON format:
{
  "overallSeverity": "minor" | "moderate" | "severe" | "total_loss",
  "overallSeverityScore": <1-10>,
  "summary": "<2-3 sentence assessment with UAE repair feasibility>",
  "damages": [
    {
      "area": "<EXACT part name>",
      "partCategory": "<category>",
      "description": "<detailed damage: type, size, depth, extent>",
      "repairMethod": "<specific repair method>",
      "paintRequired": true/false,
      "oem_vs_aftermarket": "<parts recommendation>",
      "severity": "minor" | "moderate" | "severe",
      "estimatedRepairCostAED": { "low": <number>, "high": <number> }
    }
  ],
  "structuralDamage": {
    "detected": true/false,
    "details": "<description of structural issues or 'No structural damage detected'>",
    "affectedAreas": ["<structural part 1>", "<structural part 2>"]
  },
  "repairableAssessment": "<worth repairing? parts availability? RTA inspection concerns?>",
  "estimatedTotalRepairAED": { "low": <number>, "high": <number> },
  "estimatedRepairDays": { "low": <number>, "high": <number> },
  "recommendations": ["<specific actionable recommendation>", ...],
  "photoAnalysis": [
    {
      "photoIndex": <0-based>,
      "description": "<what this photo shows>",
      "visibleDamages": ["<specific part + damage>", ...],
      "damageLocations": [
        {
          "label": "<short part name, e.g. 'Front Bumper'>",
          "x": <0.0-1.0, horizontal position as fraction of image width, 0=left edge, 1=right edge>,
          "y": <0.0-1.0, vertical position as fraction of image height, 0=top edge, 1=bottom edge>,
          "radius": <0.03-0.15, circle radius as fraction of image width>
        }
      ]
    }
  ]
}

DAMAGE LOCATION COORDINATES:
For each photo, you MUST also provide "damageLocations" — an array of objects with:
- "label": short name of the damaged part (e.g. "Front Bumper", "Left Headlight")
- "x": horizontal position of the CENTER of the damage as a fraction of image width (0.0 = left edge, 1.0 = right edge)
- "y": vertical position of the CENTER of the damage as a fraction of image height (0.0 = top edge, 1.0 = bottom edge)
- "radius": size of the damage area as a fraction of image width (0.03 for small parts like lights, 0.08 for medium panels, 0.12 for large areas)

Be PRECISE with coordinates — place the circle exactly on the visible damage in the photo. If a part is not visible in a particular photo, do NOT include it in that photo's damageLocations.

Respond ONLY with valid JSON, no markdown formatting or code blocks.`,
    },
    ...photosToAnalyze.map(
      (url): ImageContent => ({
        type: "image_url" as const,
        image_url: {
          url,
          detail: "high",
        },
      })
    ),
  ];

  const response = await invokeLLM({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userContent },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "damage_analysis",
        strict: true,
        schema: {
          type: "object",
          properties: {
            overallSeverity: {
              type: "string",
              enum: ["minor", "moderate", "severe", "total_loss"],
              description: "Overall severity of the damage",
            },
            overallSeverityScore: {
              type: "number",
              description: "Severity score from 1 (minor) to 10 (total loss)",
            },
            summary: {
              type: "string",
              description: "2-3 sentence overall assessment with UAE context",
            },
            damages: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string", description: "Exact part name from reference list" },
                  partCategory: { type: "string", description: "Part category: Body Panel, Glass, Lighting, Suspension, Structural, Mechanical, Interior, Safety, Wheels, Electrical" },
                  description: { type: "string", description: "Detailed damage description with type, size, depth" },
                  repairMethod: { type: "string", description: "Specific repair method" },
                  paintRequired: { type: "boolean", description: "Whether painting is needed" },
                  oem_vs_aftermarket: { type: "string", description: "Parts sourcing recommendation" },
                  severity: {
                    type: "string",
                    enum: ["minor", "moderate", "severe"],
                  },
                  estimatedRepairCostAED: {
                    type: "object",
                    properties: {
                      low: { type: "number" },
                      high: { type: "number" },
                    },
                    required: ["low", "high"],
                    additionalProperties: false,
                  },
                },
                required: ["area", "partCategory", "description", "repairMethod", "paintRequired", "oem_vs_aftermarket", "severity", "estimatedRepairCostAED"],
                additionalProperties: false,
              },
            },
            structuralDamage: {
              type: "object",
              properties: {
                detected: { type: "boolean" },
                details: { type: "string" },
                affectedAreas: { type: "array", items: { type: "string" } },
              },
              required: ["detected", "details", "affectedAreas"],
              additionalProperties: false,
            },
            repairableAssessment: {
              type: "string",
              description: "Assessment of whether the vehicle is worth repairing in UAE",
            },
            estimatedTotalRepairAED: {
              type: "object",
              properties: {
                low: { type: "number" },
                high: { type: "number" },
              },
              required: ["low", "high"],
              additionalProperties: false,
            },
            estimatedRepairDays: {
              type: "object",
              properties: {
                low: { type: "number" },
                high: { type: "number" },
              },
              required: ["low", "high"],
              additionalProperties: false,
            },
            recommendations: {
              type: "array",
              items: { type: "string" },
              description: "Actionable recommendations for the UAE buyer",
            },
            photoAnalysis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  photoIndex: { type: "number" },
                  description: { type: "string" },
                  visibleDamages: {
                    type: "array",
                    items: { type: "string" },
                  },
                  damageLocations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        label: { type: "string", description: "Short name of the damaged part" },
                        x: { type: "number", description: "Horizontal center position as fraction 0.0-1.0" },
                        y: { type: "number", description: "Vertical center position as fraction 0.0-1.0" },
                        radius: { type: "number", description: "Circle radius as fraction of image width 0.03-0.15" },
                      },
                      required: ["label", "x", "y", "radius"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["photoIndex", "description", "visibleDamages", "damageLocations"],
                additionalProperties: false,
              },
            },
          },
          required: [
            "overallSeverity",
            "overallSeverityScore",
            "summary",
            "damages",
            "structuralDamage",
            "repairableAssessment",
            "estimatedTotalRepairAED",
            "estimatedRepairDays",
            "recommendations",
            "photoAnalysis",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content;
  const text = typeof content === "string" ? content : "";

  try {
    const result = JSON.parse(text) as DamageAnalysisResult;

    // Apply 50% cost reduction — LLM tends to overestimate UAE workshop prices
    // Real Sharjah/Ras Al Khor workshop costs are significantly lower
    const COST_FACTOR = 0.5;
    result.damages = result.damages.map(d => ({
      ...d,
      estimatedRepairCostAED: {
        low: Math.round(d.estimatedRepairCostAED.low * COST_FACTOR),
        high: Math.round(d.estimatedRepairCostAED.high * COST_FACTOR),
      },
    }));
    result.estimatedTotalRepairAED = {
      low: Math.round(result.estimatedTotalRepairAED.low * COST_FACTOR),
      high: Math.round(result.estimatedTotalRepairAED.high * COST_FACTOR),
    };

    return result;
  } catch {
    // If JSON parsing fails, return a fallback
    return {
      overallSeverity: "moderate",
      overallSeverityScore: 5,
      summary: "Unable to parse AI analysis. The photos were processed but the response format was unexpected. Please try again.",
      damages: [],
      structuralDamage: { detected: false, details: "Analysis inconclusive", affectedAreas: [] },
      repairableAssessment: "Analysis inconclusive — please retry.",
      estimatedTotalRepairAED: { low: 0, high: 0 },
      estimatedRepairDays: { low: 0, high: 0 },
      recommendations: ["Try analyzing again with clearer photos"],
      photoAnalysis: [],
    };
  }
}

// ─── Router ───
export const damageAnalysisRouter = router({
  // Analyze damage from photo URLs — returns UAE market values in AED
  analyze: publicProcedure
    .input(
      z.object({
        imageUrls: z.array(z.string().url()).min(1).max(10),
        vehicleInfo: z
          .object({
            year: z.string().optional(),
            make: z.string().optional(),
            model: z.string().optional(),
            primaryDamage: z.string().optional(),
            secondaryDamage: z.string().optional(),
          })
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { imageUrls, vehicleInfo } = input;

      const analysis = await analyzePhotosWithAI(imageUrls, vehicleInfo || {});

      return {
        success: true,
        analysis,
        photosAnalyzed: Math.min(imageUrls.length, 6),
        totalPhotos: imageUrls.length,
      };
    }),
});
