import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { CLIENT_COOKIE_NAME } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import { jwtVerify } from "jose";
import { ENV } from "./env";
import { getClientAccountById } from "../clientAccounts";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  clientAccountId: number | null;
};

/**
 * Try to authenticate via the client session cookie (JWT set during client login).
 * Returns a User-shaped object built from the clientAccounts table.
 */
async function authenticateClientSession(
  cookieHeader: string | undefined
): Promise<{ user: User; clientAccountId: number } | null> {
  if (!cookieHeader) return null;

  const cookies = parseCookieHeader(cookieHeader);
  const token = cookies[CLIENT_COOKIE_NAME];
  if (!token) return null;

  try {
    const secret = new TextEncoder().encode(ENV.cookieSecret);
    const { payload } = await jwtVerify(token, secret, { algorithms: ["HS256"] });

    const accountId = payload.accountId as number;
    if (!accountId) return null;

    const account = await getClientAccountById(accountId);
    if (!account || !account.isActive) return null;

    // Map clientAccount to a User-shaped object so ctx.user works with protectedProcedure
    const userShim: User = {
      id: account.id,
      openId: `client_${account.id}`,
      name: account.displayName || account.username,
      email: account.email,
      loginMethod: "client_login",
      role: account.role as "user" | "admin",
      createdAt: account.createdAt,
      updatedAt: account.updatedAt,
      lastSignedIn: account.lastLoginAt || account.createdAt,
    };

    return { user: userShim, clientAccountId: account.id };
  } catch (error) {
    // Invalid or expired token
    return null;
  }
}

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let clientAccountId: number | null = null;

  // 1. Try client session cookie FIRST — if the user explicitly logged in
  //    via the client login form, their client role should take priority
  //    over the Manus OAuth session (which is always present for the site owner).
  const clientAuth = await authenticateClientSession(opts.req.headers.cookie);
  if (clientAuth) {
    user = clientAuth.user;
    clientAccountId = clientAuth.clientAccountId;
  }

  // 2. If no client session, fall back to Manus OAuth
  if (!user) {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch (error) {
      // Authentication is optional for public procedures.
      user = null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
    clientAccountId,
  };
}
