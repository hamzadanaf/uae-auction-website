import { describe, it, expect, vi } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue({
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        onDuplicateKeyUpdate: vi.fn().mockResolvedValue([{ insertId: 1 }]),
      }),
    }),
    select: vi.fn().mockReturnValue({
      from: vi.fn().mockReturnValue({
        where: vi.fn().mockReturnValue({
          orderBy: vi.fn().mockResolvedValue([]),
          limit: vi.fn().mockResolvedValue([]),
        }),
      }),
    }),
    delete: vi.fn().mockReturnValue({
      where: vi.fn().mockResolvedValue(undefined),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue(undefined),
      }),
    }),
  }),
}));

describe("Deal Queue Router", () => {
  it("should have the correct input schema for saving a deal", () => {
    // Validate the expected deal data structure
    const sampleDeal = {
      vin: "2C3CDXCT0PH548350",
      vehicleInfo: JSON.stringify({ year: "2023", make: "DODGE", model: "Charger" }),
      auctionHouse: "iaai",
      bidAmountUSD: 15000,
      shippingCostUSD: 2500,
      mileage: 25000,
      uaeMarketPriceAED: 120000,
      emirate: "dubai",
      includeRegistration: true,
      damageTypes: JSON.stringify(["front-end"]),
      spareParts: JSON.stringify(["front-bumper", "hood"]),
      costBreakdown: JSON.stringify({
        auctionFeesUSD: 1500,
        shippingUSD: 2500,
        totalLandedUSD: 19000,
        totalLandedAED: 69778,
        customsDutyAED: 3489,
        vatAED: 3489,
        partsAED: 5000,
        registrationAED: 2500,
        totalCostAED: 84256,
        estimatedProfitAED: 35744,
        profitMarginPercent: 42,
      }),
      totalCostAED: 84256,
      estimatedProfitAED: 35744,
      profitMarginPercent: 42,
    };

    expect(sampleDeal.vin).toHaveLength(17);
    expect(sampleDeal.bidAmountUSD).toBeGreaterThan(0);
    expect(sampleDeal.totalCostAED).toBeGreaterThan(0);
    expect(JSON.parse(sampleDeal.vehicleInfo)).toHaveProperty("make");
    expect(JSON.parse(sampleDeal.costBreakdown)).toHaveProperty("totalCostAED");
  });

  it("should correctly parse JSON fields when listing deals", () => {
    const rawDeal = {
      id: 1,
      userId: 1,
      vin: "2C3CDXCT0PH548350",
      vehicleInfo: '{"year":"2023","make":"DODGE","model":"Charger"}',
      auctionHouse: "iaai",
      bidAmountUSD: 15000,
      shippingCostUSD: 2500,
      mileage: 25000,
      uaeMarketPriceAED: 120000,
      emirate: "dubai",
      includeRegistration: 0,
      damageTypes: '["front-end"]',
      spareParts: '["front-bumper","hood"]',
      costBreakdown: '{"totalCostAED":84256}',
      totalCostAED: 84256,
      estimatedProfitAED: 35744,
      profitMarginPercent: 42,
      auctionLotData: null,
      damageAnalysis: null,
      photoUrl: null,
      notes: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const parsed = {
      ...rawDeal,
      vehicleInfo: JSON.parse(rawDeal.vehicleInfo),
      damageTypes: JSON.parse(rawDeal.damageTypes),
      spareParts: JSON.parse(rawDeal.spareParts),
      costBreakdown: JSON.parse(rawDeal.costBreakdown),
      auctionLotData: rawDeal.auctionLotData ? JSON.parse(rawDeal.auctionLotData) : null,
      damageAnalysis: rawDeal.damageAnalysis ? JSON.parse(rawDeal.damageAnalysis) : null,
    };

    expect(parsed.vehicleInfo.make).toBe("DODGE");
    expect(parsed.damageTypes).toContain("front-end");
    expect(parsed.spareParts).toContain("front-bumper");
    expect(parsed.costBreakdown.totalCostAED).toBe(84256);
    expect(parsed.auctionLotData).toBeNull();
  });

  it("should handle deal comparison sorting correctly", () => {
    const deals = [
      { id: 1, profitMarginPercent: 42, estimatedProfitAED: 35744, totalCostAED: 84256 },
      { id: 2, profitMarginPercent: 28, estimatedProfitAED: 22000, totalCostAED: 78000 },
      { id: 3, profitMarginPercent: 55, estimatedProfitAED: 48000, totalCostAED: 87000 },
    ];

    // Sort by profit margin descending
    const sortedByMargin = [...deals].sort((a, b) => b.profitMarginPercent - a.profitMarginPercent);
    expect(sortedByMargin[0].id).toBe(3);
    expect(sortedByMargin[2].id).toBe(2);

    // Sort by total cost ascending
    const sortedByCost = [...deals].sort((a, b) => a.totalCostAED - b.totalCostAED);
    expect(sortedByCost[0].id).toBe(2);
  });
});

describe("PDF Export Router", () => {
  it("should format currency values correctly", () => {
    const formatUSD = (n: number) => `$${n.toLocaleString("en-US")}`;
    const formatAED = (n: number) => `AED ${n.toLocaleString("en-US")}`;

    expect(formatUSD(15000)).toBe("$15,000");
    expect(formatAED(84256)).toBe("AED 84,256");
    expect(formatUSD(0)).toBe("$0");
  });

  it("should correctly determine severity colors", () => {
    const severityColor = (s: string) => {
      if (s === "minor") return "#22c55e";
      if (s === "moderate") return "#f59e0b";
      return "#ef4444";
    };

    expect(severityColor("minor")).toBe("#22c55e");
    expect(severityColor("moderate")).toBe("#f59e0b");
    expect(severityColor("severe")).toBe("#ef4444");
    expect(severityColor("total_loss")).toBe("#ef4444");
  });

  it("should build vehicle name from parts", () => {
    const buildName = (vi: { year?: string; make?: string; model?: string; trim?: string }) =>
      [vi.year, vi.make, vi.model, vi.trim].filter(Boolean).join(" ");

    expect(buildName({ year: "2023", make: "DODGE", model: "Charger", trim: "R/T" })).toBe(
      "2023 DODGE Charger R/T"
    );
    expect(buildName({ year: "2022", make: "BMW" })).toBe("2022 BMW");
    expect(buildName({})).toBe("");
  });

  it("should generate HTML with correct profit color", () => {
    const profitColor = (profit: number) => (profit >= 0 ? "#10b981" : "#ef4444");

    expect(profitColor(35744)).toBe("#10b981");
    expect(profitColor(-5000)).toBe("#ef4444");
    expect(profitColor(0)).toBe("#10b981");
  });
});
