import { describe, it, expect, vi } from "vitest";

// ─── Quote Request Flow Tests ───
describe("Quote Request Flow", () => {
  it("should have submitQuoteRequest endpoint in directoryRouter", async () => {
    const { directoryRouter } = await import("./directoryRouter");
    expect(directoryRouter).toBeDefined();
    // Check that the router has the expected procedures
    const procedures = Object.keys(directoryRouter._def.procedures);
    expect(procedures).toContain("submitQuoteRequest");
    expect(procedures).toContain("myQuoteRequests");
    expect(procedures).toContain("listQuoteRequests");
    expect(procedures).toContain("updateQuoteRequestStatus");
  });

  it("should have all directory listing endpoints", async () => {
    const { directoryRouter } = await import("./directoryRouter");
    const procedures = Object.keys(directoryRouter._def.procedures);
    expect(procedures).toContain("listActiveShippingCompanies");
    expect(procedures).toContain("listActiveInsuranceCompanies");
    expect(procedures).toContain("listActivePartsShops");
  });

  it("quoteRequests schema should have required fields", async () => {
    const { quoteRequests } = await import("../drizzle/schema");
    expect(quoteRequests).toBeDefined();
    // Check column names exist
    const columns = Object.keys(quoteRequests);
    expect(columns).toContain("companyType");
    expect(columns).toContain("companyId");
    expect(columns).toContain("companyName");
    expect(columns).toContain("clientAccountId");
    expect(columns).toContain("status");
  });
});

// ─── Admin Parts Prices Tests ───
describe("Admin Parts Prices", () => {
  it("should have getPartsPrices endpoint in siteConfigRouter", async () => {
    const { siteConfigRouter } = await import("./siteConfigRouter");
    const procedures = Object.keys(siteConfigRouter._def.procedures);
    expect(procedures).toContain("getPartsPrices");
    expect(procedures).toContain("upsertPartPrice");
    expect(procedures).toContain("bulkUpsertPartsPrices");
  });

  it("adminPartsPrices schema should have required fields", async () => {
    const { adminPartsPrices } = await import("../drizzle/schema");
    expect(adminPartsPrices).toBeDefined();
    const columns = Object.keys(adminPartsPrices);
    expect(columns).toContain("partId");
    expect(columns).toContain("partName");
    expect(columns).toContain("category");
    expect(columns).toContain("priceAED");
    expect(columns).toContain("isActive");
  });

  it("SPARE_PARTS hardcoded data should be valid", async () => {
    const { SPARE_PARTS } = await import("../client/src/lib/auctionData");
    expect(SPARE_PARTS.length).toBeGreaterThan(0);
    for (const part of SPARE_PARTS) {
      expect(part.id).toBeTruthy();
      expect(part.category).toBeTruthy();
      expect(part.name).toBeTruthy();
      expect(part.priceAED).toBeGreaterThan(0);
    }
  });

  it("SPARE_PARTS should have unique IDs", async () => {
    const { SPARE_PARTS } = await import("../client/src/lib/auctionData");
    const ids = SPARE_PARTS.map((p) => p.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });
});

// ─── Auth Protection Tests ───
describe("Auth Protection", () => {
  it("should have CLIENT_COOKIE_NAME constant", async () => {
    const { CLIENT_COOKIE_NAME } = await import("../shared/const");
    expect(CLIENT_COOKIE_NAME).toBeTruthy();
    expect(typeof CLIENT_COOKIE_NAME).toBe("string");
  });

  it("clientRouter should have login and register endpoints", async () => {
    const { clientRouter } = await import("./clientRouter");
    const procedures = Object.keys(clientRouter._def.procedures);
    expect(procedures).toContain("login");
    expect(procedures).toContain("register");
    expect(procedures).toContain("clientLogout");
    expect(procedures).toContain("getMyAccount");
    expect(procedures).toContain("changePassword");
  });

  it("protected routes should be defined in appRouter", async () => {
    const { appRouter } = await import("./routers");
    const topLevel = Object.keys(appRouter._def.procedures);
    // Check that key routers are wired
    expect(topLevel.some((k) => k.startsWith("accounts."))).toBe(true);
    expect(topLevel.some((k) => k.startsWith("directory."))).toBe(true);
    expect(topLevel.some((k) => k.startsWith("siteConfig."))).toBe(true);
    expect(topLevel.some((k) => k.startsWith("admin."))).toBe(true);
  });
});

// ─── Fee Schedule Tests ───
describe("Fee Schedules", () => {
  it("should have getFeeSchedules endpoint", async () => {
    const { siteConfigRouter } = await import("./siteConfigRouter");
    const procedures = Object.keys(siteConfigRouter._def.procedures);
    expect(procedures).toContain("getFeeSchedules");
    expect(procedures).toContain("upsertFeeSchedule");
    expect(procedures).toContain("bulkUpsertFeeSchedules");
  });

  it("adminFeeSchedules schema should have required fields", async () => {
    const { adminFeeSchedules } = await import("../drizzle/schema");
    const columns = Object.keys(adminFeeSchedules);
    expect(columns).toContain("category");
    expect(columns).toContain("feeKey");
    expect(columns).toContain("value");
    expect(columns).toContain("isActive");
  });
});
