ALTER TABLE `clientAccounts` ADD `vinLimitOverride` int;--> statement-breakpoint
ALTER TABLE `clientAccounts` ADD `bonusVinCredits` int DEFAULT 0 NOT NULL;