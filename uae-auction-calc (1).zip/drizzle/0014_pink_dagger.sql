ALTER TABLE `vehicleModels` ADD `year` int NOT NULL;--> statement-breakpoint
ALTER TABLE `vehicleModels` ADD `dubizzleBrandSlug` varchar(128);--> statement-breakpoint
ALTER TABLE `vehicleModels` ADD `dubizzleModelSlug` varchar(128);--> statement-breakpoint
ALTER TABLE `vehicleModels` DROP COLUMN `yearFrom`;--> statement-breakpoint
ALTER TABLE `vehicleModels` DROP COLUMN `yearTo`;