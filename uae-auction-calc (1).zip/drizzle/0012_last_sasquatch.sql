CREATE TABLE `shippingRates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`auction` enum('Copart','IAAI') NOT NULL,
	`state` varchar(10) NOT NULL,
	`city` varchar(100) NOT NULL,
	`loadingPort` varchar(10) NOT NULL,
	`price` decimal(10,2) NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shippingRates_id` PRIMARY KEY(`id`)
);
