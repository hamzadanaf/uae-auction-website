import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Client accounts table for simple username/password login
 */
export const clientAccounts = mysqlTable("clientAccounts", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  displayName: text("displayName"),
  email: varchar("email", { length: 320 }),
  /** UAE phone number (+971XXXXXXXXX) — unique, used for registration */
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  role: mysqlEnum("role", ["admin", "user"]).default("user").notNull(),
  createdByUserId: int("createdByUserId").notNull(),
  isActive: int("isActive").default(1).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("approved").notNull(),
  /** Per-user VIN limit override (null = use plan default) */
  vinLimitOverride: int("vinLimitOverride"),
  /** Bonus VIN credits added manually by admin (added on top of plan limit) */
  bonusVinCredits: int("bonusVinCredits").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastLoginAt: timestamp("lastLoginAt"),
});

export type ClientAccount = typeof clientAccounts.$inferSelect;
export type InsertClientAccount = typeof clientAccounts.$inferInsert;

/**
 * Saved deals for the Deal Queue
 */
export const savedDeals = mysqlTable("savedDeals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  vin: varchar("vin", { length: 17 }).notNull(),
  vehicleInfo: text("vehicleInfo").notNull(),
  auctionHouse: varchar("auctionHouse", { length: 10 }).notNull(),
  bidAmountUSD: int("bidAmountUSD").notNull(),
  shippingCostUSD: int("shippingCostUSD").notNull(),
  mileage: int("mileage").notNull(),
  uaeMarketPriceAED: int("uaeMarketPriceAED").notNull(),
  emirate: varchar("emirate", { length: 32 }).notNull(),
  includeRegistration: int("includeRegistration").default(0).notNull(),
  damageTypes: text("damageTypes").notNull(),
  spareParts: text("spareParts").notNull(),
  costBreakdown: text("costBreakdown").notNull(),
  totalCostAED: int("totalCostAED").notNull(),
  estimatedProfitAED: int("estimatedProfitAED").notNull(),
  profitMarginPercent: int("profitMarginPercent").notNull(),
  auctionLotData: text("auctionLotData"),
  damageAnalysis: text("damageAnalysis"),
  photoUrl: text("photoUrl"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SavedDeal = typeof savedDeals.$inferSelect;
export type InsertSavedDeal = typeof savedDeals.$inferInsert;

/**
 * VIN usage tracking
 */
export const vinUsage = mysqlTable("vinUsage", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  vin: varchar("vin", { length: 17 }).notNull(),
  actionType: varchar("actionType", { length: 32 }).default("vin_search").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VinUsage = typeof vinUsage.$inferSelect;
export type InsertVinUsage = typeof vinUsage.$inferInsert;

/**
 * Pricing plans — admin-editable subscription tiers
 */
export const pricingPlans = mysqlTable("pricingPlans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 64 }).notNull(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  description: text("description"),
  priceMonthlyAED: int("priceMonthlyAED").notNull(),
  priceAnnualAED: int("priceAnnualAED").notNull(),
  vinLimitPerMonth: int("vinLimitPerMonth").default(10).notNull(),
  features: text("features").notNull(),
  isActive: int("isActive").default(1).notNull(),
  isPopular: int("isPopular").default(0).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PricingPlan = typeof pricingPlans.$inferSelect;
export type InsertPricingPlan = typeof pricingPlans.$inferInsert;

/**
 * Client subscriptions
 */
export const clientSubscriptions = mysqlTable("clientSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  planId: int("planId").notNull(),
  billingPeriod: mysqlEnum("billingPeriod", ["monthly", "annual"]).default("monthly").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["stripe", "bank_transfer"]).default("bank_transfer").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired", "pending_payment"]).default("pending_payment").notNull(),
  amountAED: int("amountAED").notNull(),
  currentPeriodStart: timestamp("currentPeriodStart").defaultNow().notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd").notNull(),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClientSubscription = typeof clientSubscriptions.$inferSelect;
export type InsertClientSubscription = typeof clientSubscriptions.$inferInsert;

// ═══════════════════════════════════════════════════════════════
// NEW TABLES — Admin Management
// ═══════════════════════════════════════════════════════════════

/**
 * Site settings — key/value store for admin-configurable feature toggles and settings
 */
export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").autoincrement().primaryKey(),
  /** Setting key (e.g., "shipping_quotes_enabled", "insurance_quotes_enabled") */
  settingKey: varchar("settingKey", { length: 128 }).notNull().unique(),
  /** Setting value (stored as string, parse as needed) */
  settingValue: text("settingValue").notNull(),
  /** Human-readable label */
  label: varchar("label", { length: 255 }),
  /** Category for grouping in admin UI */
  category: varchar("category", { length: 64 }).default("general").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

/**
 * Shipping companies directory — admin manages, clients can browse and request quotes
 */
export const shippingCompanies = mysqlTable("shippingCompanies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  website: varchar("website", { length: 512 }),
  location: varchar("location", { length: 255 }),
  /** Comma-separated: "US to UAE", "Container", "RoRo", etc. */
  services: text("services"),
  /** Short description */
  description: text("description"),
  /** Logo URL */
  logoUrl: text("logoUrl"),
  /** Whether visible on client site */
  isActive: int("isActive").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ShippingCompany = typeof shippingCompanies.$inferSelect;
export type InsertShippingCompany = typeof shippingCompanies.$inferInsert;

/**
 * Insurance companies directory
 */
export const insuranceCompanies = mysqlTable("insuranceCompanies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  website: varchar("website", { length: 512 }),
  location: varchar("location", { length: 255 }),
  /** Comma-separated: "Comprehensive", "Third Party", "Salvage", etc. */
  coverageTypes: text("coverageTypes"),
  description: text("description"),
  logoUrl: text("logoUrl"),
  isActive: int("isActive").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InsuranceCompany = typeof insuranceCompanies.$inferSelect;
export type InsertInsuranceCompany = typeof insuranceCompanies.$inferInsert;

/**
 * Spare parts shops directory
 */
export const sparePartsShops = mysqlTable("sparePartsShops", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  website: varchar("website", { length: 512 }),
  location: varchar("location", { length: 255 }),
  /** Area: "Sharjah Industrial", "Ras Al Khor", "Al Ain", etc. */
  area: varchar("area", { length: 128 }),
  /** Comma-separated: "Japanese", "American", "European", "All Makes", etc. */
  specialties: text("specialties"),
  description: text("description"),
  logoUrl: text("logoUrl"),
  isActive: int("isActive").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SparePartsShop = typeof sparePartsShops.$inferSelect;
export type InsertSparePartsShop = typeof sparePartsShops.$inferInsert;

/**
 * Quote requests — clients request quotes from shipping/insurance/parts companies
 */
export const quoteRequests = mysqlTable("quoteRequests", {
  id: int("id").autoincrement().primaryKey(),
  /** Which type of company: shipping, insurance, parts */
  companyType: mysqlEnum("companyType", ["shipping", "insurance", "parts"]).notNull(),
  /** ID of the company in its respective table */
  companyId: int("companyId").notNull(),
  /** Company name (denormalized for easy display) */
  companyName: varchar("companyName", { length: 255 }).notNull(),
  /** Client account ID who requested */
  clientAccountId: int("clientAccountId").notNull(),
  /** Client name (denormalized) */
  clientName: varchar("clientName", { length: 255 }),
  /** Client email */
  clientEmail: varchar("clientEmail", { length: 320 }),
  /** Client phone */
  clientPhone: varchar("clientPhone", { length: 32 }),
  /** Vehicle info (VIN, year, make, model) */
  vehicleInfo: text("vehicleInfo"),
  /** Free-text message from client */
  message: text("message"),
  /** Quote status */
  status: mysqlEnum("status", ["pending", "sent", "responded", "closed"]).default("pending").notNull(),
  /** Admin notes */
  adminNotes: text("adminNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type QuoteRequest = typeof quoteRequests.$inferSelect;
export type InsertQuoteRequest = typeof quoteRequests.$inferInsert;

/**
 * Admin-editable spare parts prices — overrides the hardcoded defaults
 */
export const adminPartsPrices = mysqlTable("adminPartsPrices", {
  id: int("id").autoincrement().primaryKey(),
  /** Part ID matching the hardcoded SPARE_PARTS array (e.g., "engine", "front-bumper") */
  partId: varchar("partId", { length: 64 }).notNull().unique(),
  /** Part name */
  partName: varchar("partName", { length: 128 }).notNull(),
  /** Category */
  category: varchar("category", { length: 64 }).notNull(),
  /** Price in AED (whole number) */
  priceAED: int("priceAED").notNull(),
  /** Whether this part is active in the calculator */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminPartsPrice = typeof adminPartsPrices.$inferSelect;
export type InsertAdminPartsPrice = typeof adminPartsPrices.$inferInsert;

/**
 * Admin AI cost settings — controls the cost multiplier and base prices for AI damage analysis
 */
export const adminAiCostSettings = mysqlTable("adminAiCostSettings", {
  id: int("id").autoincrement().primaryKey(),
  /** Setting key (e.g., "cost_multiplier", "labor_rate_per_hour", "paint_per_panel") */
  settingKey: varchar("settingKey", { length: 128 }).notNull().unique(),
  /** Setting value (number stored as string) */
  settingValue: varchar("settingValue", { length: 64 }).notNull(),
  /** Human-readable label */
  label: varchar("label", { length: 255 }),
  /** Description of what this setting controls */
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminAiCostSetting = typeof adminAiCostSettings.$inferSelect;
export type InsertAdminAiCostSetting = typeof adminAiCostSettings.$inferInsert;

/**
 * Admin-editable fee schedules — buyer fees, virtual bid fees, fixed fees, customs, VAT, emirate registration
 * Each row is a fee entry identified by category + key
 */
export const adminFeeSchedules = mysqlTable("adminFeeSchedules", {
  id: int("id").autoincrement().primaryKey(),
  /** Category: "copart_buyer_fee", "iaai_buyer_fee", "copart_virtual_fee", "fixed_fee", "import_tax", "emirate_registration" */
  category: varchar("category", { length: 64 }).notNull(),
  /** Key within category (e.g., for buyer fees: "0-50", for fixed: "gate_fee", for emirate: "dubai") */
  feeKey: varchar("feeKey", { length: 128 }).notNull(),
  /** Human-readable label */
  label: varchar("label", { length: 255 }),
  /** JSON value — structure depends on category:
   *  buyer_fee: { min, max, fee, percent? }
   *  fixed_fee: { value }
   *  import_tax: { rate }
   *  emirate_registration: { registrationFee, inspectionFee, plateFee, otherFees, total, notes }
   */
  value: text("value").notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminFeeSchedule = typeof adminFeeSchedules.$inferSelect;
export type InsertAdminFeeSchedule = typeof adminFeeSchedules.$inferInsert;

/**
 * Admin-editable shipping rates table.
 * Mirrors the hardcoded SHIPPING_RATES structure but stored in DB for admin editing.
 */
export const shippingRates = mysqlTable("shippingRates", {
  id: int("id").autoincrement().primaryKey(),
  auction: mysqlEnum("auction", ["Copart", "IAAI"]).notNull(),
  state: varchar("state", { length: 10 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  loadingPort: varchar("loadingPort", { length: 10 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ShippingRateRow = typeof shippingRates.$inferSelect;
export type InsertShippingRate = typeof shippingRates.$inferInsert;

/**
 * Vehicle Models — 160+ models with UAE market pricing
 * Used for brand grid, model browsing, VIN auto-matching, and profit calculation
 */
export const vehicleModels = mysqlTable("vehicleModels", {
  id: int("id").autoincrement().primaryKey(),
  /** Brand name (e.g., "Ford", "Toyota", "BMW") */
  brand: varchar("brand", { length: 64 }).notNull(),
  /** Model name (e.g., "F-150", "Camry", "X5") */
  model: varchar("model", { length: 128 }).notNull(),
  /** Comma-separated trims (e.g., "XL, XLT, Lariat, King Ranch, Platinum") */
  trims: text("trims"),
  /** Region: american, japanese, european, korean */
  region: mysqlEnum("region", ["american", "japanese", "european", "korean"]).notNull(),
  /** Vehicle category */
  category: mysqlEnum("category", ["sedan", "suv", "truck", "coupe", "hatchback", "van", "electric", "sports", "luxury", "crossover"]).notNull(),
  /** Specific model year (e.g., 2020) */
  year: int("year").notNull(),
  /** UAE market price LOW (AED) — clean title, average condition */
  uaeMarketPriceLow: int("uaeMarketPriceLow"),
  /** UAE market price MID (AED) */
  uaeMarketPriceMid: int("uaeMarketPriceMid"),
  /** UAE market price HIGH (AED) */
  uaeMarketPriceHigh: int("uaeMarketPriceHigh"),
  /** Average US auction price (USD) */
  auctionAvgPriceUSD: int("auctionAvgPriceUSD"),
  /** Brand logo URL */
  brandLogoUrl: text("brandLogoUrl"),
  /** Dubizzle brand slug for marketplace link (e.g., "toyota", "mercedes-benz") */
  dubizzleBrandSlug: varchar("dubizzleBrandSlug", { length: 128 }),
  /** Dubizzle model slug for marketplace link (e.g., "camry", "3-series") */
  dubizzleModelSlug: varchar("dubizzleModelSlug", { length: 128 }),
  /** Whether this model is active/visible */
  isActive: int("isActive").default(1).notNull(),
  /** Last time prices were auto-updated */
  pricesUpdatedAt: timestamp("pricesUpdatedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VehicleModel = typeof vehicleModels.$inferSelect;
export type InsertVehicleModel = typeof vehicleModels.$inferInsert;
