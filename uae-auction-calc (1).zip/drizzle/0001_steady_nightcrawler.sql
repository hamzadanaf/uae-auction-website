CREATE TABLE `clientAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(64) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`displayName` text,
	`email` varchar(320),
	`createdByUserId` int NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastLoginAt` timestamp,
	CONSTRAINT `clientAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `clientAccounts_username_unique` UNIQUE(`username`)
);
