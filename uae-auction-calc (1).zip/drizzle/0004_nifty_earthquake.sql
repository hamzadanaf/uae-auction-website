DROP TABLE `clientUsageLogs`;--> statement-breakpoint
DROP TABLE `passwordResetTokens`;