CREATE TABLE `clientSubscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`planId` int NOT NULL,
	`billingPeriod` enum('monthly','annual') NOT NULL DEFAULT 'monthly',
	`paymentMethod` enum('stripe','bank_transfer') NOT NULL DEFAULT 'bank_transfer',
	`status` enum('active','cancelled','expired','pending_payment') NOT NULL DEFAULT 'pending_payment',
	`amountAED` int NOT NULL,
	`currentPeriodStart` timestamp NOT NULL DEFAULT (now()),
	`currentPeriodEnd` timestamp NOT NULL,
	`stripeSubscriptionId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clientSubscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pricingPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(64) NOT NULL,
	`slug` varchar(64) NOT NULL,
	`description` text,
	`priceMonthlyAED` int NOT NULL,
	`priceAnnualAED` int NOT NULL,
	`vinLimitPerMonth` int NOT NULL DEFAULT 10,
	`features` text NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`isPopular` int NOT NULL DEFAULT 0,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pricingPlans_id` PRIMARY KEY(`id`),
	CONSTRAINT `pricingPlans_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `vinUsage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`vin` varchar(17) NOT NULL,
	`actionType` varchar(32) NOT NULL DEFAULT 'vin_search',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vinUsage_id` PRIMARY KEY(`id`)
);
